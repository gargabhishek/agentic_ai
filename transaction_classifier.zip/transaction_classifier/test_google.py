#!/usr/bin/env python3
"""
Test Google AI API key
"""

import os
import requests
import json
from dotenv import load_dotenv

def test_google_api():
    """Test if Google AI API key works"""
    
    print("🔍 Testing Google AI API key...")
    
    # Load environment variables
    load_dotenv()
    
    api_key = os.getenv("GOOGLE_AI_API_KEY")
    if not api_key:
        print("❌ No GOOGLE_AI_API_KEY found in .env file")
        return False
    
    print(f"✅ API key found: {api_key[:10]}...{api_key[-10:]}")
    
    # Test API endpoint
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key={api_key}"
    
    # Simple test request
    payload = {
        "contents": [
            {
                "parts": [
                    {"text": "Classify this transaction: UPI-ZEPTO for groceries. Return JSON with category and confidence."}
                ]
            }
        ]
    }
    
    try:
        print("🚀 Testing API call...")
        response = requests.post(url, json=payload, timeout=10)
        
        print(f"📡 Response Status: {response.status_code}")
        
        if response.status_code == 200:
            result = response.json()
            print("✅ Google AI API call successful!")
            text_result = result["candidates"][0]["content"]["parts"][0]["text"]
            print(f"📄 Response: {text_result[:200]}...")
            return True
        else:
            print("❌ API call failed!")
            print(f"📄 Error response: {response.text}")
            return False
            
    except Exception as e:
        print(f"💥 Exception: {str(e)}")
        return False

if __name__ == "__main__":
    test_google_api()
