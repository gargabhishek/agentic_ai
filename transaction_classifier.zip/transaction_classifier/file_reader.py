#!/usr/bin/env python3
"""
Bank Statement File Reader
Reads bank statement data from CSV and Excel files
"""

import pandas as pd
from pathlib import Path
from typing import List, Dict, Optional
import re
from datetime import datetime

from transaction_types import Transaction

class BankStatementReader:
    """Reader for bank statement files in various formats"""
    
    def __init__(self):
        """Initialize the file reader"""
        pass
    
    def read_file(self, file_path: Path) -> List[Transaction]:
        """
        Read bank statement file and return list of Transaction objects
        
        Args:
            file_path: Path to the bank statement file
            
        Returns:
            List of Transaction objects
        """
        
        file_extension = file_path.suffix.lower()
        
        if file_extension == '.csv':
            return self._read_csv(file_path)
        elif file_extension in ['.xlsx', '.xls']:
            return self._read_excel(file_path)
        else:
            raise ValueError(f"Unsupported file format: {file_extension}")
    
    def _read_csv(self, file_path: Path) -> List[Transaction]:
        """Read CSV file and parse transactions"""
        
        try:
            # Try different encodings
            for encoding in ['utf-8', 'latin-1', 'cp1252']:
                try:
                    df = pd.read_csv(file_path, encoding=encoding)
                    break
                except UnicodeDecodeError:
                    continue
            else:
                raise ValueError("Could not read CSV file with any encoding")
            
            return self._parse_dataframe(df, file_path)
            
        except Exception as e:
            raise Exception(f"Error reading CSV file: {str(e)}")
    
    def _read_excel(self, file_path: Path) -> List[Transaction]:
        """Read Excel file and parse transactions"""
        
        try:
            # Try to read the first sheet
            df = pd.read_excel(file_path, sheet_name=0)
            return self._parse_dataframe(df, file_path)
            
        except Exception as e:
            raise Exception(f"Error reading Excel file: {str(e)}")
    
    def _parse_dataframe(self, df: pd.DataFrame, file_path: Path) -> List[Transaction]:
        """
        Parse dataframe and convert to Transaction objects
        
        This method attempts to intelligently map columns to transaction fields
        """
        
        print(f"📊 Parsing {len(df)} rows from {file_path.name}")
        print(f"   Columns found: {list(df.columns)}")
        
        # Clean column names (remove extra spaces, make lowercase)
        df.columns = [str(col).strip().lower().replace(' ', '_') for col in df.columns]
        
        # Try to identify column mappings
        column_mapping = self._identify_columns(df.columns)
        print(f"   Column mapping: {column_mapping}")
        
        transactions = []
        
        for index, row in df.iterrows():
            try:
                # Skip rows with all NaN values
                if row.isna().all():
                    continue
                
                # Extract transaction data using mapped columns
                transaction = Transaction(
                    date=self._parse_date(row.get(column_mapping.get('date', ''), '')),
                    narration=str(row.get(column_mapping.get('narration', ''), '')),
                    chq_ref_no=str(row.get(column_mapping.get('chq_ref_no', ''), '')),
                    value_date=self._parse_date(row.get(column_mapping.get('value_date', ''), '')),
                    withdrawal_amt=self._parse_amount(row.get(column_mapping.get('withdrawal_amt', ''), 0)),
                    deposit_amt=self._parse_amount(row.get(column_mapping.get('deposit_amt', ''), 0)),
                    closing_balance=self._parse_amount(row.get(column_mapping.get('closing_balance', ''), 0))
                )
                
                # Only add transaction if it has meaningful data
                if transaction.narration and (transaction.withdrawal_amt > 0 or transaction.deposit_amt > 0):
                    transactions.append(transaction)
                    
            except Exception as e:
                print(f"   ⚠️ Skipping row {index}: {str(e)}")
                continue
        
        print(f"✅ Successfully parsed {len(transactions)} transactions")
        return transactions
    
    def _identify_columns(self, columns: List[str]) -> Dict[str, str]:
        """
        Intelligently identify which columns correspond to which transaction fields
        
        Args:
            columns: List of column names from the dataframe
            
        Returns:
            Dictionary mapping transaction fields to actual column names
        """
        
        mapping = {}
        
        # Define patterns for each field
        patterns = {
            'date': [r'.*date.*', r'.*dt.*', r'.*transaction_date.*'],
            'narration': [r'.*narration.*', r'.*description.*', r'.*desc.*', r'.*particulars.*', r'.*details.*'],
            'chq_ref_no': [r'.*chq.*', r'.*ref.*no.*', r'.*reference.*', r'.*cheque.*'],
            'value_date': [r'.*value.*dt.*', r'.*value_date.*', r'.*val.*date.*'],
            'withdrawal_amt': [r'.*withdrawal.*', r'.*debit.*', r'.*dr.*', r'.*out.*', r'.*expense.*'],
            'deposit_amt': [r'.*deposit.*', r'.*credit.*', r'.*cr.*', r'.*income.*', r'.*in.*'],
            'closing_balance': [r'.*closing.*balance.*', r'.*balance.*', r'.*bal.*']
        }
        
        # Try to match each field
        for field, field_patterns in patterns.items():
            for column in columns:
                for pattern in field_patterns:
                    if re.match(pattern, column, re.IGNORECASE):
                        mapping[field] = column
                        break
                if field in mapping:
                    break
        
        # If we can't find specific columns, make reasonable assumptions
        if not mapping and len(columns) >= 6:
            # Assume standard bank statement format
            mapping = {
                'date': columns[0],
                'narration': columns[1],
                'chq_ref_no': columns[2] if len(columns) > 2 else '',
                'value_date': columns[3] if len(columns) > 3 else columns[0],
                'withdrawal_amt': columns[4] if len(columns) > 4 else '',
                'deposit_amt': columns[5] if len(columns) > 5 else '',
                'closing_balance': columns[6] if len(columns) > 6 else ''
            }
        
        return mapping
    
    def _parse_date(self, date_value) -> str:
        """Parse date from various formats"""
        
        if pd.isna(date_value) or date_value == '':
            return ''
        
        try:
            # Try to parse as pandas datetime
            if isinstance(date_value, str):
                # Common Indian date formats
                for fmt in ['%d/%m/%y', '%d/%m/%Y', '%d-%m-%Y', '%d-%m-%y', '%Y-%m-%d']:
                    try:
                        parsed_date = datetime.strptime(str(date_value).strip(), fmt)
                        return parsed_date.strftime('%d/%m/%Y')
                    except:
                        continue
            
            # If it's already a datetime object
            if hasattr(date_value, 'strftime'):
                return date_value.strftime('%d/%m/%Y')
            
            # Fallback - return as string
            return str(date_value).strip()
            
        except:
            return str(date_value).strip()
    
    def _parse_amount(self, amount_value) -> float:
        """Parse amount from various formats"""
        
        if pd.isna(amount_value) or amount_value == '' or amount_value == 0:
            return 0.0
        
        try:
            # Remove common formatting characters
            amount_str = str(amount_value).replace(',', '').replace('₹', '').replace('Rs.', '').strip()
            
            # Handle negative values in parentheses
            if amount_str.startswith('(') and amount_str.endswith(')'):
                amount_str = '-' + amount_str[1:-1]
            
            # Convert to float
            return float(amount_str)
            
        except:
            return 0.0
    
    def preview_file(self, file_path: Path, rows: int = 5) -> pd.DataFrame:
        """
        Preview first few rows of the file to understand structure
        
        Args:
            file_path: Path to the file
            rows: Number of rows to preview
            
        Returns:
            DataFrame with preview data
        """
        
        file_extension = file_path.suffix.lower()
        
        try:
            if file_extension == '.csv':
                df = pd.read_csv(file_path, nrows=rows)
            elif file_extension in ['.xlsx', '.xls']:
                df = pd.read_excel(file_path, nrows=rows)
            else:
                raise ValueError(f"Unsupported file format: {file_extension}")
            
            return df
            
        except Exception as e:
            raise Exception(f"Error previewing file: {str(e)}")

# Example usage and testing
if __name__ == "__main__":
    # This section can be used for testing the file reader
    reader = BankStatementReader()
    
    # Example: Preview a sample file
    # sample_file = Path("sample_statement.csv")
    # if sample_file.exists():
    #     preview = reader.preview_file(sample_file)
    #     print("File Preview:")
    #     print(preview)
    #     
    #     transactions = reader.read_file(sample_file)
    #     print(f"Read {len(transactions)} transactions")
    
    print("🔍 BankStatementReader initialized and ready to use!")
