#!/usr/bin/env python3
"""
Bank Statement Transaction Classifier
Uses LLM to classify transactions into predefined categories
"""

import openai
import json
from typing import List, Dict, Optional
from dataclasses import dataclass
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Import transaction types
from transaction_types import Transaction, ClassifiedTransaction

class TransactionClassifier:
    """LLM-based transaction classifier for taxation purposes"""
    
    # Define transaction categories for taxation
    CATEGORIES = {
        "SALARY_INCOME": "Salary income from employer",
        "BUSINESS_INCOME": "Business or professional income",
        "HRA_PAYMENT": "HRA (House Rent Allowance) payment made",
        "HRA_RECEIVED": "HRA received from employer",
        "OFFICE_EXPENSE": "Office-related expenses (rent, utilities, supplies)",
        "BUSINESS_EXPENSE": "Business expenses (travel, meals, equipment)",
        "PERSONAL_EXPENSE": "Personal expenses (shopping, entertainment)",
        "MEDICAL_EXPENSE": "Medical and healthcare expenses",
        "EDUCATION_EXPENSE": "Education-related expenses",
        "INVESTMENT": "Investment in stocks, mutual funds, FD, etc.",
        "LOAN_EMI": "Loan EMI payments (home, car, personal)",
        "INSURANCE_PREMIUM": "Insurance premium payments",
        "TAX_PAYMENT": "Income tax, GST, or other tax payments",
        "SALARY_PAID": "Salary paid to employees",
        "PROFESSIONAL_FEES": "Professional services fees paid",
        "SELF_TRANSFER": "Transfer between own accounts",
        "FAMILY_TRANSFER": "Transfer to/from family members",
        "CASH_WITHDRAWAL": "ATM or cash withdrawals",
        "DIVIDEND_INCOME": "Dividend received",
        "INTEREST_INCOME": "Interest earned on deposits",
        "REFUND": "Refunds received",
        "PENALTY_FINE": "Penalties or fines paid",
        "DONATION": "Charitable donations",
        "OTHER": "Other transactions not fitting above categories"
    }
    
    def __init__(self, api_key: Optional[str] = None):
        """Initialize the classifier with OpenAI API key"""
        self.api_key = api_key or os.getenv("OPENAI_API_KEY")
        if not self.api_key:
            raise ValueError("OpenAI API key not found. Set OPENAI_API_KEY environment variable.")
        
        # Initialize OpenAI client
        openai.api_key = self.api_key
        self.client = openai.OpenAI(api_key=self.api_key)
    
    def classify_transaction(self, transaction: Transaction) -> ClassifiedTransaction:
        """
        Classify a single transaction using LLM
        
        Args:
            transaction: Transaction object to classify
            
        Returns:
            ClassifiedTransaction with category, confidence, and reasoning
        """
        
        # Prepare the prompt for LLM
        prompt = self._create_classification_prompt(transaction)
        
        try:
            # Call OpenAI API
            response = self.client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "You are a financial expert specializing in transaction categorization for taxation purposes in India. Analyze bank transactions and classify them accurately."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.1,  # Low temperature for consistent classification
                max_tokens=200
            )
            
            # Parse the response
            result = self._parse_llm_response(response.choices[0].message.content)
            
            # Create classified transaction
            return ClassifiedTransaction(
                date=transaction.date,
                narration=transaction.narration,
                chq_ref_no=transaction.chq_ref_no,
                value_date=transaction.value_date,
                withdrawal_amt=transaction.withdrawal_amt,
                deposit_amt=transaction.deposit_amt,
                closing_balance=transaction.closing_balance,
                category=result["category"],
                confidence=result["confidence"],
                reasoning=result["reasoning"]
            )
            
        except Exception as e:
            # Fallback classification in case of API error
            return ClassifiedTransaction(
                date=transaction.date,
                narration=transaction.narration,
                chq_ref_no=transaction.chq_ref_no,
                value_date=transaction.value_date,
                withdrawal_amt=transaction.withdrawal_amt,
                deposit_amt=transaction.deposit_amt,
                closing_balance=transaction.closing_balance,
                category="OTHER",
                confidence=0.0,
                reasoning=f"API Error: {str(e)}"
            )
    
    def classify_transactions(self, transactions: List[Transaction]) -> List[ClassifiedTransaction]:
        """
        Classify multiple transactions
        
        Args:
            transactions: List of Transaction objects
            
        Returns:
            List of ClassifiedTransaction objects
        """
        classified = []
        
        print(f"🔄 Classifying {len(transactions)} transactions...")
        
        for i, transaction in enumerate(transactions, 1):
            print(f"   Processing transaction {i}/{len(transactions)}")
            classified_transaction = self.classify_transaction(transaction)
            classified.append(classified_transaction)
        
        print("✅ Classification completed!")
        return classified
    
    def _create_classification_prompt(self, transaction: Transaction) -> str:
        """Create a structured prompt for LLM classification"""
        
        # Determine transaction type
        amount = transaction.withdrawal_amt if transaction.withdrawal_amt > 0 else transaction.deposit_amt
        transaction_type = "Withdrawal" if transaction.withdrawal_amt > 0 else "Deposit"
        
        categories_list = "\n".join([f"- {key}: {desc}" for key, desc in self.CATEGORIES.items()])
        
        prompt = f"""
Analyze this bank transaction and classify it into one of the predefined categories for taxation purposes:

TRANSACTION DETAILS:
- Date: {transaction.date}
- Description/Narration: {transaction.narration}
- Reference No: {transaction.chq_ref_no}
- Type: {transaction_type}
- Amount: ₹{amount:,.2f}

AVAILABLE CATEGORIES:
{categories_list}

Please respond in this exact JSON format:
{{
    "category": "CATEGORY_NAME",
    "confidence": 0.95,
    "reasoning": "Brief explanation of why this category was chosen"
}}

Consider these factors:
1. Keywords in the narration (salary, rent, medical, etc.)
2. Amount patterns (regular vs irregular)
3. Transaction type (deposit vs withdrawal)
4. Common Indian business/personal transaction patterns
5. Tax implications and deductibility

Choose the most appropriate category and provide confidence score (0.0 to 1.0).
"""
        
        return prompt
    
    def _parse_llm_response(self, response: str) -> Dict:
        """Parse LLM response and extract classification details"""
        
        try:
            # Clean the response and parse JSON
            response = response.strip()
            if response.startswith("```json"):
                response = response[7:]
            if response.endswith("```"):
                response = response[:-3]
            
            result = json.loads(response.strip())
            
            # Validate the response
            if "category" not in result:
                raise ValueError("No category in response")
            
            # Ensure category is valid
            if result["category"] not in self.CATEGORIES:
                result["category"] = "OTHER"
            
            # Ensure confidence is valid
            if "confidence" not in result or not (0 <= result["confidence"] <= 1):
                result["confidence"] = 0.5
            
            # Ensure reasoning exists
            if "reasoning" not in result:
                result["reasoning"] = "No reasoning provided"
            
            return result
            
        except Exception as e:
            # Fallback parsing
            return {
                "category": "OTHER",
                "confidence": 0.0,
                "reasoning": f"Failed to parse LLM response: {str(e)}"
            }
