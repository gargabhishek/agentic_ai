#!/usr/bin/env python3
"""
Bank Statement Transaction Classifier - Main Script
Simple LLM-based solution for classifying bank transactions for taxation purposes
"""

import os
import sys
from pathlib import Path
from dotenv import load_dotenv
import argparse
from datetime import datetime

# Add current directory to path for imports
sys.path.append(str(Path(__file__).parent))

from file_reader import BankStatementReader
from local_classifier import LocalTransactionClassifier
from free_llm_classifier import FreeLLMClassifier
from excel_generator import ExcelGenerator

# Import OpenAI classifier only when needed
def get_openai_classifier():
    from classifier import TransactionClassifier
    return TransactionClassifier()

def main():
    """Main function to orchestrate the transaction classification process"""
    
    print("🏦 Bank Statement Transaction Classifier")
    print("=" * 50)
    print("📋 LLM-powered classification for taxation purposes")
    print()
    
    # Load environment variables
    load_dotenv()
    
    # Set up paths
    project_root = Path(__file__).parent
    input_dir = project_root / "data" / "input"
    output_dir = project_root / "data" / "output"
    
    # Create directories if they don't exist
    input_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Parse command line arguments
    parser = argparse.ArgumentParser(description='Classify bank statement transactions using LLM')
    parser.add_argument('--file', '-f', type=str, help='Specific file to process')
    parser.add_argument('--preview', '-p', action='store_true', help='Preview file structure before processing')
    parser.add_argument('--csv-only', '-c', action='store_true', help='Generate only CSV output (no Excel)')
    parser.add_argument('--local-llm', '-l', action='store_true', help='Use local LLM (Ollama) instead of OpenAI')
    parser.add_argument('--rule-based', '-r', action='store_true', help='Use rule-based classification (no AI)')
    parser.add_argument('--free-llm', type=str, choices=['groq', 'google', 'huggingface', 'openai_free'], help='Use free LLM API (groq/google/huggingface/openai_free)')
    parser.add_argument('--model', '-m', type=str, default='llama3.1', help='Local model to use (default: llama3.1)')
    args = parser.parse_args()
    
    try:
        # Initialize components
        print("🔧 Initializing components...")
        reader = BankStatementReader()
        
        # Choose classifier based on arguments
        if args.rule_based:
            print("🔧 Using rule-based classification (no AI)")
            classifier = LocalTransactionClassifier(model_type="rule_based")
        elif args.local_llm:
            print(f"🦙 Using local LLM: {args.model}")
            classifier = LocalTransactionClassifier(model_type="ollama", model_name=args.model)
        elif args.free_llm:
            print(f"🆓 Using free LLM API: {args.free_llm}")
            classifier = FreeLLMClassifier(provider=args.free_llm)
        else:
            print("🤖 Using OpenAI API")
            classifier = get_openai_classifier()
            
        excel_generator = ExcelGenerator()
        print("✅ Components initialized successfully")
        print()
        
        # Find files to process
        if args.file:
            # Process specific file
            file_path = Path(args.file)
            if not file_path.exists():
                # Try relative to input directory
                file_path = input_dir / args.file
            
            if not file_path.exists():
                print(f"❌ File not found: {args.file}")
                return
            
            files_to_process = [file_path]
        else:
            # Process all supported files in input directory
            files_to_process = (
                list(input_dir.glob("*.csv")) +
                list(input_dir.glob("*.xlsx")) +
                list(input_dir.glob("*.xls"))
            )
        
        if not files_to_process:
            print(f"❌ No bank statement files found in {input_dir}")
            print("   Supported formats: CSV, Excel (xlsx/xls)")
            print(f"   Please place your files in: {input_dir}")
            return
        
        print(f"📁 Found {len(files_to_process)} file(s) to process:")
        for file in files_to_process:
            print(f"   • {file.name}")
        print()
        
        # Process each file
        for file_path in files_to_process:
            print(f"🔄 Processing: {file_path.name}")
            print("-" * 40)
            
            try:
                # Preview file if requested
                if args.preview:
                    print("👀 File preview:")
                    preview_df = reader.preview_file(file_path, rows=3)
                    print(preview_df)
                    print()
                    
                    response = input("Continue with processing? (y/n): ").lower().strip()
                    if response != 'y':
                        print("⏭️ Skipping file...")
                        continue
                
                # Step 1: Read transactions from file
                print("📖 Reading transactions...")
                transactions = reader.read_file(file_path)
                
                if not transactions:
                    print("⚠️ No transactions found in file. Skipping...")
                    continue
                
                print(f"   Found {len(transactions)} transactions")
                print()
                
                # Step 2: Classify transactions using LLM
                print("🤖 Classifying transactions with LLM...")
                classified_transactions = classifier.classify_transactions(transactions)
                print()
                
                # Step 3: Generate output files
                original_filename = file_path.stem
                
                if args.csv_only:
                    # Generate CSV only
                    csv_path = excel_generator.create_simple_csv(
                        classified_transactions, output_dir, original_filename
                    )
                    print(f"📄 CSV saved: {csv_path.name}")
                else:
                    # Generate Excel report
                    excel_path = excel_generator.generate_report(
                        classified_transactions, output_dir, original_filename
                    )
                    print(f"📊 Excel report saved: {excel_path.name}")
                
                # Show summary
                print()
                print("📈 Classification Summary:")
                show_classification_summary(classified_transactions)
                
                print(f"✅ Successfully processed: {file_path.name}")
                print()
                
            except Exception as e:
                print(f"❌ Error processing {file_path.name}: {str(e)}")
                print("   Check your OpenAI API key and file format.")
                continue
        
        print("🎉 All files processed successfully!")
        print(f"📂 Check output files in: {output_dir}")
        
    except KeyboardInterrupt:
        print("\n⏹️ Process interrupted by user")
    except Exception as e:
        print(f"💥 Fatal error: {str(e)}")
        return 1
    
    return 0

def show_classification_summary(classified_transactions):
    """Display a summary of classification results"""
    
    # Count by category
    category_counts = {}
    total_confidence = 0
    
    for transaction in classified_transactions:
        category = transaction.category
        category_counts[category] = category_counts.get(category, 0) + 1
        total_confidence += transaction.confidence
    
    # Show top categories
    sorted_categories = sorted(category_counts.items(), key=lambda x: x[1], reverse=True)
    
    print(f"   Total Transactions: {len(classified_transactions)}")
    print(f"   Average Confidence: {total_confidence / len(classified_transactions):.1%}")
    print(f"   Categories Found: {len(category_counts)}")
    print()
    print("   Top Categories:")
    for category, count in sorted_categories[:5]:
        print(f"     • {category}: {count} transactions")
    
    if len(sorted_categories) > 5:
        remaining = sum(count for _, count in sorted_categories[5:])
        print(f"     • Others: {remaining} transactions")

def setup_environment(use_local: bool = False):
    """Setup environment and check requirements"""
    
    if use_local:
        print("🏠 Using local classification - no API key needed!")
        return True
    
    # Check if OpenAI API key is available for cloud API
    if not os.getenv("OPENAI_API_KEY"):
        print("⚠️ OpenAI API Key Setup Required")
        print("=" * 40)
        print("You have several options:")
        print()
        print("1. 🏠 USE LOCAL AI (Recommended - Free!)")
        print("   python main.py --local-llm")
        print("   or")
        print("   python main.py --rule-based")
        print()
        print("2. 🌐 USE OPENAI API")
        print("   • Get API key from: https://platform.openai.com/api-keys")
        print("   • Create .env file with: OPENAI_API_KEY=your-key")
        print()
        
        choice = input("Choose (1 for local, 2 for OpenAI, Enter to exit): ").strip()
        if choice == "1":
            print("💡 Restart with: python main.py --local-llm")
            return False
        elif choice == "2":
            api_key = input("Enter your OpenAI API key: ").strip()
            if api_key:
                env_path = Path(__file__).parent / ".env"
                with open(env_path, "w") as f:
                    f.write(f"OPENAI_API_KEY={api_key}\n")
                print("✅ API key saved to .env file")
                load_dotenv()
                return True
        
        print("❌ Setup cancelled")
        return False
    
    return True

def create_sample_data():
    """Create sample bank statement data for testing"""
    
    sample_data = """Date,Narration,Chq./Ref.No.,Value Dt,Withdrawal Amt.,Deposit Amt.,Closing Balance
01/07/25,ACH C- ADANIENTFINAL2024 25-124981,0000000155407547,01/07/25,27.30,,466681.17
02/07/25,50100436622470-TPT-HRA PAYTM RENT-VIJAY KUMAR,0000000480643450,02/07/25,130000.00,,336681.17
03/07/25,SALARY CREDIT - TECH CORP,0000000480643451,03/07/25,,75000.00,411681.17
04/07/25,ATM WITHDRAWAL,0000000480643452,04/07/25,5000.00,,406681.17
05/07/25,MEDICAL EXPENSE - APOLLO HOSPITAL,0000000480643453,05/07/25,2500.00,,404181.17
06/07/25,ONLINE TRANSFER TO SAVINGS ACCOUNT,0000000480643454,06/07/25,50000.00,,354181.17
07/07/25,GST PAYMENT - QUARTERLY,0000000480643455,07/07/25,15000.00,,339181.17
08/07/25,DIVIDEND FROM MUTUAL FUND,0000000480643456,08/07/25,,3500.00,342681.17"""
    
    sample_path = Path(__file__).parent / "data" / "input" / "sample_statement.csv"
    sample_path.parent.mkdir(parents=True, exist_ok=True)
    
    with open(sample_path, "w") as f:
        f.write(sample_data)
    
    return sample_path

if __name__ == "__main__":
    # Parse args first to check if using local
    import argparse
    temp_parser = argparse.ArgumentParser()
    temp_parser.add_argument('--local-llm', '-l', action='store_true')
    temp_parser.add_argument('--rule-based', '-r', action='store_true')
    temp_parser.add_argument('--free-llm', type=str, choices=['groq', 'google', 'huggingface', 'openai_free'])
    temp_args, _ = temp_parser.parse_known_args()
    
    use_local = temp_args.local_llm or temp_args.rule_based or temp_args.free_llm
    
    # Setup environment
    if not setup_environment(use_local):
        sys.exit(1)
    
    # Check if no input files exist and offer to create sample
    input_dir = Path(__file__).parent / "data" / "input"
    if not any(input_dir.glob("*")):
        print("📄 No input files found. Creating sample data for testing...")
        sample_path = create_sample_data()
        print(f"✅ Sample data created: {sample_path.name}")
        print()
    
    # Run main process
    exit_code = main()
    sys.exit(exit_code)
