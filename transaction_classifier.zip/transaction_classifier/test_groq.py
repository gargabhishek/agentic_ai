#!/usr/bin/env python3
"""
Test Groq API key and debug the issue
"""

import os
import requests
import json
from dotenv import load_dotenv

def test_groq_api():
    """Test if Groq API key works"""
    
    print("🔍 Testing Groq API key...")
    
    # Load environment variables
    load_dotenv()
    
    api_key = os.getenv("GROQ_API_KEY")
    if not api_key:
        print("❌ No GROQ_API_KEY found in .env file")
        return False
    
    print(f"✅ API key found: {api_key[:8]}...{api_key[-8:]}")
    
    # Test API endpoint
    url = "https://api.groq.com/openai/v1/chat/completions"
    
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    
    # Simple test request
    payload = {
        "messages": [
            {"role": "user", "content": "Classify this transaction: UPI-ZEPTO for groceries. Return JSON with category and confidence."}
        ],
        "model": "llama-3.1-8b-instant",
        "temperature": 0.1,
        "max_tokens": 100
    }
    
    try:
        print("🚀 Testing API call...")
        response = requests.post(url, json=payload, headers=headers, timeout=10)
        
        print(f"📡 Response Status: {response.status_code}")
        
        if response.status_code == 200:
            result = response.json()
            print("✅ API call successful!")
            print(f"📄 Response: {result['choices'][0]['message']['content']}")
            return True
        else:
            print("❌ API call failed!")
            print(f"📄 Error response: {response.text}")
            
            # Check for common issues
            if response.status_code == 401:
                print("🔑 Issue: Invalid API key")
            elif response.status_code == 400:
                print("📝 Issue: Bad request format")
            elif response.status_code == 429:
                print("⏰ Issue: Rate limit exceeded")
                
            return False
            
    except Exception as e:
        print(f"💥 Exception: {str(e)}")
        return False

def show_env_format():
    """Show correct .env file format"""
    
    print("\n📝 Correct .env file format:")
    print("=" * 30)
    print("GROQ_API_KEY=gsk_your_actual_key_here")
    print("GOOGLE_AI_API_KEY=your_google_key_here")
    print("OPENAI_API_KEY=sk-your_openai_key_here")
    print()
    print("💡 Your .env file should be in:")
    print("   /Users/abhishekgarg/Documents/Bitbucket/bank_statement_analyse/transaction_classifier/.env")

if __name__ == "__main__":
    success = test_groq_api()
    
    if not success:
        print("\n🔧 Troubleshooting suggestions:")
        print("1. Check your API key at: https://console.groq.com")
        print("2. Make sure your key starts with 'gsk_'")
        print("3. Try regenerating your API key")
        print("4. Check if you have free credits remaining")
        
    show_env_format()
