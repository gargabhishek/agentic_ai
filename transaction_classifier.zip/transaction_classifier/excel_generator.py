#!/usr/bin/env python3
"""
Excel Output Generator
Creates Excel files with classified transactions and summary reports
"""

import pandas as pd
from pathlib import Path
from typing import List, Dict
from datetime import datetime
import xlsxwriter
from xlsxwriter.utility import xl_rowcol_to_cell

from transaction_types import ClassifiedTransaction

class ExcelGenerator:
    """Generate Excel reports for classified transactions"""
    
    def __init__(self):
        """Initialize the Excel generator"""
        pass
    
    def generate_report(self, 
                       classified_transactions: List[ClassifiedTransaction],
                       output_path: Path,
                       original_filename: str = "bank_statement") -> Path:
        """
        Generate comprehensive Excel report with classified transactions
        
        Args:
            classified_transactions: List of classified transactions
            output_path: Directory to save the Excel file
            original_filename: Original filename (without extension)
            
        Returns:
            Path to the generated Excel file
        """
        
        # Generate timestamp for unique filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        excel_filename = f"classified_{original_filename}_{timestamp}.xlsx"
        excel_path = output_path / excel_filename
        
        print(f"📊 Generating Excel report: {excel_filename}")
        
        # Create workbook with multiple sheets
        with xlsxwriter.Workbook(str(excel_path)) as workbook:
            # Create sheets
            self._create_transactions_sheet(workbook, classified_transactions)
            self._create_category_summary_sheet(workbook, classified_transactions)
            self._create_monthly_summary_sheet(workbook, classified_transactions)
            self._create_tax_summary_sheet(workbook, classified_transactions)
        
        print(f"✅ Excel report saved: {excel_path}")
        return excel_path
    
    def _create_transactions_sheet(self, workbook, classified_transactions: List[ClassifiedTransaction]):
        """Create detailed transactions sheet"""
        
        worksheet = workbook.add_worksheet('All Transactions')
        
        # Define formats
        header_format = workbook.add_format({
            'bold': True,
            'bg_color': '#4F81BD',
            'font_color': 'white',
            'border': 1,
            'align': 'center'
        })
        
        currency_format = workbook.add_format({'num_format': '₹#,##0.00'})
        date_format = workbook.add_format({'num_format': 'dd/mm/yyyy'})
        confidence_format = workbook.add_format({'num_format': '0.0%'})
        
        # Define headers
        headers = [
            'Date', 'Narration', 'Chq/Ref No', 'Value Date',
            'Withdrawal', 'Deposit', 'Balance', 'Category', 
            'Confidence', 'Reasoning'
        ]
        
        # Write headers
        for col, header in enumerate(headers):
            worksheet.write(0, col, header, header_format)
        
        # Write data
        for row, transaction in enumerate(classified_transactions, start=1):
            worksheet.write(row, 0, transaction.date, date_format)
            worksheet.write(row, 1, transaction.narration)
            worksheet.write(row, 2, transaction.chq_ref_no)
            worksheet.write(row, 3, transaction.value_date, date_format)
            worksheet.write(row, 4, transaction.withdrawal_amt, currency_format)
            worksheet.write(row, 5, transaction.deposit_amt, currency_format)
            worksheet.write(row, 6, transaction.closing_balance, currency_format)
            worksheet.write(row, 7, transaction.category)
            worksheet.write(row, 8, transaction.confidence, confidence_format)
            worksheet.write(row, 9, transaction.reasoning)
        
        # Auto-adjust column widths
        worksheet.set_column('A:A', 12)  # Date
        worksheet.set_column('B:B', 50)  # Narration
        worksheet.set_column('C:C', 20)  # Chq/Ref
        worksheet.set_column('D:D', 12)  # Value Date
        worksheet.set_column('E:G', 15)  # Amounts
        worksheet.set_column('H:H', 20)  # Category
        worksheet.set_column('I:I', 12)  # Confidence
        worksheet.set_column('J:J', 30)  # Reasoning
        
        # Add filters
        worksheet.autofilter(0, 0, len(classified_transactions), len(headers) - 1)
        
        return worksheet
    
    def _create_category_summary_sheet(self, workbook, classified_transactions: List[ClassifiedTransaction]):
        """Create category-wise summary sheet"""
        
        worksheet = workbook.add_worksheet('Category Summary')
        
        # Prepare data
        category_data = self._analyze_by_category(classified_transactions)
        
        # Define formats
        header_format = workbook.add_format({
            'bold': True,
            'bg_color': '#4F81BD',
            'font_color': 'white',
            'border': 1,
            'align': 'center'
        })
        
        currency_format = workbook.add_format({'num_format': '₹#,##0.00'})
        bold_format = workbook.add_format({'bold': True})
        
        # Write headers
        headers = ['Category', 'Count', 'Total Withdrawal', 'Total Deposit', 'Net Amount', 'Avg Confidence']
        for col, header in enumerate(headers):
            worksheet.write(0, col, header, header_format)
        
        # Write category data
        row = 1
        for category, data in sorted(category_data.items()):
            worksheet.write(row, 0, category)
            worksheet.write(row, 1, data['count'])
            worksheet.write(row, 2, data['total_withdrawal'], currency_format)
            worksheet.write(row, 3, data['total_deposit'], currency_format)
            worksheet.write(row, 4, data['net_amount'], currency_format)
            worksheet.write(row, 5, data['avg_confidence'], workbook.add_format({'num_format': '0.0%'}))
            row += 1
        
        # Add totals row
        total_count = sum(data['count'] for data in category_data.values())
        total_withdrawal = sum(data['total_withdrawal'] for data in category_data.values())
        total_deposit = sum(data['total_deposit'] for data in category_data.values())
        total_net = sum(data['net_amount'] for data in category_data.values())
        
        worksheet.write(row, 0, 'TOTAL', bold_format)
        worksheet.write(row, 1, total_count, bold_format)
        worksheet.write(row, 2, total_withdrawal, [currency_format, bold_format])
        worksheet.write(row, 3, total_deposit, [currency_format, bold_format])
        worksheet.write(row, 4, total_net, [currency_format, bold_format])
        
        # Auto-adjust column widths
        worksheet.set_column('A:A', 25)  # Category
        worksheet.set_column('B:F', 15)  # Numbers
        
        # Add chart
        self._add_category_chart(workbook, worksheet, len(category_data))
        
        return worksheet
    
    def _create_monthly_summary_sheet(self, workbook, classified_transactions: List[ClassifiedTransaction]):
        """Create month-wise summary sheet"""
        
        worksheet = workbook.add_worksheet('Monthly Summary')
        
        # Prepare monthly data
        monthly_data = self._analyze_by_month(classified_transactions)
        
        # Define formats
        header_format = workbook.add_format({
            'bold': True,
            'bg_color': '#4F81BD',
            'font_color': 'white',
            'border': 1,
            'align': 'center'
        })
        
        currency_format = workbook.add_format({'num_format': '₹#,##0.00'})
        
        # Write headers
        headers = ['Month', 'Transactions', 'Total Withdrawal', 'Total Deposit', 'Net Amount']
        for col, header in enumerate(headers):
            worksheet.write(0, col, header, header_format)
        
        # Write monthly data
        for row, (month, data) in enumerate(sorted(monthly_data.items()), start=1):
            worksheet.write(row, 0, month)
            worksheet.write(row, 1, data['count'])
            worksheet.write(row, 2, data['total_withdrawal'], currency_format)
            worksheet.write(row, 3, data['total_deposit'], currency_format)
            worksheet.write(row, 4, data['net_amount'], currency_format)
        
        # Auto-adjust column widths
        worksheet.set_column('A:E', 15)
        
        return worksheet
    
    def _create_tax_summary_sheet(self, workbook, classified_transactions: List[ClassifiedTransaction]):
        """Create tax-relevant summary sheet"""
        
        worksheet = workbook.add_worksheet('Tax Summary')
        
        # Define tax categories
        tax_categories = {
            'INCOME': ['SALARY_INCOME', 'BUSINESS_INCOME', 'DIVIDEND_INCOME', 'INTEREST_INCOME', 'HRA_RECEIVED'],
            'DEDUCTIBLE_EXPENSES': ['HRA_PAYMENT', 'MEDICAL_EXPENSE', 'EDUCATION_EXPENSE', 'INSURANCE_PREMIUM', 'DONATION'],
            'BUSINESS_EXPENSES': ['OFFICE_EXPENSE', 'BUSINESS_EXPENSE', 'PROFESSIONAL_FEES'],
            'INVESTMENTS': ['INVESTMENT'],
            'TAX_PAYMENTS': ['TAX_PAYMENT'],
            'NON_DEDUCTIBLE': ['PERSONAL_EXPENSE', 'CASH_WITHDRAWAL', 'SELF_TRANSFER']
        }
        
        # Calculate tax summary
        tax_summary = {}
        for tax_group, categories in tax_categories.items():
            tax_summary[tax_group] = {
                'withdrawal': 0,
                'deposit': 0,
                'net': 0,
                'count': 0
            }
            
            for transaction in classified_transactions:
                if transaction.category in categories:
                    tax_summary[tax_group]['withdrawal'] += transaction.withdrawal_amt
                    tax_summary[tax_group]['deposit'] += transaction.deposit_amt
                    tax_summary[tax_group]['net'] += (transaction.deposit_amt - transaction.withdrawal_amt)
                    tax_summary[tax_group]['count'] += 1
        
        # Define formats
        header_format = workbook.add_format({
            'bold': True,
            'bg_color': '#4F81BD',
            'font_color': 'white',
            'border': 1,
            'align': 'center'
        })
        
        currency_format = workbook.add_format({'num_format': '₹#,##0.00'})
        
        # Write headers
        headers = ['Tax Category', 'Count', 'Total Withdrawal', 'Total Deposit', 'Net Amount']
        for col, header in enumerate(headers):
            worksheet.write(0, col, header, header_format)
        
        # Write tax summary
        for row, (tax_group, data) in enumerate(tax_summary.items(), start=1):
            worksheet.write(row, 0, tax_group)
            worksheet.write(row, 1, data['count'])
            worksheet.write(row, 2, data['withdrawal'], currency_format)
            worksheet.write(row, 3, data['deposit'], currency_format)
            worksheet.write(row, 4, data['net'], currency_format)
        
        # Auto-adjust column widths
        worksheet.set_column('A:A', 25)
        worksheet.set_column('B:E', 15)
        
        return worksheet
    
    def _analyze_by_category(self, classified_transactions: List[ClassifiedTransaction]) -> Dict:
        """Analyze transactions by category"""
        
        category_data = {}
        
        for transaction in classified_transactions:
            category = transaction.category
            
            if category not in category_data:
                category_data[category] = {
                    'count': 0,
                    'total_withdrawal': 0,
                    'total_deposit': 0,
                    'net_amount': 0,
                    'confidences': []
                }
            
            data = category_data[category]
            data['count'] += 1
            data['total_withdrawal'] += transaction.withdrawal_amt
            data['total_deposit'] += transaction.deposit_amt
            data['net_amount'] += (transaction.deposit_amt - transaction.withdrawal_amt)
            data['confidences'].append(transaction.confidence)
        
        # Calculate average confidence
        for category in category_data:
            confidences = category_data[category]['confidences']
            category_data[category]['avg_confidence'] = sum(confidences) / len(confidences) if confidences else 0
            del category_data[category]['confidences']  # Remove temporary list
        
        return category_data
    
    def _analyze_by_month(self, classified_transactions: List[ClassifiedTransaction]) -> Dict:
        """Analyze transactions by month"""
        
        monthly_data = {}
        
        for transaction in classified_transactions:
            try:
                # Extract month from date
                if '/' in transaction.date:
                    parts = transaction.date.split('/')
                    if len(parts) >= 3:
                        month_year = f"{parts[1]}/{parts[2]}"  # MM/YYYY format
                    else:
                        month_year = "Unknown"
                else:
                    month_year = "Unknown"
                
                if month_year not in monthly_data:
                    monthly_data[month_year] = {
                        'count': 0,
                        'total_withdrawal': 0,
                        'total_deposit': 0,
                        'net_amount': 0
                    }
                
                data = monthly_data[month_year]
                data['count'] += 1
                data['total_withdrawal'] += transaction.withdrawal_amt
                data['total_deposit'] += transaction.deposit_amt
                data['net_amount'] += (transaction.deposit_amt - transaction.withdrawal_amt)
                
            except:
                # Handle date parsing errors
                continue
        
        return monthly_data
    
    def _add_category_chart(self, workbook, worksheet, data_rows):
        """Add a pie chart for category distribution"""
        
        # Create chart
        chart = workbook.add_chart({'type': 'pie'})
        
        # Configure chart
        chart.add_series({
            'name': 'Category Distribution',
            'categories': ['Category Summary', 1, 0, data_rows, 0],
            'values': ['Category Summary', 1, 1, data_rows, 1],
            'data_labels': {'percentage': True}
        })
        
        # Chart formatting
        chart.set_title({'name': 'Transaction Category Distribution'})
        chart.set_size({'width': 720, 'height': 576})
        
        # Insert chart
        worksheet.insert_chart('H2', chart)
    
    def create_simple_csv(self, 
                         classified_transactions: List[ClassifiedTransaction],
                         output_path: Path,
                         original_filename: str = "bank_statement") -> Path:
        """
        Create simple CSV output for basic usage
        
        Args:
            classified_transactions: List of classified transactions
            output_path: Directory to save the CSV file
            original_filename: Original filename (without extension)
            
        Returns:
            Path to the generated CSV file
        """
        
        # Generate timestamp for unique filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        csv_filename = f"classified_{original_filename}_{timestamp}.csv"
        csv_path = output_path / csv_filename
        
        print(f"📄 Generating CSV report: {csv_filename}")
        
        # Convert to pandas DataFrame
        data = []
        for transaction in classified_transactions:
            data.append({
                'Date': transaction.date,
                'Narration': transaction.narration,
                'Chq_Ref_No': transaction.chq_ref_no,
                'Value_Date': transaction.value_date,
                'Withdrawal_Amt': transaction.withdrawal_amt,
                'Deposit_Amt': transaction.deposit_amt,
                'Closing_Balance': transaction.closing_balance,
                'Category': transaction.category,
                'Confidence': transaction.confidence,
                'Reasoning': transaction.reasoning
            })
        
        df = pd.DataFrame(data)
        df.to_csv(csv_path, index=False)
        
        print(f"✅ CSV report saved: {csv_path}")
        return csv_path

# Example usage and testing
if __name__ == "__main__":
    print("📊 ExcelGenerator initialized and ready to use!")
