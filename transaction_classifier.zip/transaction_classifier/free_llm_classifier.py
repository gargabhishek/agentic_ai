#!/usr/bin/env python3
"""
Free LLM Transaction Classifier
Uses free API services like Groq, Google AI Studio, etc.
"""

import json
import requests
from typing import List, Dict, Optional
import os
from dotenv import load_dotenv

from transaction_types import Transaction, ClassifiedTransaction

class FreeLLMClassifier:
    """Free LLM-based transaction classifier using various free APIs"""
    
    # Same categories as before
    CATEGORIES = {
        "SALARY_INCOME": "Salary income from employer",
        "BUSINESS_INCOME": "Business or professional income", 
        "HRA_PAYMENT": "HRA (House Rent Allowance) payment made",
        "HRA_RECEIVED": "HRA received from employer",
        "OFFICE_EXPENSE": "Office-related expenses (rent, utilities, supplies)",
        "BUSINESS_EXPENSE": "Business expenses (travel, meals, equipment)",
        "PERSONAL_EXPENSE": "Personal expenses (shopping, entertainment)",
        "MEDICAL_EXPENSE": "Medical and healthcare expenses",
        "EDUCATION_EXPENSE": "Education-related expenses",
        "INVESTMENT": "Investment in stocks, mutual funds, FD, etc.",
        "LOAN_EMI": "Loan EMI payments (home, car, personal)",
        "INSURANCE_PREMIUM": "Insurance premium payments",
        "TAX_PAYMENT": "Income tax, GST, or other tax payments",
        "SALARY_PAID": "Salary paid to employees",
        "PROFESSIONAL_FEES": "Professional services fees paid",
        "SELF_TRANSFER": "Transfer between own accounts",
        "FAMILY_TRANSFER": "Transfer to/from family members",
        "CASH_WITHDRAWAL": "ATM or cash withdrawals",
        "DIVIDEND_INCOME": "Dividend received",
        "INTEREST_INCOME": "Interest earned on deposits",
        "REFUND": "Refunds received",
        "PENALTY_FINE": "Penalties or fines paid",
        "DONATION": "Charitable donations",
        "OTHER": "Other transactions not fitting above categories"
    }
    
    def __init__(self, provider: str = "groq"):
        """
        Initialize with free LLM provider
        
        Args:
            provider: "groq", "google", "huggingface", "openai_free"
        """
        load_dotenv()
        self.provider = provider
        self.api_key = None
        
        if provider == "groq":
            self.api_key = os.getenv("GROQ_API_KEY")
            self.api_url = "https://api.groq.com/openai/v1/chat/completions"
            self.model = "llama-3.1-8b-instant"  # Current available model
            
        elif provider == "google":
            self.api_key = os.getenv("GOOGLE_AI_API_KEY") 
            self.api_url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key={self.api_key}"
            self.model = "gemini-1.5-flash"
            
        elif provider == "huggingface":
            self.api_key = os.getenv("HUGGINGFACE_API_KEY")
            self.api_url = "https://api-inference.huggingface.co/models/meta-llama/Llama-2-70b-chat-hf"
            self.model = "llama2-70b"
            
        elif provider == "openai_free":
            self.api_key = os.getenv("OPENAI_API_KEY")
            self.api_url = "https://api.openai.com/v1/chat/completions"
            self.model = "gpt-3.5-turbo"
        
        if not self.api_key:
            print(f"⚠️ {provider.upper()} API key not found!")
            print(f"   Set {provider.upper()}_API_KEY in .env file")
    
    def classify_transaction(self, transaction: Transaction) -> ClassifiedTransaction:
        """Classify a single transaction using free LLM API"""
        
        try:
            if self.provider == "groq":
                return self._classify_with_groq(transaction)
            elif self.provider == "google":
                return self._classify_with_google(transaction)
            elif self.provider == "huggingface":
                return self._classify_with_huggingface(transaction)
            else:
                return self._classify_with_openai(transaction)
                
        except Exception as e:
            print(f"⚠️ API error: {str(e)}")
            # Fallback to basic rule-based
            return self._basic_fallback(transaction)
    
    def _classify_with_groq(self, transaction: Transaction) -> ClassifiedTransaction:
        """Classify using Groq API (fast and free!)"""
        
        prompt = self._create_classification_prompt(transaction)
        
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "messages": [
                {"role": "system", "content": "You are a financial expert specializing in transaction categorization for taxation purposes in India."},
                {"role": "user", "content": prompt}
            ],
            "model": self.model,
            "temperature": 0.1,
            "max_tokens": 150
        }
        
        response = requests.post(self.api_url, json=payload, headers=headers, timeout=10)
        
        if response.status_code == 200:
            result_text = response.json()["choices"][0]["message"]["content"]
            result = self._parse_llm_response(result_text)
            
            return ClassifiedTransaction(
                date=transaction.date,
                narration=transaction.narration,
                chq_ref_no=transaction.chq_ref_no,
                value_date=transaction.value_date,
                withdrawal_amt=transaction.withdrawal_amt,
                deposit_amt=transaction.deposit_amt,
                closing_balance=transaction.closing_balance,
                category=result["category"],
                confidence=result["confidence"],
                reasoning=result["reasoning"]
            )
        else:
            raise Exception(f"Groq API error: {response.status_code}")
    
    def _classify_with_google(self, transaction: Transaction) -> ClassifiedTransaction:
        """Classify using Google Gemini API"""
        
        prompt = self._create_classification_prompt(transaction)
        
        payload = {
            "contents": [
                {
                    "parts": [
                        {"text": f"You are a financial expert. {prompt}"}
                    ]
                }
            ]
        }
        
        response = requests.post(self.api_url, json=payload, timeout=10)
        
        if response.status_code == 200:
            result_text = response.json()["candidates"][0]["content"]["parts"][0]["text"]
            result = self._parse_llm_response(result_text)
            
            return ClassifiedTransaction(
                date=transaction.date,
                narration=transaction.narration,
                chq_ref_no=transaction.chq_ref_no,
                value_date=transaction.value_date,
                withdrawal_amt=transaction.withdrawal_amt,
                deposit_amt=transaction.deposit_amt,
                closing_balance=transaction.closing_balance,
                category=result["category"],
                confidence=result["confidence"],
                reasoning=result["reasoning"]
            )
        else:
            raise Exception(f"Google AI error: {response.status_code}")
    
    def _classify_with_huggingface(self, transaction: Transaction) -> ClassifiedTransaction:
        """Classify using Hugging Face Inference API"""
        
        prompt = self._create_classification_prompt(transaction)
        
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "inputs": prompt,
            "parameters": {
                "max_new_tokens": 150,
                "temperature": 0.1
            }
        }
        
        response = requests.post(self.api_url, json=payload, headers=headers, timeout=30)
        
        if response.status_code == 200:
            result_text = response.json()[0]["generated_text"]
            # Extract only the new part after the prompt
            result_text = result_text[len(prompt):].strip()
            result = self._parse_llm_response(result_text)
            
            return ClassifiedTransaction(
                date=transaction.date,
                narration=transaction.narration,
                chq_ref_no=transaction.chq_ref_no,
                value_date=transaction.value_date,
                withdrawal_amt=transaction.withdrawal_amt,
                deposit_amt=transaction.deposit_amt,
                closing_balance=transaction.closing_balance,
                category=result["category"],
                confidence=result["confidence"],
                reasoning=result["reasoning"]
            )
        else:
            raise Exception(f"Hugging Face error: {response.status_code}")
    
    def _classify_with_openai(self, transaction: Transaction) -> ClassifiedTransaction:
        """Classify using OpenAI API (for free credits)"""
        
        prompt = self._create_classification_prompt(transaction)
        
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "model": "gpt-3.5-turbo",
            "messages": [
                {"role": "system", "content": "You are a financial expert specializing in transaction categorization for taxation purposes in India."},
                {"role": "user", "content": prompt}
            ],
            "temperature": 0.1,
            "max_tokens": 150
        }
        
        response = requests.post(self.api_url, json=payload, headers=headers, timeout=10)
        
        if response.status_code == 200:
            result_text = response.json()["choices"][0]["message"]["content"]
            result = self._parse_llm_response(result_text)
            
            return ClassifiedTransaction(
                date=transaction.date,
                narration=transaction.narration,
                chq_ref_no=transaction.chq_ref_no,
                value_date=transaction.value_date,
                withdrawal_amt=transaction.withdrawal_amt,
                deposit_amt=transaction.deposit_amt,
                closing_balance=transaction.closing_balance,
                category=result["category"],
                confidence=result["confidence"],
                reasoning=result["reasoning"]
            )
        else:
            raise Exception(f"OpenAI error: {response.status_code}")
    
    def _create_classification_prompt(self, transaction: Transaction) -> str:
        """Create prompt for LLM classification"""
        
        amount = transaction.withdrawal_amt if transaction.withdrawal_amt > 0 else transaction.deposit_amt
        transaction_type = "Withdrawal" if transaction.withdrawal_amt > 0 else "Deposit"
        
        categories_list = "\n".join([f"- {key}: {desc}" for key, desc in self.CATEGORIES.items()])
        
        prompt = f"""Analyze this Indian bank transaction and classify it for taxation purposes:

TRANSACTION:
- Date: {transaction.date}
- Description: {transaction.narration}
- Type: {transaction_type}
- Amount: ₹{amount:,.2f}

CATEGORIES:
{categories_list}

Return ONLY JSON:
{{
    "category": "CATEGORY_NAME",
    "confidence": 0.95,
    "reasoning": "Brief explanation"
}}

Consider Indian UPI patterns, merchant names, and context."""
        
        return prompt
    
    def _parse_llm_response(self, response: str) -> Dict:
        """Parse LLM response and extract classification"""
        
        try:
            # Clean response
            response = response.strip()
            if response.startswith("```json"):
                response = response[7:]
            if response.endswith("```"):
                response = response[:-3]
            
            # Find JSON part
            start = response.find('{')
            end = response.rfind('}') + 1
            if start >= 0 and end > start:
                response = response[start:end]
            
            result = json.loads(response)
            
            # Validate
            if result["category"] not in self.CATEGORIES:
                result["category"] = "OTHER"
            
            if not (0 <= result.get("confidence", 0.5) <= 1):
                result["confidence"] = 0.7
                
            return result
            
        except Exception as e:
            return {
                "category": "OTHER",
                "confidence": 0.3,
                "reasoning": f"Parse error: {str(e)}"
            }
    
    def _basic_fallback(self, transaction: Transaction) -> ClassifiedTransaction:
        """Basic fallback classification"""
        
        narration = transaction.narration.lower()
        
        # Basic patterns
        if "salary" in narration:
            category, confidence = "SALARY_INCOME", 0.8
        elif "atm" in narration or "cash" in narration:
            category, confidence = "CASH_WITHDRAWAL", 0.8
        elif "medical" in narration or "hospital" in narration:
            category, confidence = "MEDICAL_EXPENSE", 0.8
        elif "tax" in narration or "gst" in narration:
            category, confidence = "TAX_PAYMENT", 0.8
        else:
            category, confidence = "OTHER", 0.3
        
        return ClassifiedTransaction(
            date=transaction.date,
            narration=transaction.narration,
            chq_ref_no=transaction.chq_ref_no,
            value_date=transaction.value_date,
            withdrawal_amt=transaction.withdrawal_amt,
            deposit_amt=transaction.deposit_amt,
            closing_balance=transaction.closing_balance,
            category=category,
            confidence=confidence,
            reasoning="Fallback classification"
        )
    
    def classify_transactions(self, transactions: List[Transaction]) -> List[ClassifiedTransaction]:
        """Classify multiple transactions"""
        
        classified = []
        print(f"🔄 Classifying {len(transactions)} transactions using {self.provider}...")
        
        for i, transaction in enumerate(transactions, 1):
            print(f"   Processing transaction {i}/{len(transactions)}")
            classified_transaction = self.classify_transaction(transaction)
            classified.append(classified_transaction)
            
            # Better rate limiting for free tiers
            import time
            if i % 5 == 0:  # Every 5 requests
                time.sleep(3)  # 3 second pause
            else:
                time.sleep(0.5)  # Small delay between each request
        
        print("✅ Classification completed!")
        return classified

# Setup guide
def show_free_api_setup():
    print("""
🆓 FREE LLM API SETUP GUIDE
===========================

Choose ONE option:

🚀 OPTION 1: GROQ (Recommended - Super Fast)
   1. Go to: https://console.groq.com
   2. Sign up (free)
   3. Get API key
   4. Add to .env: GROQ_API_KEY=your-key-here
   5. Run: python main.py --free-llm groq

🔵 OPTION 2: GOOGLE AI STUDIO
   1. Go to: https://ai.google.dev
   2. Get API key (free)
   3. Add to .env: GOOGLE_AI_API_KEY=your-key-here
   4. Run: python main.py --free-llm google

🤗 OPTION 3: HUGGING FACE
   1. Go to: https://huggingface.co/settings/tokens
   2. Create token (free)
   3. Add to .env: HUGGINGFACE_API_KEY=your-token-here
   4. Run: python main.py --free-llm huggingface

💰 OPTION 4: OPENAI FREE CREDITS
   1. New users get $5 free at: https://platform.openai.com
   2. Add to .env: OPENAI_API_KEY=your-key-here
   3. Run: python main.py --csv-only

All options are FREE and give MUCH better results than rule-based!
""")

if __name__ == "__main__":
    show_free_api_setup()
