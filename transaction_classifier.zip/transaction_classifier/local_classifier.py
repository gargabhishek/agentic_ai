#!/usr/bin/env python3
"""
Local LLM Transaction Classifier
Uses local models (Ollama) or Hugging Face models instead of OpenAI API
No API key required!
"""

import json
from typing import List, Dict, Optional
from dataclasses import dataclass
import requests
import os
from pathlib import Path

# Import the transaction classes
from transaction_types import Transaction, ClassifiedTransaction

class LocalTransactionClassifier:
    """Local LLM-based transaction classifier - no API key needed!"""
    
    # Same categories as the original classifier
    CATEGORIES = {
        "SALARY_INCOME": "Salary income from employer",
        "BUSINESS_INCOME": "Business or professional income",
        "HRA_PAYMENT": "HRA (House Rent Allowance) payment made",
        "HRA_RECEIVED": "HRA received from employer",
        "OFFICE_EXPENSE": "Office-related expenses (rent, utilities, supplies)",
        "BUSINESS_EXPENSE": "Business expenses (travel, meals, equipment)",
        "PERSONAL_EXPENSE": "Personal expenses (shopping, entertainment)",
        "MEDICAL_EXPENSE": "Medical and healthcare expenses",
        "EDUCATION_EXPENSE": "Education-related expenses",
        "INVESTMENT": "Investment in stocks, mutual funds, FD, etc.",
        "LOAN_EMI": "Loan EMI payments (home, car, personal)",
        "INSURANCE_PREMIUM": "Insurance premium payments",
        "TAX_PAYMENT": "Income tax, GST, or other tax payments",
        "SALARY_PAID": "Salary paid to employees",
        "PROFESSIONAL_FEES": "Professional services fees paid",
        "SELF_TRANSFER": "Transfer between own accounts",
        "FAMILY_TRANSFER": "Transfer to/from family members",
        "CASH_WITHDRAWAL": "ATM or cash withdrawals",
        "DIVIDEND_INCOME": "Dividend received",
        "INTEREST_INCOME": "Interest earned on deposits",
        "REFUND": "Refunds received",
        "PENALTY_FINE": "Penalties or fines paid",
        "DONATION": "Charitable donations",
        "OTHER": "Other transactions not fitting above categories"
    }
    
    def __init__(self, model_type: str = "ollama", model_name: str = "llama3.1"):
        """
        Initialize local classifier
        
        Args:
            model_type: "ollama", "huggingface", or "rule_based"
            model_name: Name of the model to use
        """
        self.model_type = model_type
        self.model_name = model_name
        
        if model_type == "ollama":
            self.ollama_url = "http://localhost:11434/api/generate"
            self._check_ollama_connection()
        elif model_type == "rule_based":
            self._setup_rule_patterns()
    
    def _check_ollama_connection(self):
        """Check if Ollama is running and model is available"""
        try:
            response = requests.get("http://localhost:11434/api/tags", timeout=5)
            if response.status_code == 200:
                models = [model["name"] for model in response.json().get("models", [])]
                if self.model_name not in models:
                    print(f"⚠️ Model '{self.model_name}' not found. Available models: {models}")
                    print(f"💡 Install with: ollama pull {self.model_name}")
                else:
                    print(f"✅ Connected to Ollama with model: {self.model_name}")
            else:
                print("❌ Ollama is running but not responding properly")
        except requests.exceptions.RequestException:
            print("❌ Ollama not running. Please start with: ollama serve")
            print("💡 Or install from: https://ollama.ai/")
    
    def _setup_rule_patterns(self):
        """Setup rule-based classification patterns"""
        self.rule_patterns = {
            "SALARY_INCOME": ["salary", "pay credit", "salary credit", "monthly pay"],
            "HRA_PAYMENT": ["hra", "rent", "paytm rent", "house rent"],
            "HRA_RECEIVED": ["hra received", "hra credit"],
            "BUSINESS_EXPENSE": ["business", "office", "professional", "services"],
            "MEDICAL_EXPENSE": ["medical", "hospital", "doctor", "pharmacy", "health"],
            "ATM_WITHDRAWAL": ["atm", "cash withdrawal", "withdrawal"],
            "SELF_TRANSFER": ["transfer", "neft", "imps", "own account"],
            "TAX_PAYMENT": ["tax", "gst", "income tax", "tds"],
            "INVESTMENT": ["mutual fund", "sip", "investment", "equity", "dividend"],
            "INSURANCE_PREMIUM": ["insurance", "premium", "policy"],
            "PERSONAL_EXPENSE": ["shopping", "online", "amazon", "flipkart"],
        }
    
    def classify_transaction(self, transaction: Transaction) -> ClassifiedTransaction:
        """Classify a single transaction"""
        
        if self.model_type == "ollama":
            return self._classify_with_ollama(transaction)
        elif self.model_type == "rule_based":
            return self._classify_with_rules(transaction)
        else:
            # Fallback to rule-based
            return self._classify_with_rules(transaction)
    
    def _classify_with_ollama(self, transaction: Transaction) -> ClassifiedTransaction:
        """Classify using Ollama local LLM"""
        
        prompt = self._create_classification_prompt(transaction)
        
        try:
            payload = {
                "model": self.model_name,
                "prompt": prompt,
                "stream": False,
                "format": "json"
            }
            
            response = requests.post(self.ollama_url, json=payload, timeout=30)
            
            if response.status_code == 200:
                result_text = response.json().get("response", "{}")
                result = self._parse_llm_response(result_text)
                
                return ClassifiedTransaction(
                    date=transaction.date,
                    narration=transaction.narration,
                    chq_ref_no=transaction.chq_ref_no,
                    value_date=transaction.value_date,
                    withdrawal_amt=transaction.withdrawal_amt,
                    deposit_amt=transaction.deposit_amt,
                    closing_balance=transaction.closing_balance,
                    category=result["category"],
                    confidence=result["confidence"],
                    reasoning=result["reasoning"]
                )
            else:
                print(f"⚠️ Ollama API error, falling back to rules")
                return self._classify_with_rules(transaction)
                
        except Exception as e:
            print(f"⚠️ Ollama error: {str(e)}, falling back to rules")
            return self._classify_with_rules(transaction)
    
    def _classify_with_rules(self, transaction: Transaction) -> ClassifiedTransaction:
        """Classify using rule-based patterns"""
        
        narration = transaction.narration.lower()
        best_category = "OTHER"
        best_confidence = 0.5
        reasoning = "Rule-based classification"
        
        # Check each category pattern
        for category, patterns in self.rule_patterns.items():
            for pattern in patterns:
                if pattern.lower() in narration:
                    best_category = category
                    best_confidence = 0.8
                    reasoning = f"Matched pattern: '{pattern}'"
                    break
            if best_category != "OTHER":
                break
        
        # Additional business logic
        if transaction.withdrawal_amt > 0 and transaction.deposit_amt == 0:
            # It's an expense/withdrawal
            if "atm" in narration.lower():
                best_category = "CASH_WITHDRAWAL"
                best_confidence = 0.9
        elif transaction.deposit_amt > 0 and transaction.withdrawal_amt == 0:
            # It's income/deposit
            if "salary" in narration.lower():
                best_category = "SALARY_INCOME"
                best_confidence = 0.9
        
        return ClassifiedTransaction(
            date=transaction.date,
            narration=transaction.narration,
            chq_ref_no=transaction.chq_ref_no,
            value_date=transaction.value_date,
            withdrawal_amt=transaction.withdrawal_amt,
            deposit_amt=transaction.deposit_amt,
            closing_balance=transaction.closing_balance,
            category=best_category,
            confidence=best_confidence,
            reasoning=reasoning
        )
    
    def classify_transactions(self, transactions: List[Transaction]) -> List[ClassifiedTransaction]:
        """Classify multiple transactions"""
        classified = []
        
        print(f"🔄 Classifying {len(transactions)} transactions using {self.model_type}...")
        
        for i, transaction in enumerate(transactions, 1):
            print(f"   Processing transaction {i}/{len(transactions)}")
            classified_transaction = self.classify_transaction(transaction)
            classified.append(classified_transaction)
        
        print("✅ Classification completed!")
        return classified
    
    def _create_classification_prompt(self, transaction: Transaction) -> str:
        """Create prompt for local LLM"""
        
        amount = transaction.withdrawal_amt if transaction.withdrawal_amt > 0 else transaction.deposit_amt
        transaction_type = "Withdrawal" if transaction.withdrawal_amt > 0 else "Deposit"
        
        categories_list = "\n".join([f"- {key}: {desc}" for key, desc in self.CATEGORIES.items()])
        
        prompt = f"""You are a financial expert. Classify this bank transaction for tax purposes.

TRANSACTION:
- Date: {transaction.date}
- Description: {transaction.narration}
- Type: {transaction_type}
- Amount: ₹{amount:,.2f}

CATEGORIES:
{categories_list}

Return only JSON in this format:
{{
    "category": "CATEGORY_NAME",
    "confidence": 0.95,
    "reasoning": "Brief explanation"
}}

Choose the most appropriate category based on keywords and context."""
        
        return prompt
    
    def _parse_llm_response(self, response: str) -> Dict:
        """Parse LLM response"""
        try:
            # Clean response
            response = response.strip()
            if response.startswith("```json"):
                response = response[7:]
            if response.endswith("```"):
                response = response[:-3]
            
            result = json.loads(response.strip())
            
            # Validate
            if result["category"] not in self.CATEGORIES:
                result["category"] = "OTHER"
            
            if not (0 <= result.get("confidence", 0.5) <= 1):
                result["confidence"] = 0.5
            
            return result
            
        except:
            return {
                "category": "OTHER",
                "confidence": 0.3,
                "reasoning": "Failed to parse response"
            }

# Installation helper
def install_ollama_guide():
    """Print Ollama installation guide"""
    print("""
🦙 Ollama Setup Guide (Free Local AI)
=====================================

1. Install Ollama:
   • macOS: brew install ollama
   • Linux: curl -fsSL https://ollama.ai/install.sh | sh
   • Windows: Download from https://ollama.ai/

2. Start Ollama:
   ollama serve

3. Install a model (choose one):
   ollama pull llama3.1        # 4.7GB - Recommended
   ollama pull llama3.1:8b     # 4.7GB - Same as above
   ollama pull codellama       # 3.8GB - Good for structured tasks
   ollama pull mistral         # 4.1GB - Fast and efficient

4. Test it:
   ollama run llama3.1 "Hello world"

5. Use in classifier:
   python main.py --local-llm
""")

if __name__ == "__main__":
    print("🏠 LocalTransactionClassifier ready!")
    print("Choose your method:")
    print("1. Ollama (recommended) - Free, runs locally")
    print("2. Rule-based - Fast, no AI needed")
    print()
    install_ollama_guide()
