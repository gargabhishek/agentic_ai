# 🏦 Bank Statement Transaction Classifier

A simple LLM-powered solution for classifying bank transactions into taxation categories. Perfect for individuals and small businesses managing their financial records for tax purposes.

## 🎯 What It Does

This tool takes your bank statement data and automatically classifies each transaction into relevant categories such as:

- **Income Categories**: Salary, Business Income, Dividends, Interest
- **Expense Categories**: Office Expenses, Medical, Education, Personal
- **Tax-Relevant**: HRA Payments, Tax Payments, Insurance Premiums
- **Transfers**: Self Transfers, Family Transfers
- **And more...**

## 🚀 Quick Start

### 1. Setup

```bash
# Navigate to the transaction classifier directory
cd transaction_classifier

# Install requirements
pip install -r requirements.txt

# Set up your OpenAI API key
echo "OPENAI_API_KEY=your-api-key-here" > .env
```

### 2. Prepare Your Data

Place your bank statement files in the `data/input/` folder:
- **Supported formats**: CSV, Excel (.xlsx, .xls)
- **Expected columns**: Date, Narration, Withdrawal Amount, Deposit Amount, etc.

Example format:
```csv
Date,Narration,Chq./Ref.No.,Value Dt,Withdrawal Amt.,Deposit Amt.,Closing Balance
01/07/25,ACH C- ADANIENTFINAL2024 25-124981,0000000155407547,01/07/25,27.30,,466681.17
02/07/25,50100436622470-TPT-HRA PAYTM RENT-VIJAY KUMAR,0000000480643450,02/07/25,130000.00,,336681.17
```

### 3. Run Classification

```bash
# Process all files in data/input/
python main.py

# Process a specific file
python main.py --file your_statement.csv

# Preview file structure before processing
python main.py --preview

# Generate only CSV output (no Excel)
python main.py --csv-only
```

### 4. Check Results

Your classified transactions will be saved in `data/output/` as:
- **Excel files**: Complete reports with multiple sheets (transactions, summaries, charts)
- **CSV files**: Simple format for further analysis

## 📊 Output Features

### Excel Report Includes:
1. **All Transactions**: Complete classified transaction list
2. **Category Summary**: Spending by category with charts
3. **Monthly Summary**: Month-wise transaction analysis
4. **Tax Summary**: Tax-relevant categorization for filing

### Categories Available:
- `SALARY_INCOME` - Salary from employer
- `HRA_PAYMENT` - HRA paid for rent
- `HRA_RECEIVED` - HRA received from employer
- `OFFICE_EXPENSE` - Office-related expenses
- `BUSINESS_EXPENSE` - Business expenses
- `PERSONAL_EXPENSE` - Personal expenses
- `MEDICAL_EXPENSE` - Healthcare expenses
- `INVESTMENT` - Investments made
- `TAX_PAYMENT` - Tax payments
- `SELF_TRANSFER` - Transfers between own accounts
- And 15+ more categories...

## 🔧 Advanced Usage

### Custom API Settings
```bash
# Use different OpenAI model (in code)
# Default: gpt-3.5-turbo (cost-effective)
# Alternative: gpt-4 (more accurate, higher cost)
```

### Batch Processing
```bash
# Process multiple files at once
python main.py  # Processes all files in data/input/
```

### File Structure
```
transaction_classifier/
├── main.py              # Main script
├── classifier.py        # LLM classification logic
├── file_reader.py       # File reading utilities
├── excel_generator.py   # Excel report generation
├── requirements.txt     # Dependencies
├── .env                 # API keys (create this)
└── data/
    ├── input/           # Put your bank statements here
    └── output/          # Classified results appear here
```

## 💡 Tips for Best Results

1. **Clean Data**: Ensure your bank statement has clear transaction descriptions
2. **API Costs**: Start with small files to understand costs (~$0.01-0.05 per transaction)
3. **Review Classifications**: Check the generated Excel file and confidence scores
4. **Customize Categories**: Modify `classifier.py` to add your own categories

## 🔒 Privacy & Security

- **Local Processing**: All classification happens locally on your machine
- **API Privacy**: Only transaction descriptions are sent to OpenAI for classification
- **No Storage**: OpenAI doesn't store your data when using the API
- **Offline Option**: Consider local LLM solutions for maximum privacy

## 📈 Sample Output

```
🏦 Bank Statement Transaction Classifier
📋 LLM-powered classification for taxation purposes

🔧 Initializing components...
✅ Components initialized successfully

📁 Found 1 file(s) to process:
   • sample_statement.csv

📖 Reading transactions...
   Found 8 transactions

🤖 Classifying transactions with LLM...
   Processing transaction 1/8
   Processing transaction 2/8
   ...
✅ Classification completed!

📊 Excel report saved: classified_sample_statement_20240101_120000.xlsx

📈 Classification Summary:
   Total Transactions: 8
   Average Confidence: 94.5%
   Categories Found: 6

   Top Categories:
     • HRA_PAYMENT: 1 transactions
     • SALARY_INCOME: 1 transactions
     • PERSONAL_EXPENSE: 2 transactions
```

## 🆘 Troubleshooting

**"No OpenAI API key found"**
- Create `.env` file with your API key
- Get API key from: https://platform.openai.com/api-keys

**"No transactions found"**
- Check file format and column headers
- Use `--preview` to see how file is being read

**"API Error"**
- Check internet connection
- Verify API key is valid and has credits

**High API costs**
- Use `gpt-3.5-turbo` instead of `gpt-4`
- Process smaller batches
- Review and optimize prompts

## 🎓 Next Steps

Once comfortable with basic classification:

1. **Customize Categories**: Add your specific business categories
2. **Improve Prompts**: Fine-tune classification accuracy
3. **Add Rules**: Combine LLM with rule-based classification
4. **Integrate**: Connect with accounting software
5. **Automate**: Set up recurring classification workflows

---

**Keep your finances organized and tax-ready! 📊💼**
