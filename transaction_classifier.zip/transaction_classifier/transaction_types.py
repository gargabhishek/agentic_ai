#!/usr/bin/env python3
"""
Transaction Data Types
Common data classes used across different classifiers
"""

from dataclasses import dataclass

@dataclass
class Transaction:
    """Data class for a bank transaction"""
    date: str
    narration: str
    chq_ref_no: str
    value_date: str
    withdrawal_amt: float
    deposit_amt: float
    closing_balance: float

@dataclass
class ClassifiedTransaction:
    """Data class for a classified transaction"""
    date: str
    narration: str
    chq_ref_no: str
    value_date: str
    withdrawal_amt: float
    deposit_amt: float
    closing_balance: float
    category: str
    confidence: float
    reasoning: str
