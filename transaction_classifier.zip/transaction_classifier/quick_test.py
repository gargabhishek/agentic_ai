#!/usr/bin/env python3
"""
Quick Test Script - No API Key Required!
Demonstrates rule-based classification with your sample data
"""

import sys
from pathlib import Path

# Add current directory to path
sys.path.append(str(Path(__file__).parent))

from local_classifier import LocalTransactionClassifier
from transaction_types import Transaction

def test_classification():
    """Test classification with sample transactions"""
    
    print("🔍 Quick Classification Test (No API Key Needed!)")
    print("=" * 55)
    print()
    
    # Sample transactions based on your example
    sample_transactions = [
        Transaction(
            date="01/07/25",
            narration="ACH C- ADANIENTFINAL2024 25-124981",
            chq_ref_no="0000000155407547",
            value_date="01/07/25",
            withdrawal_amt=27.30,
            deposit_amt=0.0,
            closing_balance=466681.17
        ),
        Transaction(
            date="02/07/25",
            narration="50100436622470-TPT-HRA PAYTM RENT-VIJAY KUMAR",
            chq_ref_no="0000000480643450",
            value_date="02/07/25",
            withdrawal_amt=130000.00,
            deposit_amt=0.0,
            closing_balance=336681.17
        ),
        Transaction(
            date="03/07/25",
            narration="SALARY CREDIT - TECH CORP",
            chq_ref_no="0000000480643451",
            value_date="03/07/25",
            withdrawal_amt=0.0,
            deposit_amt=75000.00,
            closing_balance=411681.17
        ),
        Transaction(
            date="04/07/25",
            narration="ATM WITHDRAWAL",
            chq_ref_no="0000000480643452",
            value_date="04/07/25",
            withdrawal_amt=5000.00,
            deposit_amt=0.0,
            closing_balance=406681.17
        )
    ]
    
    # Test rule-based classifier
    print("🔧 Testing Rule-Based Classification:")
    print()
    
    classifier = LocalTransactionClassifier(model_type="rule_based")
    
    for i, transaction in enumerate(sample_transactions, 1):
        print(f"Transaction {i}:")
        print(f"  📝 Description: {transaction.narration}")
        print(f"  💰 Amount: ₹{transaction.withdrawal_amt + transaction.deposit_amt:,.2f}")
        
        # Classify
        result = classifier.classify_transaction(transaction)
        
        print(f"  🏷️  Category: {result.category}")
        print(f"  🎯 Confidence: {result.confidence:.1%}")
        print(f"  💡 Reasoning: {result.reasoning}")
        print()
    
    print("✅ Test completed!")
    print()
    print("Next steps:")
    print("1. 🚀 Try with your data: python main.py --rule-based")
    print("2. 🦙 For better accuracy: python main.py --local-llm (after installing Ollama)")
    print("3. 📊 Full Excel reports: python main.py --rule-based (without --csv-only)")

if __name__ == "__main__":
    test_classification()
