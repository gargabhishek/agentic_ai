"""
Command Line Interface for the Bank Transaction Analyzer.
"""
import click
import json
from pathlib import Path
from typing import Optional, List
from datetime import datetime, timedelta
from rich.console import Console
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.panel import Panel
from rich import print as rprint

from ..core.processor import TransactionProcessor
# Remove database dependency - using file-based storage now
from ..utils.helpers import format_currency, calculate_date_range
from ..utils.validators import validate_file
from config import settings


console = Console()


@click.group()
@click.option('--debug', is_flag=True, help='Enable debug mode')
@click.pass_context
def main(ctx, debug):
    """Bank Transaction Analyzer - AI-powered transaction classification and analysis."""
    ctx.ensure_object(dict)
    ctx.obj['debug'] = debug
    
    if debug:
        console.print("[yellow]Debug mode enabled[/yellow]")


@main.command()
@click.argument('file_path', type=click.Path(exists=True))
@click.option('--bank', '-b', help='Bank name for better parsing')
@click.option('--ai/--no-ai', default=True, help='Use AI classification (default: true)')
@click.option('--output', '-o', type=click.Path(), help='Output file for results')
@click.pass_context
def process(ctx, file_path: str, bank: Optional[str], ai: bool, output: Optional[str]):
    """Process a bank statement file (PDF, Excel, CSV)."""
    
    file_path = Path(file_path)
    
    # Validate file
    if not validate_file(file_path):
        console.print("[red]❌ Invalid file. Check file type and size.[/red]")
        return
        
    console.print(f"[green]📄 Processing file:[/green] {file_path}")
    if bank:
        console.print(f"[blue]🏦 Bank:[/blue] {bank}")
    console.print(f"[blue]🤖 AI Classification:[/blue] {'Enabled' if ai else 'Disabled'}")
    
    # Initialize processor
    processor = TransactionProcessor(use_ai=ai)
    
    # Process file with progress bar
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console
    ) as progress:
        task = progress.add_task("Processing file...", total=None)
        
        try:
            batch = processor.process_file(file_path, bank)
            progress.update(task, description="✅ Processing complete!")
            
        except Exception as e:
            progress.update(task, description="❌ Processing failed!")
            console.print(f"[red]Error processing file: {str(e)}[/red]")
            return
            
    # Display results
    _display_batch_results(batch)
    
    # Save results if output specified
    if output:
        _save_results(batch, output)


@main.command()
@click.option('--category', '-c', help='Filter by category')
@click.option('--bank', '-b', help='Filter by bank')
@click.option('--period', '-p', 
              type=click.Choice(['today', 'yesterday', 'last_week', 'last_month', 'last_year']),
              default='last_month', help='Time period')
@click.option('--limit', '-l', default=50, help='Maximum number of transactions to show')
@click.option('--output', '-o', type=click.Path(), help='Export to file')
def list(category: Optional[str], bank: Optional[str], period: str, limit: int, output: Optional[str]):
    """List transactions with optional filters."""
    
    # Calculate date range
    start_date, end_date = calculate_date_range(period)
    
    # Prepare filters
    filters = {
        'date_from': start_date,
        'date_to': end_date
    }
    
    if category:
        filters['category'] = category.upper()
    if bank:
        filters['bank_name'] = bank
        
    # Get transactions from stored CSV files
    processor = TransactionProcessor()
    transactions = processor.search_transactions("", limit=limit)  # Get all transactions
    
    # Apply filters client-side
    if category:
        transactions = [t for t in transactions if t.get('Category', '').upper() == category.upper()]
    if bank:
        transactions = [t for t in transactions if t.get('Bank_Name', '').upper() == bank.upper()]
    
    # Apply date filter (simplified)
    # Note: For full date filtering, we'd need to parse dates from CSV
    
    if not transactions:
        console.print("[yellow]No transactions found matching the criteria.[/yellow]")
        console.print("[blue]💡 Tip: Make sure you've processed some bank statements first![/blue]")
        return
        
    # Display transactions table
    _display_transactions_table(transactions, f"Transactions ({period})")
    
    # Export if requested
    if output:
        _export_transactions(transactions, output)


@main.command()
@click.option('--period', '-p',
              type=click.Choice(['last_week', 'last_month', 'last_3_months', 'last_year']),
              default='last_month', help='Analysis period')
@click.option('--output', '-o', type=click.Path(), help='Save report to file')
def analytics(period: str, output: Optional[str]):
    """Generate analytics report for transactions."""
    
    # Calculate date range
    start_date, end_date = calculate_date_range(period)
    
    console.print(f"[green]📊 Generating analytics for {period}[/green]")
    
    # Generate analytics from stored CSV files
    processor = TransactionProcessor()
    analytics_result = processor.get_analytics(
        start_date=start_date.isoformat(),
        end_date=end_date.isoformat()
    )
    
    if "error" in analytics_result:
        console.print(f"[yellow]{analytics_result['error']}[/yellow]")
        console.print("[blue]💡 Tip: Process some bank statements first to generate analytics![/blue]")
        return
        
    # Display analytics info
    console.print(f"[green]📊 Analytics generated![/green]")
    console.print(f"[blue]📄 Report saved to:[/blue] {analytics_result.get('analytics_file', 'Unknown')}")
    
    # Save additional report if requested
    if output:
        console.print(f"[blue]💾 Also saving to:[/blue] {output}")
        # Copy the analytics file to the requested output location
        import shutil
        try:
            shutil.copy2(analytics_result['analytics_file'], output)
            console.print(f"[green]✅ Analytics copied to {output}[/green]")
        except Exception as e:
            console.print(f"[red]❌ Failed to copy analytics: {str(e)}[/red]")


@main.command()
@click.argument('query')
@click.option('--category', '-c', help='Filter by category')
@click.option('--limit', '-l', default=20, help='Maximum number of results')
def search(query: str, category: Optional[str], limit: int):
    """Search transactions by description."""
    
    console.print(f"[green]🔍 Searching for:[/green] '{query}'")
    
    processor = TransactionProcessor()
    results = processor.search_transactions(query, category, limit)
    
    if not results:
        console.print("[yellow]No transactions found matching your search.[/yellow]")
        console.print("[blue]💡 Tip: Make sure you've processed some bank statements first![/blue]")
        return
        
    # Results are already in dict format from CSV
    _display_transactions_table(results, f"Search Results for '{query}'")


@main.command()
@click.argument('file_paths', nargs=-1, required=True)
@click.option('--bank', '-b', help='Bank name for all files')
@click.option('--ai/--no-ai', default=True, help='Use AI classification')
@click.option('--output-dir', '-o', type=click.Path(), help='Output directory for results')
def batch(file_paths: tuple, bank: Optional[str], ai: bool, output_dir: Optional[str]):
    """Process multiple files in batch."""
    
    file_list = [Path(fp) for fp in file_paths]
    
    # Validate all files first
    valid_files = []
    for file_path in file_list:
        if validate_file(file_path):
            valid_files.append(file_path)
        else:
            console.print(f"[red]❌ Skipping invalid file:[/red] {file_path}")
            
    if not valid_files:
        console.print("[red]No valid files to process.[/red]")
        return
        
    console.print(f"[green]📁 Processing {len(valid_files)} files in batch mode[/green]")
    
    # Initialize processor
    processor = TransactionProcessor(use_ai=ai)
    
    # Process files with progress
    with Progress(console=console) as progress:
        main_task = progress.add_task("Processing files...", total=len(valid_files))
        
        all_batches = []
        for i, file_path in enumerate(valid_files):
            progress.update(main_task, description=f"Processing {file_path.name}...")
            
            try:
                batch = processor.process_file(file_path, bank)
                all_batches.append(batch)
                console.print(f"[green]✅ Processed:[/green] {file_path.name} ({batch.total_transactions} transactions)")
                
            except Exception as e:
                console.print(f"[red]❌ Failed:[/red] {file_path.name} - {str(e)}")
                
            progress.advance(main_task)
            
    # Display summary
    _display_batch_summary(all_batches)
    
    # Save results if output directory specified
    if output_dir:
        _save_batch_results(all_batches, output_dir)


@main.command()
@click.option('--days', default=365, help='Keep data newer than N days (delete older)')
@click.option('--confirm', is_flag=True, help='Confirm deletion without prompt')
def cleanup(days: int, confirm: bool):
    """Clean up old transaction data."""
    
    if not confirm:
        if not click.confirm(f'This will delete transaction data older than {days} days. Continue?'):
            return
            
    console.print(f"[yellow]🧹 Cleaning up files older than {days} days...[/yellow]")
    
    # For file-based storage, we could implement file cleanup
    # For now, show current storage stats
    processor = TransactionProcessor()
    storage_stats = processor.get_storage_stats()
    
    console.print(f"[blue]📊 Current storage statistics:[/blue]")
    console.print(f"  • Total CSV files: {storage_stats.get('total_csv_files', 0)}")
    console.print(f"  • Total size: {storage_stats.get('total_size_mb', 0):.1f} MB")
    console.print(f"  • Base directory: {storage_stats.get('base_directory', 'Unknown')}")
    console.print(f"[yellow]💡 Manual cleanup: Delete old files from the output directory[/yellow]")


@main.command()
def status():
    """Show system status and statistics."""
    
    processor = TransactionProcessor()
    
    # Get storage statistics
    storage_stats = processor.get_storage_stats()
    processed_files = processor.list_processed_files()
    
    # Try to get some basic transaction stats from recent files
    all_transactions = processor.search_transactions("", limit=10000)  # Get recent transactions
    total_count = len(all_transactions)
    
    # Category distribution
    categories = {}
    total_amount = 0
    for txn in all_transactions:
        category = txn.get('Category', 'OTHER')
        try:
            amount = float(txn.get('Amount', 0))
        except (ValueError, TypeError):
            amount = 0
        
        if category not in categories:
            categories[category] = {'count': 0, 'amount': 0}
        categories[category]['count'] += 1
        categories[category]['amount'] += amount
        total_amount += amount
        
    # Display status
    console.print(Panel.fit("📊 Bank Transaction Analyzer Status", style="bold green"))
    
    status_table = Table(show_header=False, box=None)
    status_table.add_column("Metric", style="cyan")
    status_table.add_column("Value", style="white")
    
    status_table.add_row("Total Transactions", f"{total_count:,}")
    status_table.add_row("Processed Files", f"{storage_stats.get('total_csv_files', 0):,}")
    status_table.add_row("Storage Size", f"{storage_stats.get('total_size_mb', 0):.1f} MB")
    status_table.add_row("Total Amount", format_currency(total_amount))
    status_table.add_row("Categories", f"{len(categories)}")
    status_table.add_row("Storage Type", "File-based (CSV)")
    
    console.print(status_table)
    
    # Top categories
    if categories:
        console.print("\n[bold]Top Categories:[/bold]")
        sorted_categories = sorted(categories.items(), key=lambda x: x[1]['count'], reverse=True)
        
        cat_table = Table()
        cat_table.add_column("Category", style="cyan")
        cat_table.add_column("Count", justify="right")
        cat_table.add_column("Total Amount", justify="right")
        
        for category, data in sorted_categories[:10]:
            cat_table.add_row(
                category,
                f"{data['count']:,}",
                format_currency(data['amount'])
            )
            
        console.print(cat_table)


@main.command()
def files():
    """List all processed files and their locations."""
    
    processor = TransactionProcessor()
    processed_files = processor.list_processed_files()
    storage_stats = processor.get_storage_stats()
    
    console.print(Panel.fit("📁 Processed Files", style="bold green"))
    
    if not processed_files:
        console.print("[yellow]No processed files found.[/yellow]")
        console.print("[blue]💡 Tip: Process some bank statements first using 'bank-analyzer process <file>'[/blue]")
        return
    
    # Display storage info
    console.print(f"[blue]📊 Storage Directory:[/blue] {storage_stats.get('base_directory', 'Unknown')}")
    console.print(f"[blue]📈 Total Files:[/blue] {len(processed_files)} • [blue]Total Size:[/blue] {storage_stats.get('total_size_mb', 0):.1f} MB\n")
    
    # Display files table
    files_table = Table()
    files_table.add_column("File Name", style="cyan", max_width=50)
    files_table.add_column("Bank", style="yellow", width=10)
    files_table.add_column("Size", style="green", justify="right", width=8)
    files_table.add_column("Created", style="blue", width=12)
    files_table.add_column("Location", style="white", max_width=40)
    
    for file_info in processed_files[:20]:  # Show first 20 files
        created_date = file_info.get('created_at', '')[:10] if file_info.get('created_at') else ''
        
        files_table.add_row(
            file_info.get('file_name', ''),
            file_info.get('bank_name', 'Unknown'),
            f"{file_info.get('size_mb', 0):.1f}MB",
            created_date,
            file_info.get('relative_path', '')[:40]
        )
    
    console.print(files_table)
    
    if len(processed_files) > 20:
        console.print(f"[dim]... and {len(processed_files) - 20} more files[/dim]")
    
    console.print(f"\n[green]💡 Tip:[/green] Use 'bank-analyzer search <query>' to search within these files")


def _display_batch_results(batch):
    """Display batch processing results."""
    console.print(f"\n[bold green]✅ Processing Complete![/bold green]")
    
    results_table = Table(show_header=False, box=None)
    results_table.add_column("Metric", style="cyan")
    results_table.add_column("Value", style="white")
    
    results_table.add_row("Batch ID", batch.id)
    results_table.add_row("Source File", batch.source_file)
    results_table.add_row("File Type", batch.file_type.upper())
    results_table.add_row("Bank", batch.bank_name or "Unknown")
    results_table.add_row("Total Transactions", str(batch.total_transactions))
    results_table.add_row("Processed", str(batch.processed_transactions))
    results_table.add_row("Failed", str(batch.failed_transactions))
    results_table.add_row("Success Rate", f"{batch.get_progress():.1f}%")
    
    console.print(results_table)
    
    if batch.error_messages:
        console.print(f"\n[red]Errors:[/red]")
        for error in batch.error_messages:
            console.print(f"  • {error}")


def _display_transactions_table(transactions: List[dict], title: str):
    """Display transactions in a table format."""
    console.print(f"\n[bold]{title}[/bold]")
    
    table = Table()
    table.add_column("Date", style="cyan", width=12)
    table.add_column("Description", style="white", max_width=40)
    table.add_column("Amount", style="green", justify="right", width=12)
    table.add_column("Category", style="yellow", width=15)
    table.add_column("Bank", style="blue", width=10)
    
    for txn in transactions:
        date_str = txn.get('date', '')[:10] if txn.get('date') else ''
        amount = txn.get('amount', 0)
        amount_str = format_currency(amount)
        if amount < 0:
            amount_str = f"[red]{amount_str}[/red]"
        else:
            amount_str = f"[green]{amount_str}[/green]"
            
        table.add_row(
            date_str,
            txn.get('description', '')[:40],
            amount_str,
            txn.get('category', 'OTHER'),
            txn.get('bank_name', '')[:10]
        )
        
    console.print(table)
    console.print(f"[dim]Showing {len(transactions)} transactions[/dim]")


def _display_analytics(analytics_data: dict):
    """Display analytics in a formatted way."""
    console.print(Panel.fit("📊 Transaction Analytics", style="bold green"))
    
    # Summary stats
    summary_table = Table(show_header=False, box=None)
    summary_table.add_column("Metric", style="cyan")
    summary_table.add_column("Value", style="white")
    
    summary_table.add_row("Period", f"{analytics_data.get('period_start', '')} to {analytics_data.get('period_end', '')}")
    summary_table.add_row("Total Transactions", f"{analytics_data.get('total_transactions', 0):,}")
    summary_table.add_row("Total Income", f"[green]{format_currency(analytics_data.get('total_income', 0))}[/green]")
    summary_table.add_row("Total Expenses", f"[red]{format_currency(analytics_data.get('total_expenses', 0))}[/red]")
    summary_table.add_row("Net Amount", f"{format_currency(analytics_data.get('net_amount', 0))}")
    
    console.print(summary_table)
    
    # Category breakdown
    category_breakdown = analytics_data.get('category_breakdown', {})
    if category_breakdown:
        console.print(f"\n[bold]Category Breakdown:[/bold]")
        
        cat_table = Table()
        cat_table.add_column("Category", style="cyan")
        cat_table.add_column("Count", justify="right")
        cat_table.add_column("Total", justify="right")
        cat_table.add_column("Average", justify="right")
        
        sorted_categories = sorted(
            category_breakdown.items(), 
            key=lambda x: abs(x[1]['total']), 
            reverse=True
        )
        
        for category, data in sorted_categories:
            cat_table.add_row(
                category,
                f"{data['count']:,}",
                format_currency(data['total']),
                format_currency(data['average'])
            )
            
        console.print(cat_table)
        
    # Top expenses
    top_expenses = analytics_data.get('top_expenses', [])
    if top_expenses:
        console.print(f"\n[bold]Top Expenses:[/bold]")
        
        exp_table = Table()
        exp_table.add_column("Description", style="white", max_width=40)
        exp_table.add_column("Amount", style="red", justify="right")
        exp_table.add_column("Category", style="yellow")
        exp_table.add_column("Date", style="cyan")
        
        for expense in top_expenses[:10]:
            exp_table.add_row(
                expense['description'][:40],
                format_currency(expense['amount']),
                expense['category'],
                expense['date'][:10]
            )
            
        console.print(exp_table)


def _display_batch_summary(batches: List):
    """Display summary for batch processing."""
    console.print(f"\n[bold green]📁 Batch Processing Summary[/bold green]")
    
    total_files = len(batches)
    total_transactions = sum(batch.total_transactions for batch in batches)
    total_processed = sum(batch.processed_transactions for batch in batches)
    total_failed = sum(batch.failed_transactions for batch in batches)
    
    summary_table = Table(show_header=False, box=None)
    summary_table.add_column("Metric", style="cyan")
    summary_table.add_column("Value", style="white")
    
    summary_table.add_row("Files Processed", str(total_files))
    summary_table.add_row("Total Transactions", str(total_transactions))
    summary_table.add_row("Successfully Processed", str(total_processed))
    summary_table.add_row("Failed", str(total_failed))
    summary_table.add_row("Overall Success Rate", f"{(total_processed / max(total_transactions, 1)) * 100:.1f}%")
    
    console.print(summary_table)


def _save_results(batch, output_path: str):
    """Save batch results to file."""
    output_path = Path(output_path)
    
    results = {
        'batch': batch.to_dict(),
        'transactions': [txn.to_dict() for txn in batch.transactions]
    }
    
    if output_path.suffix.lower() == '.json':
        with open(output_path, 'w') as f:
            json.dump(results, f, indent=2, default=str)
    else:
        # Save as CSV
        import pandas as pd
        df = pd.DataFrame([txn.to_dict() for txn in batch.transactions])
        df.to_csv(output_path, index=False)
        
    console.print(f"[green]💾 Results saved to:[/green] {output_path}")


def _export_transactions(transactions: List[dict], output_path: str):
    """Export transactions to file."""
    output_path = Path(output_path)
    
    if output_path.suffix.lower() == '.json':
        with open(output_path, 'w') as f:
            json.dump(transactions, f, indent=2, default=str)
    else:
        # Save as CSV
        import pandas as pd
        df = pd.DataFrame(transactions)
        df.to_csv(output_path, index=False)
        
    console.print(f"[green]💾 Transactions exported to:[/green] {output_path}")


def _save_analytics_report(analytics_data: dict, output_path: str):
    """Save analytics report to file."""
    output_path = Path(output_path)
    
    with open(output_path, 'w') as f:
        json.dump(analytics_data, f, indent=2, default=str)
        
    console.print(f"[green]💾 Analytics report saved to:[/green] {output_path}")


def _save_batch_results(batches: List, output_dir: str):
    """Save batch results to output directory."""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    for batch in batches:
        filename = f"batch_{batch.id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        output_path = output_dir / filename
        _save_results(batch, str(output_path))


if __name__ == '__main__':
    main()
