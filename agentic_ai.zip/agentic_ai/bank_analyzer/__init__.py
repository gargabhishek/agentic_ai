"""
Bank Transaction Analyzer - AI-powered transaction classification and analysis system.
"""

__version__ = "1.0.0"
__author__ = "Abhishek Garg"

from .core.processor import TransactionProcessor
from .core.models import Transaction, TransactionBatch

__all__ = ["TransactionProcessor", "Transaction", "TransactionBatch"]
