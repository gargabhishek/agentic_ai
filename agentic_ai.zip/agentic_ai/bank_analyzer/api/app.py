"""
FastAPI application for the Bank Transaction Analyzer.
"""
from fastapi import FastAPI, HTTPException, Depends, UploadFile, File, Form
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import tempfile
import shutil
from pathlib import Path
from typing import Optional, List, Dict, Any

from ..core.processor import TransactionProcessor
from ..database.manager import DatabaseManager
from ..security.auth import verify_access_token, get_current_user
from ..utils.validators import validate_file_upload
from ..utils.helpers import calculate_date_range
from .routes import router
from config import settings


def create_app() -> FastAPI:
    """Create and configure FastAPI application."""
    
    app = FastAPI(
        title="Bank Transaction Analyzer API",
        description="AI-powered bank transaction classification and analysis system",
        version="1.0.0",
        docs_url="/docs" if settings.debug_mode else None,
        redoc_url="/redoc" if settings.debug_mode else None
    )
    
    # CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],  # Configure appropriately for production
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # Security
    security = HTTPBearer()
    
    # Include routes
    app.include_router(router, prefix="/api/v1")
    
    @app.get("/")
    async def root():
        """Root endpoint."""
        return {
            "message": "Bank Transaction Analyzer API",
            "version": "1.0.0",
            "status": "running"
        }
    
    @app.get("/health")
    async def health_check():
        """Health check endpoint."""
        try:
            # Test database connection
            db_manager = DatabaseManager()
            db_manager.get_transactions(limit=1)
            
            return {
                "status": "healthy",
                "database": "connected",
                "timestamp": "2025-01-06T10:39:28.123456"
            }
        except Exception as e:
            return JSONResponse(
                status_code=503,
                content={
                    "status": "unhealthy",
                    "error": str(e),
                    "timestamp": "2025-01-06T10:39:28.123456"
                }
            )
    
    # Exception handlers
    @app.exception_handler(HTTPException)
    async def http_exception_handler(request, exc):
        return JSONResponse(
            status_code=exc.status_code,
            content={"error": exc.detail, "status_code": exc.status_code}
        )
    
    @app.exception_handler(Exception)
    async def general_exception_handler(request, exc):
        return JSONResponse(
            status_code=500,
            content={"error": "Internal server error", "detail": str(exc)}
        )
    
    return app


# Dependency for authentication
async def get_current_user_dep(credentials: HTTPAuthorizationCredentials = Depends(HTTPBearer())):
    """Dependency to get current authenticated user."""
    token = credentials.credentials
    user = get_current_user(token)
    if user is None:
        raise HTTPException(status_code=401, detail="Invalid authentication credentials")
    return user


# Create app instance
app = create_app()
