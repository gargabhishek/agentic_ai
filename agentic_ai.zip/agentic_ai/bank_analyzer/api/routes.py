"""
API routes for the Bank Transaction Analyzer.
"""
from fastapi import APIRouter, HTTPException, Depends, UploadFile, File, Form, Query
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from typing import Optional, List, Dict, Any
import tempfile
import json
from pathlib import Path
from datetime import datetime, timedelta

from ..core.processor import TransactionProcessor
from ..core.models import TransactionRequest, ClassificationResult
from ..database.manager import DatabaseManager
from ..security.auth import create_access_token, authenticate_user, verify_access_token
from ..utils.validators import validate_file_upload, validate_api_request
from ..utils.helpers import calculate_date_range, format_currency
from config import settings


router = APIRouter()
security = HTTPBearer()


# Authentication endpoints
@router.post("/auth/login")
async def login(username: str = Form(...), password: str = Form(...)):
    """Authenticate user and return access token."""
    
    if not authenticate_user(username, password):
        raise HTTPException(status_code=401, detail="Invalid username or password")
    
    # Create access token
    access_token = create_access_token(
        data={"sub": username, "is_admin": username == "admin"},
        expires_delta=timedelta(hours=24)
    )
    
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "expires_in": 86400  # 24 hours in seconds
    }


@router.get("/auth/me")
async def get_current_user_info(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Get current user information."""
    
    token = credentials.credentials
    payload = verify_access_token(token)
    
    if payload is None:
        raise HTTPException(status_code=401, detail="Invalid token")
    
    return {
        "username": payload.get("sub"),
        "is_admin": payload.get("is_admin", False),
        "expires": payload.get("exp")
    }


# File processing endpoints
@router.post("/process/upload")
async def upload_and_process_file(
    file: UploadFile = File(...),
    bank_name: Optional[str] = Form(None),
    use_ai: bool = Form(True),
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    """Upload and process a bank statement file."""
    
    # Verify authentication
    token = credentials.credentials
    if verify_access_token(token) is None:
        raise HTTPException(status_code=401, detail="Invalid token")
    
    # Read file content
    file_content = await file.read()
    
    # Validate file
    is_valid, error_msg = validate_file_upload(file_content, file.filename)
    if not is_valid:
        raise HTTPException(status_code=400, detail=error_msg)
    
    # Save file temporarily
    with tempfile.NamedTemporaryFile(delete=False, suffix=Path(file.filename).suffix) as tmp_file:
        tmp_file.write(file_content)
        tmp_file_path = Path(tmp_file.name)
    
    try:
        # Process file
        processor = TransactionProcessor(use_ai=use_ai)
        batch = processor.process_file(tmp_file_path, bank_name)
        
        # Return results
        return {
            "batch_id": batch.id,
            "status": batch.processing_status.value,
            "total_transactions": batch.total_transactions,
            "processed_transactions": batch.processed_transactions,
            "failed_transactions": batch.failed_transactions,
            "success_rate": batch.get_progress(),
            "file_info": {
                "filename": file.filename,
                "file_type": batch.file_type,
                "bank_name": batch.bank_name
            },
            "transactions": [txn.to_dict() for txn in batch.transactions[:10]],  # First 10 transactions
            "error_messages": batch.error_messages
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Processing failed: {str(e)}")
    
    finally:
        # Clean up temporary file
        tmp_file_path.unlink(missing_ok=True)


@router.get("/process/batch/{batch_id}")
async def get_batch_status(
    batch_id: str,
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    """Get processing status for a batch."""
    
    # Verify authentication
    token = credentials.credentials
    if verify_access_token(token) is None:
        raise HTTPException(status_code=401, detail="Invalid token")
    
    db_manager = DatabaseManager()
    batch_summary = db_manager.get_batch_summary(batch_id)
    
    if not batch_summary:
        raise HTTPException(status_code=404, detail="Batch not found")
    
    return batch_summary


# Transaction endpoints
@router.get("/transactions")
async def get_transactions(
    category: Optional[str] = Query(None),
    bank_name: Optional[str] = Query(None),
    date_from: Optional[str] = Query(None),
    date_to: Optional[str] = Query(None),
    search: Optional[str] = Query(None),
    limit: int = Query(50, le=1000),
    offset: int = Query(0, ge=0),
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    """Get transactions with optional filters."""
    
    # Verify authentication
    token = credentials.credentials
    if verify_access_token(token) is None:
        raise HTTPException(status_code=401, detail="Invalid token")
    
    # Build filters
    filters = {}
    
    if category:
        filters['category'] = category.upper()
    if bank_name:
        filters['bank_name'] = bank_name
    if date_from:
        try:
            filters['date_from'] = datetime.fromisoformat(date_from).date()
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid date_from format. Use YYYY-MM-DD")
    if date_to:
        try:
            filters['date_to'] = datetime.fromisoformat(date_to).date()
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid date_to format. Use YYYY-MM-DD")
    if search:
        filters['search'] = search
    
    # Get transactions
    db_manager = DatabaseManager()
    transactions = db_manager.get_transactions(filters=filters, limit=limit, offset=offset)
    
    return {
        "transactions": transactions,
        "count": len(transactions),
        "limit": limit,
        "offset": offset,
        "filters": filters
    }


@router.post("/transactions/classify")
async def classify_transaction(
    transaction: TransactionRequest,
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    """Classify a single transaction."""
    
    # Verify authentication
    token = credentials.credentials
    if verify_access_token(token) is None:
        raise HTTPException(status_code=401, detail="Invalid token")
    
    # Convert to Transaction object
    from ..core.models import Transaction, TransactionType
    from decimal import Decimal
    
    txn = Transaction(
        description=transaction.description,
        amount=Decimal(str(transaction.amount)),
        transaction_type=transaction.transaction_type,
        date=transaction.date,
        bank_name=transaction.bank_name,
        account_number=transaction.account_number
    )
    
    # Classify transaction
    processor = TransactionProcessor(use_ai=settings.enable_ai_classification)
    result = processor.classify_transaction(txn)
    
    return {
        "category": result.category,
        "subcategory": result.subcategory,
        "confidence_score": result.confidence_score,
        "method": result.method,
        "keywords_found": result.keywords_found,
        "reasoning": result.reasoning
    }


@router.get("/transactions/search")
async def search_transactions(
    query: str = Query(..., min_length=2),
    category: Optional[str] = Query(None),
    limit: int = Query(20, le=100),
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    """Search transactions by description."""
    
    # Verify authentication
    token = credentials.credentials
    if verify_access_token(token) is None:
        raise HTTPException(status_code=401, detail="Invalid token")
    
    db_manager = DatabaseManager()
    results = db_manager.search_transactions(query, category, limit)
    
    return {
        "query": query,
        "results": [txn.to_dict() for txn in results],
        "count": len(results)
    }


# Analytics endpoints
@router.get("/analytics/summary")
async def get_analytics_summary(
    period: str = Query("last_month", regex="^(last_week|last_month|last_3_months|last_year|this_month|this_year)$"),
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    """Get analytics summary for a time period."""
    
    # Verify authentication
    token = credentials.credentials
    if verify_access_token(token) is None:
        raise HTTPException(status_code=401, detail="Invalid token")
    
    # Calculate date range
    start_date, end_date = calculate_date_range(period)
    
    # Get analytics
    db_manager = DatabaseManager()
    analytics = db_manager.get_analytics(
        start_date=start_date.isoformat(),
        end_date=end_date.isoformat()
    )
    
    return analytics


@router.get("/analytics/categories")
async def get_category_analytics(
    date_from: Optional[str] = Query(None),
    date_to: Optional[str] = Query(None),
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    """Get category-wise analytics."""
    
    # Verify authentication
    token = credentials.credentials
    if verify_access_token(token) is None:
        raise HTTPException(status_code=401, detail="Invalid token")
    
    # Set default dates if not provided
    if not date_to:
        date_to = datetime.now().date().isoformat()
    if not date_from:
        date_from = (datetime.now().date() - timedelta(days=30)).isoformat()
    
    # Get analytics
    db_manager = DatabaseManager()
    analytics = db_manager.get_analytics(start_date=date_from, end_date=date_to)
    
    category_breakdown = analytics.get('category_breakdown', {})
    
    # Format response
    categories = []
    for category, data in category_breakdown.items():
        categories.append({
            "category": category,
            "total_amount": data['total'],
            "transaction_count": data['count'],
            "average_amount": data['average'],
            "percentage": (abs(data['total']) / analytics.get('total_expenses', 1)) * 100 if data['total'] < 0 else 0
        })
    
    # Sort by total amount (descending)
    categories.sort(key=lambda x: abs(x['total_amount']), reverse=True)
    
    return {
        "period": f"{date_from} to {date_to}",
        "categories": categories,
        "total_categories": len(categories)
    }


# System endpoints
@router.get("/system/status")
async def get_system_status(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Get system status and statistics."""
    
    # Verify authentication
    token = credentials.credentials
    if verify_access_token(token) is None:
        raise HTTPException(status_code=401, detail="Invalid token")
    
    db_manager = DatabaseManager()
    
    # Get basic statistics
    all_transactions = db_manager.get_transactions(limit=999999)
    
    # Calculate statistics
    total_count = len(all_transactions)
    total_amount = sum(txn.get('amount', 0) for txn in all_transactions)
    
    # Category distribution
    categories = {}
    for txn in all_transactions:
        category = txn.get('category', 'OTHER')
        if category not in categories:
            categories[category] = 0
        categories[category] += 1
    
    # Recent activity (last 7 days)
    recent_start = (datetime.now() - timedelta(days=7)).date()
    recent_transactions = db_manager.get_transactions(
        filters={'date_from': recent_start},
        limit=999999
    )
    
    return {
        "system": {
            "status": "operational",
            "version": "1.0.0",
            "database": "connected",
            "ai_enabled": settings.enable_ai_classification
        },
        "statistics": {
            "total_transactions": total_count,
            "total_amount": total_amount,
            "categories_count": len(categories),
            "recent_transactions": len(recent_transactions)
        },
        "categories": categories,
        "timestamp": datetime.utcnow().isoformat()
    }


@router.get("/system/categories")
async def get_available_categories():
    """Get list of available transaction categories."""
    
    from config import TRANSACTION_CATEGORIES
    
    categories = []
    for category, keywords in TRANSACTION_CATEGORIES.items():
        categories.append({
            "name": category,
            "keywords": keywords[:10],  # First 10 keywords
            "total_keywords": len(keywords)
        })
    
    return {
        "categories": categories,
        "total_categories": len(categories)
    }
