"""
Base classifier for transaction categorization.
"""
import logging
from abc import ABC, abstractmethod
from typing import Optional

from ..core.models import Transaction, ClassificationResult


class BaseClassifier(ABC):
    """Abstract base class for all transaction classifiers."""
    
    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)
        
    @abstractmethod
    def classify(self, transaction: Transaction) -> ClassificationResult:
        """
        Classify a transaction into a category.
        
        Args:
            transaction: Transaction to classify
            
        Returns:
            ClassificationResult with category, confidence, and metadata
        """
        pass
        
    def preprocess_description(self, description: str) -> str:
        """
        Preprocess transaction description for classification.
        
        Args:
            description: Raw transaction description
            
        Returns:
            Cleaned and normalized description
        """
        if not description:
            return ""
            
        # Convert to lowercase
        desc = description.lower().strip()
        
        # Remove common bank terms that don't help with classification
        bank_terms = [
            'txn', 'transaction', 'ref', 'reference', 'no', 'number',
            'upi', 'neft', 'rtgs', 'imps', 'pos', 'atm', 'ach',
            'dr', 'cr', 'debit', 'credit'
        ]
        
        for term in bank_terms:
            desc = desc.replace(term, ' ')
            
        # Remove extra whitespace
        desc = ' '.join(desc.split())
        
        return desc
        
    def extract_keywords(self, description: str) -> list:
        """
        Extract meaningful keywords from transaction description.
        
        Args:
            description: Transaction description
            
        Returns:
            List of extracted keywords
        """
        processed_desc = self.preprocess_description(description)
        
        # Split into words and filter
        words = processed_desc.split()
        
        # Filter out common stop words and short words
        stop_words = {
            'the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
            'of', 'with', 'by', 'from', 'up', 'about', 'into', 'through',
            'during', 'before', 'after', 'above', 'below', 'between',
            'among', 'under', 'over', 'is', 'are', 'was', 'were', 'be',
            'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did',
            'will', 'would', 'could', 'should', 'may', 'might', 'must',
            'can', 'a', 'an', 'as', 'i', 'you', 'he', 'she', 'it', 'we',
            'they', 'them', 'their', 'what', 'which', 'who', 'when',
            'where', 'why', 'how', 'all', 'any', 'both', 'each', 'few',
            'more', 'most', 'other', 'some', 'such', 'only', 'own',
            'same', 'so', 'than', 'too', 'very'
        }
        
        keywords = [
            word for word in words 
            if len(word) > 2 and word not in stop_words and word.isalpha()
        ]
        
        return keywords
        
    def calculate_confidence(self, matched_keywords: list, total_keywords: list, 
                           base_confidence: float = 0.5) -> float:
        """
        Calculate confidence score based on keyword matches.
        
        Args:
            matched_keywords: List of keywords that matched
            total_keywords: Total keywords extracted from description
            base_confidence: Base confidence score
            
        Returns:
            Confidence score between 0 and 1
        """
        if not total_keywords:
            return 0.0
            
        match_ratio = len(matched_keywords) / len(total_keywords)
        
        # Boost confidence for multiple matches
        boost = min(len(matched_keywords) * 0.1, 0.3)
        
        confidence = min(base_confidence + match_ratio * 0.5 + boost, 1.0)
        
        return round(confidence, 3)
        
    def get_subcategory(self, category: str, keywords: list) -> Optional[str]:
        """
        Determine subcategory based on category and keywords.
        
        Args:
            category: Main category
            keywords: Keywords found in description
            
        Returns:
            Subcategory if determinable, None otherwise
        """
        subcategory_mapping = {
            'FOOD': {
                'restaurant': ['restaurant', 'dining', 'cafe', 'bistro', 'eatery'],
                'grocery': ['grocery', 'supermarket', 'market', 'store', 'mart'],
                'delivery': ['delivery', 'zomato', 'swiggy', 'uber', 'food'],
                'fast_food': ['mcdonald', 'kfc', 'pizza', 'burger', 'subway']
            },
            'TRANSPORTATION': {
                'fuel': ['fuel', 'petrol', 'diesel', 'gas', 'bp', 'shell'],
                'public_transport': ['metro', 'bus', 'train', 'rail'],
                'taxi': ['uber', 'ola', 'taxi', 'cab'],
                'parking': ['parking', 'toll']
            },
            'SHOPPING': {
                'online': ['amazon', 'flipkart', 'myntra', 'ajio'],
                'retail': ['mall', 'store', 'shop', 'retail'],
                'electronics': ['electronics', 'mobile', 'laptop', 'tv'],
                'clothing': ['clothing', 'fashion', 'apparel']
            },
            'ENTERTAINMENT': {
                'streaming': ['netflix', 'prime', 'hotstar', 'spotify'],
                'movies': ['movie', 'cinema', 'pvr', 'inox'],
                'gaming': ['game', 'gaming', 'xbox', 'playstation'],
                'events': ['concert', 'event', 'show']
            }
        }
        
        if category not in subcategory_mapping:
            return None
            
        keywords_lower = [kw.lower() for kw in keywords]
        
        for subcategory, subcat_keywords in subcategory_mapping[category].items():
            if any(kw in keywords_lower for kw in subcat_keywords):
                return subcategory
                
        return None
