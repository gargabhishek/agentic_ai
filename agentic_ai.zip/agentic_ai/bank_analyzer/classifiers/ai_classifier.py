"""
AI-powered transaction classifier using OpenAI GPT models.
"""
import json
import re
from typing import Optional, Dict, Any
from decimal import Decimal

try:
    from openai import OpenAI
except ImportError:
    OpenAI = None

from .base_classifier import BaseClassifier
from ..core.models import Transaction, ClassificationResult
from config import settings, TRANSACTION_CATEGORIES


class AITransactionClassifier(BaseClassifier):
    """AI-powered classifier using OpenAI GPT models."""
    
    def __init__(self):
        super().__init__()
        
        if OpenAI is None:
            raise ImportError("OpenAI package is required for AI classification. Install with: pip install openai")
            
        if not settings.openai_api_key:
            raise ValueError("OpenAI API key is required for AI classification")
            
        self.client = OpenAI(api_key=settings.openai_api_key)
        self.model = "gpt-3.5-turbo"  # Use GPT-3.5 for cost efficiency
        
        # Build category descriptions for better AI understanding
        self.category_descriptions = self._build_category_descriptions()
        
    def classify(self, transaction: Transaction) -> ClassificationResult:
        """
        Classify transaction using AI.
        
        Args:
            transaction: Transaction to classify
            
        Returns:
            ClassificationResult with AI-determined category
        """
        try:
            # Prepare transaction data for AI
            transaction_data = self._prepare_transaction_data(transaction)
            
            # Create prompt
            prompt = self._create_classification_prompt(transaction_data)
            
            # Get AI response
            response = self._get_ai_response(prompt)
            
            # Parse AI response
            result = self._parse_ai_response(response, transaction)
            
            return result
            
        except Exception as e:
            self.logger.error(f"AI classification failed: {str(e)}")
            # Return low-confidence result
            return ClassificationResult(
                category="OTHER",
                confidence_score=0.0,
                method="ai_failed",
                reasoning=f"AI classification failed: {str(e)}"
            )
            
    def _prepare_transaction_data(self, transaction: Transaction) -> Dict[str, Any]:
        """Prepare transaction data for AI processing."""
        return {
            'description': transaction.description or "",
            'amount': float(transaction.amount) if transaction.amount else 0.0,
            'transaction_type': transaction.transaction_type.value if transaction.transaction_type else "unknown",
            'date': transaction.date.strftime('%Y-%m-%d') if transaction.date else "",
            'bank_name': transaction.bank_name or "",
            'raw_text': transaction.raw_text or ""
        }
        
    def _create_classification_prompt(self, transaction_data: Dict[str, Any]) -> str:
        """Create classification prompt for AI."""
        
        categories_text = "\n".join([
            f"- {category}: {', '.join(keywords[:5])}"  # Show first 5 keywords
            for category, keywords in TRANSACTION_CATEGORIES.items()
        ])
        
        prompt = f"""
You are an expert financial transaction classifier. Analyze the following bank transaction and classify it into the most appropriate category.

AVAILABLE CATEGORIES:
{categories_text}

TRANSACTION DETAILS:
- Description: {transaction_data['description']}
- Amount: ₹{transaction_data['amount']}
- Type: {transaction_data['transaction_type']}
- Date: {transaction_data['date']}
- Bank: {transaction_data['bank_name']}
- Raw Text: {transaction_data['raw_text']}

CLASSIFICATION RULES:
1. Choose the MOST SPECIFIC and ACCURATE category
2. Consider context clues in the description
3. For ambiguous cases, choose the most likely category
4. Provide confidence score (0.0 to 1.0)
5. Explain your reasoning briefly

RESPONSE FORMAT (JSON only):
{{
    "category": "CATEGORY_NAME",
    "subcategory": "subcategory_name or null",
    "confidence_score": 0.85,
    "keywords_found": ["keyword1", "keyword2"],
    "reasoning": "Brief explanation of classification decision"
}}

Respond with ONLY the JSON object, no additional text.
"""
        return prompt
        
    def _get_ai_response(self, prompt: str) -> str:
        """Get response from OpenAI API."""
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": "You are a financial transaction classifier. Respond only with valid JSON."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                max_tokens=300,
                temperature=0.1,  # Low temperature for consistent results
                response_format={"type": "json_object"}
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            self.logger.error(f"OpenAI API error: {str(e)}")
            raise
            
    def _parse_ai_response(self, response: str, transaction: Transaction) -> ClassificationResult:
        """Parse AI response and create ClassificationResult."""
        try:
            # Parse JSON response
            data = json.loads(response)
            
            # Validate category
            category = data.get('category', 'OTHER').upper()
            if category not in TRANSACTION_CATEGORIES:
                category = 'OTHER'
                
            # Get confidence score
            confidence = float(data.get('confidence_score', 0.5))
            confidence = max(0.0, min(1.0, confidence))  # Clamp between 0 and 1
            
            # Get subcategory
            subcategory = data.get('subcategory')
            if subcategory == "null" or subcategory == "":
                subcategory = None
                
            # Get keywords
            keywords_found = data.get('keywords_found', [])
            if not isinstance(keywords_found, list):
                keywords_found = []
                
            # Get reasoning
            reasoning = data.get('reasoning', 'AI classification')
            
            return ClassificationResult(
                category=category,
                subcategory=subcategory,
                confidence_score=confidence,
                method="ai",
                keywords_found=keywords_found,
                reasoning=reasoning
            )
            
        except json.JSONDecodeError as e:
            self.logger.error(f"Failed to parse AI response JSON: {str(e)}")
            # Try to extract category from malformed response
            category = self._extract_category_from_text(response)
            
            return ClassificationResult(
                category=category,
                confidence_score=0.3,
                method="ai_fallback",
                reasoning="AI response parsing failed, extracted category from text"
            )
            
        except Exception as e:
            self.logger.error(f"Error parsing AI response: {str(e)}")
            return ClassificationResult(
                category="OTHER",
                confidence_score=0.0,
                method="ai_failed",
                reasoning=f"Failed to parse AI response: {str(e)}"
            )
            
    def _extract_category_from_text(self, text: str) -> str:
        """Extract category from malformed AI response text."""
        text_upper = text.upper()
        
        # Look for category names in the response
        for category in TRANSACTION_CATEGORIES.keys():
            if category in text_upper:
                return category
                
        return "OTHER"
        
    def _build_category_descriptions(self) -> Dict[str, str]:
        """Build detailed descriptions for each category to help AI."""
        return {
            'INCOME': 'Money received including salary, freelance payments, interest, dividends, refunds, bonuses, and other earnings',
            'FOOD': 'Food-related expenses including restaurants, groceries, delivery services, cafes, and dining',
            'TRANSPORTATION': 'Travel and transportation costs including fuel, public transport, taxi/ride-sharing, parking, and tolls',
            'UTILITIES': 'Essential services like electricity, water, gas, internet, phone bills, and cable TV',
            'HEALTHCARE': 'Medical expenses including doctor visits, hospital bills, pharmacy purchases, and health insurance',
            'ENTERTAINMENT': 'Leisure activities like movies, streaming services, gaming, concerts, and recreational activities',
            'SHOPPING': 'General purchases including online shopping, retail stores, electronics, clothing, and household items',
            'EDUCATION': 'Educational expenses including school fees, courses, books, training, and educational materials',
            'INVESTMENT': 'Investment-related transactions including mutual funds, stocks, SIP, and other financial instruments',
            'INSURANCE': 'Insurance premiums including life, health, car, and property insurance',
            'LOAN': 'Loan payments including EMI, credit card payments, and other debt obligations',
            'RENT': 'Housing-related payments including rent, property taxes, and housing maintenance',
            'OTHER': 'Miscellaneous transactions that don\'t fit into other categories'
        }
        
    def get_category_suggestions(self, description: str) -> Dict[str, float]:
        """
        Get category suggestions with confidence scores for a description.
        
        Args:
            description: Transaction description
            
        Returns:
            Dictionary mapping categories to confidence scores
        """
        # Create a simplified transaction for classification
        temp_transaction = Transaction(
            description=description,
            amount=Decimal('100'),  # Dummy amount
        )
        
        # Get multiple suggestions by asking AI for top 3 categories
        prompt = f"""
Analyze this transaction description and provide the top 3 most likely categories with confidence scores.

Description: {description}

Available categories: {', '.join(TRANSACTION_CATEGORIES.keys())}

Response format (JSON):
{{
    "suggestions": [
        {{"category": "CATEGORY1", "confidence": 0.85}},
        {{"category": "CATEGORY2", "confidence": 0.60}},
        {{"category": "CATEGORY3", "confidence": 0.30}}
    ]
}}
"""
        
        try:
            response = self._get_ai_response(prompt)
            data = json.loads(response)
            
            suggestions = {}
            for suggestion in data.get('suggestions', []):
                category = suggestion.get('category', '').upper()
                confidence = float(suggestion.get('confidence', 0.0))
                
                if category in TRANSACTION_CATEGORIES:
                    suggestions[category] = confidence
                    
            return suggestions
            
        except Exception as e:
            self.logger.error(f"Failed to get category suggestions: {str(e)}")
            return {}
            
    def explain_classification(self, transaction: Transaction) -> str:
        """
        Get detailed explanation of why a transaction was classified a certain way.
        
        Args:
            transaction: Transaction to explain
            
        Returns:
            Detailed explanation string
        """
        result = self.classify(transaction)
        
        explanation = f"""
Classification: {result.category}
Confidence: {result.confidence_score:.2%}
Method: {result.method}

Reasoning: {result.reasoning}

Keywords found: {', '.join(result.keywords_found) if result.keywords_found else 'None'}

Category description: {self.category_descriptions.get(result.category, 'No description available')}
"""
        
        return explanation.strip()
