"""
Rule-based transaction classifier using keyword matching and patterns.
"""
from typing import List, Dict, Set
from decimal import Decimal

from .base_classifier import BaseClassifier
from ..core.models import Transaction, ClassificationResult
from config import TRANSACTION_CATEGORIES


class RuleBasedClassifier(BaseClassifier):
    """Rule-based classifier using predefined patterns and keywords."""
    
    def __init__(self):
        super().__init__()
        self.category_keywords = self._build_keyword_map()
        self.amount_patterns = self._build_amount_patterns()
        self.merchant_patterns = self._build_merchant_patterns()
        
    def classify(self, transaction: Transaction) -> ClassificationResult:
        """
        Classify transaction using rule-based approach.
        
        Args:
            transaction: Transaction to classify
            
        Returns:
            ClassificationResult with category and confidence
        """
        description = transaction.description or ""
        amount = transaction.amount or Decimal('0')
        
        # Extract keywords from description
        keywords = self.extract_keywords(description)
        
        # Try different classification strategies
        strategies = [
            self._classify_by_merchant,
            self._classify_by_keywords,
            self._classify_by_amount_pattern,
            self._classify_by_description_pattern
        ]
        
        best_result = None
        best_confidence = 0.0
        
        for strategy in strategies:
            result = strategy(transaction, keywords)
            if result and result.confidence_score > best_confidence:
                best_result = result
                best_confidence = result.confidence_score
                
        # If no good match found, classify as OTHER
        if not best_result or best_confidence < 0.3:
            best_result = ClassificationResult(
                category="OTHER",
                confidence_score=0.1,
                method="rule_based",
                keywords_found=keywords,
                reasoning="No clear pattern matched"
            )
            
        return best_result
        
    def _build_keyword_map(self) -> Dict[str, Set[str]]:
        """Build comprehensive keyword mapping for categories."""
        # Start with base categories from config
        keyword_map = {}
        
        for category, base_keywords in TRANSACTION_CATEGORIES.items():
            keyword_map[category] = set(base_keywords)
            
        # Add more comprehensive keywords
        keyword_map['FOOD'].update([
            'restaurant', 'dining', 'cafe', 'bistro', 'eatery', 'food',
            'zomato', 'swiggy', 'uber eats', 'delivery', 'takeaway',
            'mcdonald', 'kfc', 'pizza', 'burger', 'subway', 'dominos',
            'grocery', 'supermarket', 'market', 'store', 'mart', 'bigbasket',
            'grofers', 'fresh', 'organic', 'bakery', 'sweet', 'ice cream'
        ])
        
        keyword_map['TRANSPORTATION'].update([
            'fuel', 'petrol', 'diesel', 'gas', 'station', 'bp', 'shell',
            'uber', 'ola', 'taxi', 'cab', 'auto', 'rickshaw',
            'metro', 'bus', 'train', 'rail', 'irctc', 'booking',
            'parking', 'toll', 'highway', 'valet', 'garage'
        ])
        
        keyword_map['UTILITIES'].update([
            'electricity', 'power', 'electric', 'bill', 'utility',
            'water', 'sewer', 'waste', 'garbage',
            'gas', 'lng', 'pipeline',
            'internet', 'broadband', 'wifi', 'data', 'airtel', 'jio', 'vi',
            'phone', 'mobile', 'telecom', 'recharge',
            'cable', 'tv', 'dth', 'tata sky', 'dish'
        ])
        
        keyword_map['HEALTHCARE'].update([
            'doctor', 'hospital', 'clinic', 'medical', 'health',
            'pharmacy', 'medicine', 'drug', 'prescription',
            'dental', 'dentist', 'optician', 'vision',
            'lab', 'test', 'diagnostic', 'scan', 'xray',
            'apollo', 'fortis', 'max', 'manipal'
        ])
        
        keyword_map['ENTERTAINMENT'].update([
            'movie', 'cinema', 'pvr', 'inox', 'multiplex',
            'netflix', 'prime', 'hotstar', 'spotify', 'youtube',
            'game', 'gaming', 'xbox', 'playstation', 'steam',
            'concert', 'show', 'event', 'ticket', 'bookmyshow',
            'club', 'bar', 'pub', 'nightlife'
        ])
        
        keyword_map['SHOPPING'].update([
            'amazon', 'flipkart', 'myntra', 'ajio', 'nykaa',
            'mall', 'store', 'shop', 'retail', 'purchase',
            'electronics', 'mobile', 'laptop', 'tv', 'appliance',
            'clothing', 'fashion', 'apparel', 'shoes', 'bag',
            'home', 'furniture', 'decor', 'kitchen'
        ])
        
        keyword_map['EDUCATION'].update([
            'school', 'college', 'university', 'education',
            'course', 'training', 'workshop', 'seminar',
            'book', 'library', 'study', 'tutorial',
            'fee', 'tuition', 'admission', 'exam'
        ])
        
        keyword_map['INVESTMENT'].update([
            'mutual fund', 'mf', 'sip', 'systematic',
            'stock', 'share', 'equity', 'trading',
            'bond', 'debt', 'gilt', 'government',
            'investment', 'portfolio', 'zerodha', 'groww',
            'upstox', 'kite', 'angel'
        ])
        
        keyword_map['INSURANCE'].update([
            'insurance', 'premium', 'policy',
            'life insurance', 'lic', 'term',
            'health insurance', 'medical',
            'car insurance', 'vehicle', 'auto',
            'home insurance', 'property'
        ])
        
        keyword_map['LOAN'].update([
            'emi', 'loan', 'mortgage', 'home loan',
            'personal loan', 'car loan', 'education loan',
            'credit card', 'payment', 'outstanding',
            'principal', 'interest', 'installment'
        ])
        
        keyword_map['RENT'].update([
            'rent', 'rental', 'lease', 'housing',
            'apartment', 'flat', 'house', 'property',
            'landlord', 'tenant', 'deposit', 'advance'
        ])
        
        keyword_map['INCOME'].update([
            'salary', 'wage', 'payroll', 'income',
            'freelance', 'consulting', 'bonus',
            'interest', 'dividend', 'return',
            'refund', 'cashback', 'reward',
            'gift', 'prize', 'winning'
        ])
        
        return keyword_map
        
    def _build_amount_patterns(self) -> Dict[str, Dict]:
        """Build amount-based classification patterns."""
        return {
            'UTILITIES': {
                'min_amount': Decimal('100'),
                'max_amount': Decimal('10000'),
                'common_amounts': [
                    Decimal('500'), Decimal('1000'), Decimal('1500'),
                    Decimal('2000'), Decimal('2500'), Decimal('3000')
                ]
            },
            'RENT': {
                'min_amount': Decimal('5000'),
                'max_amount': Decimal('100000'),
                'patterns': ['monthly', 'recurring']
            },
            'LOAN': {
                'min_amount': Decimal('1000'),
                'max_amount': Decimal('100000'),
                'patterns': ['emi', 'monthly']
            }
        }
        
    def _build_merchant_patterns(self) -> Dict[str, str]:
        """Build merchant name to category mapping."""
        return {
            # Food & Dining
            'zomato': 'FOOD',
            'swiggy': 'FOOD',
            'mcdonald': 'FOOD',
            'dominos': 'FOOD',
            'kfc': 'FOOD',
            'subway': 'FOOD',
            'pizza hut': 'FOOD',
            'bigbasket': 'FOOD',
            'grofers': 'FOOD',
            
            # Transportation
            'uber': 'TRANSPORTATION',
            'ola': 'TRANSPORTATION',
            'irctc': 'TRANSPORTATION',
            'indian oil': 'TRANSPORTATION',
            'bharat petroleum': 'TRANSPORTATION',
            'hp petrol': 'TRANSPORTATION',
            
            # Shopping
            'amazon': 'SHOPPING',
            'flipkart': 'SHOPPING',
            'myntra': 'SHOPPING',
            'ajio': 'SHOPPING',
            'nykaa': 'SHOPPING',
            'reliance digital': 'SHOPPING',
            'croma': 'SHOPPING',
            
            # Entertainment
            'netflix': 'ENTERTAINMENT',
            'amazon prime': 'ENTERTAINMENT',
            'hotstar': 'ENTERTAINMENT',
            'spotify': 'ENTERTAINMENT',
            'bookmyshow': 'ENTERTAINMENT',
            'pvr': 'ENTERTAINMENT',
            'inox': 'ENTERTAINMENT',
            
            # Utilities
            'airtel': 'UTILITIES',
            'jio': 'UTILITIES',
            'vodafone': 'UTILITIES',
            'bsnl': 'UTILITIES',
            'tata sky': 'UTILITIES',
            'dish tv': 'UTILITIES',
            
            # Investment
            'zerodha': 'INVESTMENT',
            'groww': 'INVESTMENT',
            'upstox': 'INVESTMENT',
            'kite': 'INVESTMENT',
            'edelweiss': 'INVESTMENT',
            'hdfc mutual fund': 'INVESTMENT',
            'icici prudential': 'INVESTMENT',
            
            # Insurance
            'lic': 'INSURANCE',
            'hdfc life': 'INSURANCE',
            'icici lombard': 'INSURANCE',
            'bajaj allianz': 'INSURANCE'
        }
        
    def _classify_by_merchant(self, transaction: Transaction, keywords: List[str]) -> ClassificationResult:
        """Classify based on known merchant patterns."""
        description = transaction.description.lower()
        
        for merchant, category in self.merchant_patterns.items():
            if merchant in description:
                return ClassificationResult(
                    category=category,
                    subcategory=self.get_subcategory(category, keywords),
                    confidence_score=0.95,
                    method="rule_based",
                    keywords_found=[merchant],
                    reasoning=f"Matched known merchant: {merchant}"
                )
                
        return None
        
    def _classify_by_keywords(self, transaction: Transaction, keywords: List[str]) -> ClassificationResult:
        """Classify based on keyword matching."""
        best_category = None
        best_score = 0
        matched_keywords = []
        
        for category, category_keywords in self.category_keywords.items():
            # Count keyword matches
            matches = [kw for kw in keywords if kw in category_keywords]
            
            if matches:
                # Calculate match score
                score = len(matches) / len(keywords) if keywords else 0
                
                # Boost score for exact matches of important keywords
                important_matches = [
                    kw for kw in matches 
                    if kw in ['salary', 'rent', 'emi', 'grocery', 'restaurant']
                ]
                if important_matches:
                    score += 0.3
                    
                if score > best_score:
                    best_score = score
                    best_category = category
                    matched_keywords = matches
                    
        if best_category and best_score > 0.3:
            confidence = self.calculate_confidence(matched_keywords, keywords, best_score)
            
            return ClassificationResult(
                category=best_category,
                subcategory=self.get_subcategory(best_category, keywords),
                confidence_score=confidence,
                method="rule_based",
                keywords_found=matched_keywords,
                reasoning=f"Keyword match: {', '.join(matched_keywords)}"
            )
            
        return None
        
    def _classify_by_amount_pattern(self, transaction: Transaction, keywords: List[str]) -> ClassificationResult:
        """Classify based on amount patterns."""
        amount = abs(transaction.amount) if transaction.amount else Decimal('0')
        
        for category, patterns in self.amount_patterns.items():
            min_amt = patterns.get('min_amount', Decimal('0'))
            max_amt = patterns.get('max_amount', Decimal('999999'))
            
            if min_amt <= amount <= max_amt:
                # Check for additional pattern confirmation
                if 'common_amounts' in patterns:
                    if amount in patterns['common_amounts']:
                        return ClassificationResult(
                            category=category,
                            confidence_score=0.6,
                            method="rule_based",
                            reasoning=f"Amount pattern match for {category}"
                        )
                        
                # Lower confidence for just amount range
                return ClassificationResult(
                    category=category,
                    confidence_score=0.4,
                    method="rule_based",
                    reasoning=f"Amount in typical {category} range"
                )
                
        return None
        
    def _classify_by_description_pattern(self, transaction: Transaction, keywords: List[str]) -> ClassificationResult:
        """Classify based on description patterns."""
        description = transaction.description.lower()
        
        # Pattern-based rules
        patterns = {
            'INCOME': [
                r'salary.*credit',
                r'sal.*cr',
                r'payroll',
                r'bonus.*credit',
                r'interest.*credit',
                r'dividend.*cr'
            ],
            'LOAN': [
                r'emi.*debit',
                r'loan.*debit',
                r'.*emi.*',
                r'home.*loan',
                r'personal.*loan'
            ],
            'UTILITIES': [
                r'bill.*payment',
                r'electricity.*bill',
                r'mobile.*recharge',
                r'broadband.*bill'
            ],
            'RENT': [
                r'rent.*payment',
                r'house.*rent',
                r'monthly.*rent'
            ]
        }
        
        import re
        
        for category, category_patterns in patterns.items():
            for pattern in category_patterns:
                if re.search(pattern, description):
                    return ClassificationResult(
                        category=category,
                        confidence_score=0.8,
                        method="rule_based",
                        keywords_found=keywords,
                        reasoning=f"Pattern match: {pattern}"
                    )
                    
        return None
