"""
Excel/CSV parser for extracting bank transaction data from spreadsheet files.
"""
import pandas as pd
from pathlib import Path
from typing import List, Dict, Any, Optional
from decimal import Decimal

from .base_parser import BaseParser


class ExcelParser(BaseParser):
    """Parser for Excel and CSV bank transaction files."""
    
    def __init__(self):
        super().__init__()
        
    def parse(self, file_path: Path, bank_name: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Parse Excel/CSV file and extract transaction data.
        
        Args:
            file_path: Path to Excel/CSV file
            bank_name: Bank name for better parsing
            
        Returns:
            List of transaction dictionaries
        """
        self.logger.info(f"Parsing Excel/CSV file: {file_path}")
        
        try:
            # Read file based on extension
            if file_path.suffix.lower() == '.csv':
                df = pd.read_csv(file_path, encoding='utf-8')
            else:
                df = pd.read_excel(file_path, engine='openpyxl')
                
            self.logger.info(f"Loaded {len(df)} rows from {file_path}")
            
            # Detect and map columns
            column_mapping = self._detect_columns(df.columns.tolist(), bank_name)
            
            if not column_mapping:
                raise ValueError("Could not identify transaction columns in the file")
                
            # Extract transactions
            transactions = self._extract_transactions(df, column_mapping, bank_name)
            
            # Filter valid transactions
            valid_transactions = [txn for txn in transactions if self.validate_transaction(txn)]
            self.logger.info(f"Found {len(valid_transactions)} valid transactions")
            
            return valid_transactions
            
        except Exception as e:
            self.logger.error(f"Error parsing Excel/CSV {file_path}: {str(e)}")
            raise
            
    def _detect_columns(self, columns: List[str], bank_name: Optional[str] = None) -> Dict[str, str]:
        """
        Detect and map column names to transaction fields.
        
        Args:
            columns: List of column names
            bank_name: Bank name for better detection
            
        Returns:
            Dictionary mapping field names to column names
        """
        columns_lower = [col.lower().strip() for col in columns]
        mapping = {}
        
        # Date column detection
        date_keywords = ['date', 'transaction date', 'value date', 'posting date', 'txn date']
        for keyword in date_keywords:
            for i, col in enumerate(columns_lower):
                if keyword in col:
                    mapping['date'] = columns[i]
                    break
            if 'date' in mapping:
                break
                
        # Description column detection
        desc_keywords = ['description', 'particulars', 'details', 'narration', 'memo', 'reference']
        for keyword in desc_keywords:
            for i, col in enumerate(columns_lower):
                if keyword in col:
                    mapping['description'] = columns[i]
                    break
            if 'description' in mapping:
                break
                
        # Amount column detection
        amount_keywords = ['amount', 'transaction amount']
        debit_keywords = ['debit', 'withdrawal', 'dr', 'paid out']
        credit_keywords = ['credit', 'deposit', 'cr', 'paid in']
        
        # Look for separate debit/credit columns first
        for i, col in enumerate(columns_lower):
            if any(keyword in col for keyword in debit_keywords):
                mapping['debit'] = columns[i]
            elif any(keyword in col for keyword in credit_keywords):
                mapping['credit'] = columns[i]
                
        # If no separate debit/credit columns, look for single amount column
        if 'debit' not in mapping and 'credit' not in mapping:
            for keyword in amount_keywords:
                for i, col in enumerate(columns_lower):
                    if keyword in col:
                        mapping['amount'] = columns[i]
                        break
                if 'amount' in mapping:
                    break
                    
        # Balance column detection
        balance_keywords = ['balance', 'running balance', 'available balance']
        for keyword in balance_keywords:
            for i, col in enumerate(columns_lower):
                if keyword in col:
                    mapping['balance'] = columns[i]
                    break
            if 'balance' in mapping:
                break
                
        # Reference number detection
        ref_keywords = ['reference', 'ref no', 'transaction id', 'cheque no', 'utr', 'ref']
        for keyword in ref_keywords:
            for i, col in enumerate(columns_lower):
                if keyword in col:
                    mapping['reference'] = columns[i]
                    break
            if 'reference' in mapping:
                break
                
        # Account number detection
        account_keywords = ['account', 'account number', 'ac no']
        for keyword in account_keywords:
            for i, col in enumerate(columns_lower):
                if keyword in col:
                    mapping['account'] = columns[i]
                    break
            if 'account' in mapping:
                break
                
        self.logger.info(f"Column mapping: {mapping}")
        return mapping
        
    def _extract_transactions(self, df: pd.DataFrame, column_mapping: Dict[str, str], 
                            bank_name: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Extract transactions from DataFrame using column mapping.
        
        Args:
            df: DataFrame containing transaction data
            column_mapping: Mapping of fields to column names
            bank_name: Bank name
            
        Returns:
            List of transaction dictionaries
        """
        transactions = []
        
        for index, row in df.iterrows():
            try:
                transaction = {}
                
                # Extract date
                if 'date' in column_mapping:
                    date_value = row[column_mapping['date']]
                    if pd.notna(date_value):
                        if isinstance(date_value, str):
                            transaction['date'] = self.parse_date(date_value, bank_name)
                        else:
                            # Handle pandas datetime
                            transaction['date'] = pd.to_datetime(date_value).to_pydatetime()
                            
                # Extract description
                if 'description' in column_mapping:
                    desc_value = row[column_mapping['description']]
                    if pd.notna(desc_value):
                        transaction['description'] = self.clean_description(str(desc_value))
                        transaction['raw_text'] = str(desc_value)
                        
                # Extract amount
                amount = None
                if 'debit' in column_mapping and 'credit' in column_mapping:
                    debit_value = row[column_mapping['debit']]
                    credit_value = row[column_mapping['credit']]
                    
                    debit_amount = Decimal('0')
                    credit_amount = Decimal('0')
                    
                    if pd.notna(debit_value) and debit_value != '':
                        debit_amount = self.clean_amount(str(debit_value)) or Decimal('0')
                    if pd.notna(credit_value) and credit_value != '':
                        credit_amount = self.clean_amount(str(credit_value)) or Decimal('0')
                        
                    # Net amount (credit positive, debit negative)
                    amount = credit_amount - debit_amount
                    
                elif 'amount' in column_mapping:
                    amount_value = row[column_mapping['amount']]
                    if pd.notna(amount_value):
                        amount = self.clean_amount(str(amount_value))
                        
                transaction['amount'] = amount
                
                # Extract balance
                if 'balance' in column_mapping:
                    balance_value = row[column_mapping['balance']]
                    if pd.notna(balance_value):
                        transaction['balance'] = self.clean_amount(str(balance_value))
                        
                # Extract reference
                if 'reference' in column_mapping:
                    ref_value = row[column_mapping['reference']]
                    if pd.notna(ref_value):
                        transaction['reference_number'] = str(ref_value)
                        
                # Extract account number
                if 'account' in column_mapping:
                    account_value = row[column_mapping['account']]
                    if pd.notna(account_value):
                        transaction['account_number'] = str(account_value)
                        
                # Set bank name
                transaction['bank_name'] = bank_name
                
                # Skip empty transactions
                if (transaction.get('date') is None and 
                    (transaction.get('amount') is None or transaction.get('amount') == 0) and 
                    not transaction.get('description')):
                    continue
                    
                transactions.append(transaction)
                
            except Exception as e:
                self.logger.warning(f"Error processing row {index}: {str(e)}")
                continue
                
        return transactions
        
    def _detect_file_format(self, df: pd.DataFrame, bank_name: Optional[str] = None) -> str:
        """
        Detect the format/structure of the transaction file.
        
        Args:
            df: DataFrame to analyze
            bank_name: Bank name if known
            
        Returns:
            Format identifier string
        """
        # Analyze column patterns
        columns = [col.lower() for col in df.columns.tolist()]
        
        # Check for common patterns
        if any('debit' in col and 'credit' in col for col in columns):
            return "debit_credit_format"
        elif any('amount' in col for col in columns):
            return "single_amount_format"
        elif bank_name:
            return f"{bank_name.lower()}_format"
        else:
            return "generic_format"
            
    def _handle_bank_specific_format(self, df: pd.DataFrame, bank_name: str) -> List[Dict[str, Any]]:
        """
        Handle bank-specific file formats.
        
        Args:
            df: DataFrame containing transaction data
            bank_name: Name of the bank
            
        Returns:
            List of transaction dictionaries
        """
        if bank_name == 'HDFC':
            return self._parse_hdfc_format(df)
        elif bank_name == 'ICICI':
            return self._parse_icici_format(df)
        elif bank_name == 'SBI':
            return self._parse_sbi_format(df)
        else:
            # Use generic parsing
            column_mapping = self._detect_columns(df.columns.tolist(), bank_name)
            return self._extract_transactions(df, column_mapping, bank_name)
            
    def _parse_hdfc_format(self, df: pd.DataFrame) -> List[Dict[str, Any]]:
        """Parse HDFC-specific format."""
        # HDFC typically uses: Date, Narration, Chq/Ref No, Value Dt, Withdrawal Amt, Deposit Amt, Closing Balance
        mapping = {
            'date': 'Date',
            'description': 'Narration',
            'debit': 'Withdrawal Amt',
            'credit': 'Deposit Amt',
            'balance': 'Closing Balance',
            'reference': 'Chq/Ref No'
        }
        
        # Adjust mapping based on actual columns
        actual_mapping = {}
        for field, expected_col in mapping.items():
            for col in df.columns:
                if expected_col.lower() in col.lower():
                    actual_mapping[field] = col
                    break
                    
        return self._extract_transactions(df, actual_mapping, 'HDFC')
        
    def _parse_icici_format(self, df: pd.DataFrame) -> List[Dict[str, Any]]:
        """Parse ICICI-specific format."""
        # ICICI typically uses different column names
        mapping = {
            'date': 'Value Date',
            'description': 'Transaction Remarks',
            'debit': 'Debit',
            'credit': 'Credit',
            'balance': 'Balance',
            'reference': 'Reference No'
        }
        
        actual_mapping = {}
        for field, expected_col in mapping.items():
            for col in df.columns:
                if expected_col.lower() in col.lower():
                    actual_mapping[field] = col
                    break
                    
        return self._extract_transactions(df, actual_mapping, 'ICICI')
        
    def _parse_sbi_format(self, df: pd.DataFrame) -> List[Dict[str, Any]]:
        """Parse SBI-specific format."""
        # SBI format handling
        mapping = {
            'date': 'Txn Date',
            'description': 'Description',
            'debit': 'Debit',
            'credit': 'Credit',
            'balance': 'Balance',
            'reference': 'Ref No/Cheque No'
        }
        
        actual_mapping = {}
        for field, expected_col in mapping.items():
            for col in df.columns:
                if expected_col.lower() in col.lower():
                    actual_mapping[field] = col
                    break
                    
        return self._extract_transactions(df, actual_mapping, 'SBI')
