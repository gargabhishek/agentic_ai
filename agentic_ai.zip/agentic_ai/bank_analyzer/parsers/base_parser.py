"""
Base parser class for document processing.
"""
import re
import logging
from abc import ABC, abstractmethod
from datetime import datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

from config import BANK_PATTERNS


class BaseParser(ABC):
    """Abstract base class for all document parsers."""
    
    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)
        
    @abstractmethod
    def parse(self, file_path: Path, bank_name: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Parse a file and extract transaction data.
        
        Args:
            file_path: Path to the file to parse
            bank_name: Name of the bank for better parsing
            
        Returns:
            List of dictionaries containing transaction data
        """
        pass
        
    def detect_bank(self, text: str) -> Optional[str]:
        """
        Detect bank name from document text.
        
        Args:
            text: Document text to analyze
            
        Returns:
            Bank name if detected, None otherwise
        """
        bank_keywords = {
            'HDFC': ['hdfc', 'housing development finance', 'hdfc bank'],
            'ICICI': ['icici', 'icici bank', 'industrial credit'],
            'SBI': ['sbi', 'state bank of india', 'state bank'],
            'AXIS': ['axis', 'axis bank'],
            'KOTAK': ['kotak', 'kotak mahindra'],
            'CITI': ['citi', 'citibank', 'citicorp'],
            'YES': ['yes bank', 'yes'],
            'IDFC': ['idfc', 'idfc first'],
            'INDUSIND': ['indusind', 'indusind bank']
        }
        
        text_lower = text.lower()
        
        for bank, keywords in bank_keywords.items():
            for keyword in keywords:
                if keyword in text_lower:
                    self.logger.info(f"Detected bank: {bank}")
                    return bank
                    
        return None
        
    def clean_amount(self, amount_str: str) -> Optional[Decimal]:
        """
        Clean and convert amount string to Decimal.
        
        Args:
            amount_str: Amount string to clean
            
        Returns:
            Decimal amount or None if conversion fails
        """
        if not amount_str:
            return None
            
        # Remove common currency symbols and whitespace
        cleaned = re.sub(r'[₹$€£,\s]', '', str(amount_str))
        
        # Handle negative amounts in parentheses
        if cleaned.startswith('(') and cleaned.endswith(')'):
            cleaned = '-' + cleaned[1:-1]
            
        try:
            return Decimal(cleaned)
        except (InvalidOperation, ValueError):
            self.logger.warning(f"Could not convert amount: {amount_str}")
            return None
            
    def parse_date(self, date_str: str, bank_name: Optional[str] = None) -> Optional[datetime]:
        """
        Parse date string to datetime object.
        
        Args:
            date_str: Date string to parse
            bank_name: Bank name for format detection
            
        Returns:
            Parsed datetime or None if parsing fails
        """
        if not date_str:
            return None
            
        # Common date formats
        date_formats = [
            '%d/%m/%Y',
            '%d-%m-%Y',
            '%Y-%m-%d',
            '%d/%m/%y',
            '%d-%m-%y',
            '%m/%d/%Y',
            '%d %b %Y',
            '%d %B %Y',
            '%b %d, %Y',
            '%B %d, %Y'
        ]
        
        # Bank-specific formats
        if bank_name and bank_name in BANK_PATTERNS:
            bank_format = BANK_PATTERNS[bank_name].get('date_pattern')
            if bank_format:
                # Convert regex pattern to strftime format
                if bank_format == r'\d{2}/\d{2}/\d{4}':
                    date_formats.insert(0, '%d/%m/%Y')
                elif bank_format == r'\d{2}-\d{2}-\d{4}':
                    date_formats.insert(0, '%d-%m-%Y')
                    
        cleaned_date = date_str.strip()
        
        for fmt in date_formats:
            try:
                return datetime.strptime(cleaned_date, fmt)
            except ValueError:
                continue
                
        self.logger.warning(f"Could not parse date: {date_str}")
        return None
        
    def clean_description(self, description: str) -> str:
        """
        Clean transaction description.
        
        Args:
            description: Raw description text
            
        Returns:
            Cleaned description
        """
        if not description:
            return ""
            
        # Remove extra whitespace and special characters
        cleaned = re.sub(r'\s+', ' ', description)
        cleaned = re.sub(r'[^\w\s\-/.]', ' ', cleaned)
        cleaned = cleaned.strip()
        
        # Remove common bank codes and reference numbers
        patterns_to_remove = [
            r'\b[A-Z]{2,4}\d{6,}\b',  # Bank reference codes
            r'\bREF\s*:?\s*\w+\b',    # Reference numbers
            r'\bTXN\s*:?\s*\w+\b',    # Transaction IDs
            r'\b\d{10,}\b'            # Long numbers
        ]
        
        for pattern in patterns_to_remove:
            cleaned = re.sub(pattern, '', cleaned, flags=re.IGNORECASE)
            
        return re.sub(r'\s+', ' ', cleaned).strip()
        
    def extract_reference_number(self, text: str) -> Optional[str]:
        """
        Extract reference number from transaction text.
        
        Args:
            text: Transaction text
            
        Returns:
            Reference number if found
        """
        patterns = [
            r'REF\s*:?\s*(\w+)',
            r'TXN\s*:?\s*(\w+)',
            r'UPI\s*:?\s*(\w+)',
            r'(\d{12,})'
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                return match.group(1)
                
        return None
        
    def categorize_transaction_type(self, amount: Decimal, description: str) -> str:
        """
        Determine if transaction is debit or credit based on amount and description.
        
        Args:
            amount: Transaction amount
            description: Transaction description
            
        Returns:
            'debit' or 'credit'
        """
        # Amount-based determination
        if amount < 0:
            return 'debit'
        elif amount > 0:
            return 'credit'
            
        # Description-based determination for zero amounts
        credit_keywords = ['deposit', 'credit', 'refund', 'salary', 'interest', 'dividend']
        debit_keywords = ['withdrawal', 'debit', 'payment', 'purchase', 'fee', 'charge']
        
        desc_lower = description.lower()
        
        for keyword in credit_keywords:
            if keyword in desc_lower:
                return 'credit'
                
        for keyword in debit_keywords:
            if keyword in desc_lower:
                return 'debit'
                
        return 'debit'  # Default to debit
        
    def validate_transaction(self, transaction: Dict[str, Any]) -> bool:
        """
        Validate extracted transaction data.
        
        Args:
            transaction: Transaction dictionary
            
        Returns:
            True if transaction is valid
        """
        required_fields = ['date', 'description', 'amount']
        
        for field in required_fields:
            if field not in transaction or transaction[field] is None:
                self.logger.warning(f"Missing required field: {field}")
                return False
                
        # Validate amount
        if isinstance(transaction['amount'], (int, float, Decimal)):
            if transaction['amount'] == 0:
                self.logger.warning("Transaction amount is zero")
                return False
        else:
            self.logger.warning("Invalid amount type")
            return False
            
        # Validate date
        if not isinstance(transaction['date'], datetime):
            self.logger.warning("Invalid date type")
            return False
            
        return True
