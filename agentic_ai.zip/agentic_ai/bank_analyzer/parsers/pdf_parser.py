"""
PDF parser for extracting bank transaction data from PDF statements.
"""
import re
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple
from decimal import Decimal

try:
    import pdfplumber
except ImportError:
    pdfplumber = None

from .base_parser import BaseParser


class PDFParser(BaseParser):
    """Parser for PDF bank statements."""
    
    def __init__(self):
        super().__init__()
        if pdfplumber is None:
            raise ImportError("pdfplumber is required for PDF parsing. Install with: pip install pdfplumber")
            
    def parse(self, file_path: Path, bank_name: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Parse PDF file and extract transaction data.
        
        Args:
            file_path: Path to PDF file
            bank_name: Bank name for better parsing
            
        Returns:
            List of transaction dictionaries
        """
        self.logger.info(f"Parsing PDF file: {file_path}")
        
        transactions = []
        
        try:
            with pdfplumber.open(file_path) as pdf:
                full_text = ""
                
                # Extract text from all pages
                for page_num, page in enumerate(pdf.pages):
                    page_text = page.extract_text()
                    if page_text:
                        full_text += page_text + "\n"
                        self.logger.debug(f"Extracted text from page {page_num + 1}")
                        
                # Detect bank if not provided
                if not bank_name:
                    bank_name = self.detect_bank(full_text)
                    
                # Try table extraction first
                table_transactions = self._extract_from_tables(pdf, bank_name)
                if table_transactions:
                    transactions.extend(table_transactions)
                    self.logger.info(f"Extracted {len(table_transactions)} transactions from tables")
                else:
                    # Fallback to text parsing
                    text_transactions = self._extract_from_text(full_text, bank_name)
                    transactions.extend(text_transactions)
                    self.logger.info(f"Extracted {len(text_transactions)} transactions from text")
                    
        except Exception as e:
            self.logger.error(f"Error parsing PDF {file_path}: {str(e)}")
            raise
            
        # Filter valid transactions
        valid_transactions = [txn for txn in transactions if self.validate_transaction(txn)]
        self.logger.info(f"Found {len(valid_transactions)} valid transactions")
        
        return valid_transactions
        
    def _extract_from_tables(self, pdf, bank_name: Optional[str] = None) -> List[Dict[str, Any]]:
        """Extract transactions from PDF tables."""
        transactions = []
        
        for page in pdf.pages:
            tables = page.extract_tables()
            
            for table in tables:
                if not table or len(table) < 2:  # Need header + at least one data row
                    continue
                    
                header = table[0]
                if not self._is_transaction_table(header):
                    continue
                    
                # Map column indices
                column_mapping = self._map_columns(header, bank_name)
                
                # Process data rows
                for row in table[1:]:
                    if len(row) < len(header):
                        continue
                        
                    transaction = self._extract_transaction_from_row(row, column_mapping, bank_name)
                    if transaction:
                        transactions.append(transaction)
                        
        return transactions
        
    def _extract_from_text(self, text: str, bank_name: Optional[str] = None) -> List[Dict[str, Any]]:
        """Extract transactions from PDF text using pattern matching."""
        transactions = []
        lines = text.split('\n')
        
        # Bank-specific patterns
        if bank_name == 'HDFC':
            transactions = self._parse_hdfc_text(lines)
        elif bank_name == 'ICICI':
            transactions = self._parse_icici_text(lines)
        elif bank_name == 'SBI':
            transactions = self._parse_sbi_text(lines)
        else:
            # Generic pattern matching
            transactions = self._parse_generic_text(lines)
            
        return transactions
        
    def _is_transaction_table(self, header: List[str]) -> bool:
        """Check if table header indicates a transaction table."""
        header_lower = [cell.lower() if cell else "" for cell in header]
        
        required_indicators = ['date', 'amount']
        optional_indicators = ['description', 'debit', 'credit', 'balance', 'particulars']
        
        found_required = sum(1 for indicator in required_indicators 
                           if any(indicator in cell for cell in header_lower))
        found_optional = sum(1 for indicator in optional_indicators 
                           if any(indicator in cell for cell in header_lower))
        
        return found_required >= 1 and found_optional >= 1
        
    def _map_columns(self, header: List[str], bank_name: Optional[str] = None) -> Dict[str, int]:
        """Map table columns to transaction fields."""
        header_lower = [cell.lower() if cell else "" for cell in header]
        
        mapping = {}
        
        # Date column
        for i, cell in enumerate(header_lower):
            if any(keyword in cell for keyword in ['date', 'value date', 'txn date']):
                mapping['date'] = i
                break
                
        # Description column
        for i, cell in enumerate(header_lower):
            if any(keyword in cell for keyword in ['description', 'particulars', 'details', 'narration']):
                mapping['description'] = i
                break
                
        # Amount columns
        for i, cell in enumerate(header_lower):
            if any(keyword in cell for keyword in ['debit', 'withdrawal', 'dr']):
                mapping['debit'] = i
            elif any(keyword in cell for keyword in ['credit', 'deposit', 'cr']):
                mapping['credit'] = i
            elif 'amount' in cell and 'debit' not in mapping and 'credit' not in mapping:
                mapping['amount'] = i
                
        # Balance column
        for i, cell in enumerate(header_lower):
            if any(keyword in cell for keyword in ['balance', 'bal']):
                mapping['balance'] = i
                break
                
        # Reference column
        for i, cell in enumerate(header_lower):
            if any(keyword in cell for keyword in ['ref', 'reference', 'cheque']):
                mapping['reference'] = i
                break
                
        return mapping
        
    def _extract_transaction_from_row(self, row: List[str], column_mapping: Dict[str, int], 
                                    bank_name: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Extract transaction data from table row."""
        transaction = {}
        
        try:
            # Extract date
            if 'date' in column_mapping:
                date_str = row[column_mapping['date']]
                transaction['date'] = self.parse_date(date_str, bank_name)
                
            # Extract description
            if 'description' in column_mapping:
                desc = row[column_mapping['description']] or ""
                transaction['description'] = self.clean_description(desc)
                transaction['raw_text'] = desc
                
            # Extract amount
            amount = None
            if 'debit' in column_mapping and 'credit' in column_mapping:
                debit_str = row[column_mapping['debit']] or "0"
                credit_str = row[column_mapping['credit']] or "0"
                
                debit_amount = self.clean_amount(debit_str) or Decimal('0')
                credit_amount = self.clean_amount(credit_str) or Decimal('0')
                
                if debit_amount > 0:
                    amount = -debit_amount  # Debit as negative
                elif credit_amount > 0:
                    amount = credit_amount   # Credit as positive
                    
            elif 'amount' in column_mapping:
                amount_str = row[column_mapping['amount']]
                amount = self.clean_amount(amount_str)
                
            transaction['amount'] = amount
            
            # Extract balance
            if 'balance' in column_mapping:
                balance_str = row[column_mapping['balance']]
                transaction['balance'] = self.clean_amount(balance_str)
                
            # Extract reference
            if 'reference' in column_mapping:
                ref_str = row[column_mapping['reference']]
                transaction['reference_number'] = ref_str
                
            # Validate minimum required fields
            if transaction.get('date') and transaction.get('amount') is not None:
                return transaction
                
        except Exception as e:
            self.logger.warning(f"Error extracting transaction from row: {str(e)}")
            
        return None
        
    def _parse_hdfc_text(self, lines: List[str]) -> List[Dict[str, Any]]:
        """Parse HDFC bank statement text."""
        transactions = []
        
        # HDFC pattern: DD/MM/YYYY Description Amount Balance
        pattern = r'(\d{2}/\d{2}/\d{4})\s+(.+?)\s+([\d,]+\.\d{2})\s+([\d,]+\.\d{2})'
        
        for line in lines:
            match = re.search(pattern, line)
            if match:
                date_str, description, amount_str, balance_str = match.groups()
                
                transaction = {
                    'date': self.parse_date(date_str, 'HDFC'),
                    'description': self.clean_description(description),
                    'amount': self.clean_amount(amount_str),
                    'balance': self.clean_amount(balance_str),
                    'raw_text': line.strip()
                }
                
                if self.validate_transaction(transaction):
                    transactions.append(transaction)
                    
        return transactions
        
    def _parse_icici_text(self, lines: List[str]) -> List[Dict[str, Any]]:
        """Parse ICICI bank statement text."""
        transactions = []
        
        # ICICI pattern: DD-MM-YYYY Description Dr/Cr Amount Balance
        pattern = r'(\d{2}-\d{2}-\d{4})\s+(.+?)\s+(Dr|Cr)\s+([\d,]+\.\d{2})\s+([\d,]+\.\d{2})'
        
        for line in lines:
            match = re.search(pattern, line)
            if match:
                date_str, description, dr_cr, amount_str, balance_str = match.groups()
                
                amount = self.clean_amount(amount_str)
                if dr_cr == 'Dr':
                    amount = -amount  # Debit as negative
                    
                transaction = {
                    'date': self.parse_date(date_str, 'ICICI'),
                    'description': self.clean_description(description),
                    'amount': amount,
                    'balance': self.clean_amount(balance_str),
                    'raw_text': line.strip()
                }
                
                if self.validate_transaction(transaction):
                    transactions.append(transaction)
                    
        return transactions
        
    def _parse_sbi_text(self, lines: List[str]) -> List[Dict[str, Any]]:
        """Parse SBI bank statement text."""
        transactions = []
        
        # SBI pattern: DD/MM/YYYY Description Debit Credit Balance
        pattern = r'(\d{2}/\d{2}/\d{4})\s+(.+?)\s+([\d,]*\.?\d*)\s+([\d,]*\.?\d*)\s+([\d,]+\.\d{2})'
        
        for line in lines:
            match = re.search(pattern, line)
            if match:
                date_str, description, debit_str, credit_str, balance_str = match.groups()
                
                debit = self.clean_amount(debit_str) or Decimal('0')
                credit = self.clean_amount(credit_str) or Decimal('0')
                
                amount = credit - debit  # Net amount
                
                transaction = {
                    'date': self.parse_date(date_str, 'SBI'),
                    'description': self.clean_description(description),
                    'amount': amount,
                    'balance': self.clean_amount(balance_str),
                    'raw_text': line.strip()
                }
                
                if self.validate_transaction(transaction):
                    transactions.append(transaction)
                    
        return transactions
        
    def _parse_generic_text(self, lines: List[str]) -> List[Dict[str, Any]]:
        """Parse generic bank statement text."""
        transactions = []
        
        # Generic patterns for different date formats and amounts
        patterns = [
            r'(\d{1,2}/\d{1,2}/\d{4})\s+(.+?)\s+([\d,]+\.\d{2})',  # DD/MM/YYYY
            r'(\d{1,2}-\d{1,2}-\d{4})\s+(.+?)\s+([\d,]+\.\d{2})',  # DD-MM-YYYY
            r'(\d{4}-\d{1,2}-\d{1,2})\s+(.+?)\s+([\d,]+\.\d{2})',  # YYYY-MM-DD
        ]
        
        for line in lines:
            for pattern in patterns:
                match = re.search(pattern, line)
                if match:
                    date_str, description, amount_str = match.groups()
                    
                    transaction = {
                        'date': self.parse_date(date_str),
                        'description': self.clean_description(description),
                        'amount': self.clean_amount(amount_str),
                        'raw_text': line.strip()
                    }
                    
                    if self.validate_transaction(transaction):
                        transactions.append(transaction)
                        break  # Found match, move to next line
                        
        return transactions
