"""
Validation utilities for the Bank Transaction Analyzer.
"""
import re
from pathlib import Path
from typing import Optional, Dict, Any, List
from decimal import Decimal
from datetime import datetime

from config import settings


def validate_file(file_path: Path) -> bool:
    """
    Validate file for processing.
    
    Args:
        file_path: Path to file to validate
        
    Returns:
        True if file is valid for processing
    """
    if not file_path.exists():
        return False
        
    if not file_path.is_file():
        return False
        
    # Check file extension
    extension = file_path.suffix[1:].lower()
    if extension not in settings.allowed_extensions:
        return False
        
    # Check file size
    file_size_mb = file_path.stat().st_size / (1024 * 1024)
    if file_size_mb > settings.max_file_size_mb:
        return False
        
    return True


def validate_transaction(transaction: Dict[str, Any]) -> tuple:
    """
    Validate transaction data.
    
    Args:
        transaction: Transaction dictionary to validate
        
    Returns:
        Tuple of (is_valid, error_messages)
    """
    errors = []
    
    # Required fields
    required_fields = ['date', 'description', 'amount']
    
    for field in required_fields:
        if field not in transaction or transaction[field] is None:
            errors.append(f"Missing required field: {field}")
            
    # Validate date
    if 'date' in transaction and transaction['date'] is not None:
        if not isinstance(transaction['date'], datetime):
            try:
                # Try to parse string date
                datetime.fromisoformat(str(transaction['date']))
            except:
                errors.append("Invalid date format")
                
    # Validate amount
    if 'amount' in transaction and transaction['amount'] is not None:
        try:
            amount = Decimal(str(transaction['amount']))
            if amount == 0:
                errors.append("Transaction amount cannot be zero")
        except:
            errors.append("Invalid amount format")
            
    # Validate description
    if 'description' in transaction:
        desc = transaction['description']
        if isinstance(desc, str) and len(desc.strip()) == 0:
            errors.append("Description cannot be empty")
            
    # Validate category (if present)
    if 'category' in transaction and transaction['category']:
        from config import TRANSACTION_CATEGORIES
        if transaction['category'] not in TRANSACTION_CATEGORIES:
            errors.append(f"Invalid category: {transaction['category']}")
            
    return len(errors) == 0, errors


def validate_amount(amount_str: str) -> tuple:
    """
    Validate and parse amount string.
    
    Args:
        amount_str: Amount string to validate
        
    Returns:
        Tuple of (is_valid, parsed_amount, error_message)
    """
    if not amount_str:
        return False, None, "Amount cannot be empty"
        
    try:
        # Clean amount string
        cleaned = re.sub(r'[₹$€£,\s]', '', str(amount_str))
        
        # Handle negative amounts in parentheses
        if cleaned.startswith('(') and cleaned.endswith(')'):
            cleaned = '-' + cleaned[1:-1]
            
        amount = Decimal(cleaned)
        
        # Validate range
        if amount < Decimal('-999999999'):
            return False, None, "Amount too small"
        if amount > Decimal('999999999'):
            return False, None, "Amount too large"
            
        return True, amount, None
        
    except Exception as e:
        return False, None, f"Invalid amount format: {str(e)}"


def validate_date(date_str: str) -> tuple:
    """
    Validate and parse date string.
    
    Args:
        date_str: Date string to validate
        
    Returns:
        Tuple of (is_valid, parsed_date, error_message)
    """
    if not date_str:
        return False, None, "Date cannot be empty"
        
    # Common date formats
    date_formats = [
        '%Y-%m-%d',
        '%d/%m/%Y',
        '%d-%m-%Y',
        '%m/%d/%Y',
        '%d %b %Y',
        '%d %B %Y',
        '%b %d, %Y',
        '%B %d, %Y'
    ]
    
    for fmt in date_formats:
        try:
            parsed_date = datetime.strptime(date_str.strip(), fmt)
            
            # Validate date range (not too far in past or future)
            min_date = datetime(1900, 1, 1)
            max_date = datetime(2100, 12, 31)
            
            if parsed_date < min_date or parsed_date > max_date:
                return False, None, "Date out of valid range"
                
            return True, parsed_date, None
            
        except ValueError:
            continue
            
    return False, None, "Invalid date format"


def validate_bank_name(bank_name: str) -> bool:
    """
    Validate bank name.
    
    Args:
        bank_name: Bank name to validate
        
    Returns:
        True if valid bank name
    """
    if not bank_name or not isinstance(bank_name, str):
        return False
        
    # Check minimum length
    if len(bank_name.strip()) < 2:
        return False
        
    # Check for valid characters (letters, numbers, spaces, basic punctuation)
    if not re.match(r'^[a-zA-Z0-9\s\-&.]+$', bank_name):
        return False
        
    return True


def validate_account_number(account_number: str) -> bool:
    """
    Validate account number format.
    
    Args:
        account_number: Account number to validate
        
    Returns:
        True if valid account number format
    """
    if not account_number or not isinstance(account_number, str):
        return False
        
    # Remove spaces and hyphens
    cleaned = re.sub(r'[\s\-]', '', account_number)
    
    # Check if it's numeric
    if not cleaned.isdigit():
        return False
        
    # Check length (typically 9-18 digits for most banks)
    if len(cleaned) < 9 or len(cleaned) > 18:
        return False
        
    return True


def validate_category_mapping(mapping: Dict[str, str]) -> tuple:
    """
    Validate category mapping configuration.
    
    Args:
        mapping: Dictionary mapping descriptions to categories
        
    Returns:
        Tuple of (is_valid, error_messages)
    """
    errors = []
    
    if not isinstance(mapping, dict):
        errors.append("Category mapping must be a dictionary")
        return False, errors
        
    from config import TRANSACTION_CATEGORIES
    valid_categories = set(TRANSACTION_CATEGORIES.keys())
    
    for description, category in mapping.items():
        if not isinstance(description, str) or not description.strip():
            errors.append(f"Invalid description key: {description}")
            
        if not isinstance(category, str) or category not in valid_categories:
            errors.append(f"Invalid category: {category}")
            
    return len(errors) == 0, errors


def validate_api_request(request_data: Dict[str, Any], required_fields: List[str]) -> tuple:
    """
    Validate API request data.
    
    Args:
        request_data: Request data dictionary
        required_fields: List of required field names
        
    Returns:
        Tuple of (is_valid, error_messages)
    """
    errors = []
    
    if not isinstance(request_data, dict):
        errors.append("Request data must be a JSON object")
        return False, errors
        
    # Check required fields
    for field in required_fields:
        if field not in request_data:
            errors.append(f"Missing required field: {field}")
        elif request_data[field] is None:
            errors.append(f"Field '{field}' cannot be null")
            
    return len(errors) == 0, errors


def sanitize_input(input_str: str, max_length: int = 1000) -> str:
    """
    Sanitize user input string.
    
    Args:
        input_str: Input string to sanitize
        max_length: Maximum allowed length
        
    Returns:
        Sanitized string
    """
    if not input_str:
        return ""
        
    # Convert to string and strip
    sanitized = str(input_str).strip()
    
    # Limit length
    if len(sanitized) > max_length:
        sanitized = sanitized[:max_length]
        
    # Remove potentially dangerous characters
    sanitized = re.sub(r'[<>"\']', '', sanitized)
    
    return sanitized


def validate_file_upload(file_data: bytes, filename: str) -> tuple:
    """
    Validate uploaded file data.
    
    Args:
        file_data: File content as bytes
        filename: Original filename
        
    Returns:
        Tuple of (is_valid, error_message)
    """
    # Check file size
    file_size_mb = len(file_data) / (1024 * 1024)
    if file_size_mb > settings.max_file_size_mb:
        return False, f"File size ({file_size_mb:.1f}MB) exceeds limit ({settings.max_file_size_mb}MB)"
        
    # Check file extension
    extension = Path(filename).suffix[1:].lower()
    if extension not in settings.allowed_extensions:
        return False, f"File type '{extension}' not allowed. Allowed types: {', '.join(settings.allowed_extensions)}"
        
    # Basic file content validation
    if len(file_data) == 0:
        return False, "File is empty"
        
    # Check for minimum file size (100 bytes)
    if len(file_data) < 100:
        return False, "File too small to contain valid transaction data"
        
    return True, None
