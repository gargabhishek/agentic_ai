"""
Helper utility functions for the Bank Transaction Analyzer.
"""
import re
import hashlib
from decimal import Decimal
from typing import Optional, Union, List, Dict, Any
from datetime import datetime, timedelta


def format_currency(amount: Union[Decimal, float, int], currency: str = "₹") -> str:
    """
    Format amount as currency string.
    
    Args:
        amount: Amount to format
        currency: Currency symbol
        
    Returns:
        Formatted currency string
    """
    if amount is None:
        return f"{currency}0.00"
        
    amount = float(amount)
    
    # Handle negative amounts
    if amount < 0:
        return f"-{currency}{abs(amount):,.2f}"
    
    return f"{currency}{amount:,.2f}"


def clean_text(text: str) -> str:
    """
    Clean and normalize text.
    
    Args:
        text: Text to clean
        
    Returns:
        Cleaned text
    """
    if not text:
        return ""
        
    # Remove extra whitespace
    text = re.sub(r'\s+', ' ', text)
    
    # Remove special characters except basic punctuation
    text = re.sub(r'[^\w\s\-.,!?]', '', text)
    
    return text.strip()


def sanitize_filename(filename: str) -> str:
    """
    Sanitize filename for safe file operations.
    
    Args:
        filename: Original filename
        
    Returns:
        Sanitized filename
    """
    # Remove/replace invalid characters
    filename = re.sub(r'[<>:"/\\|?*]', '_', filename)
    
    # Remove leading/trailing dots and spaces
    filename = filename.strip('. ')
    
    # Ensure it's not empty
    if not filename:
        filename = "unnamed_file"
        
    return filename


def generate_transaction_id(transaction_data: Dict[str, Any]) -> str:
    """
    Generate a unique ID for a transaction based on its data.
    
    Args:
        transaction_data: Transaction data dictionary
        
    Returns:
        Unique transaction ID
    """
    # Create a string from key transaction fields
    key_fields = [
        str(transaction_data.get('date', '')),
        str(transaction_data.get('description', '')),
        str(transaction_data.get('amount', '')),
        str(transaction_data.get('account_number', ''))
    ]
    
    data_string = '|'.join(key_fields)
    
    # Generate hash
    hash_object = hashlib.md5(data_string.encode())
    return hash_object.hexdigest()[:12]  # Use first 12 characters


def parse_amount_range(amount_str: str) -> tuple:
    """
    Parse amount range string like "100-500" or ">1000".
    
    Args:
        amount_str: Amount range string
        
    Returns:
        Tuple of (min_amount, max_amount)
    """
    amount_str = amount_str.strip()
    
    if '-' in amount_str:
        # Range like "100-500"
        parts = amount_str.split('-')
        if len(parts) == 2:
            try:
                min_amt = Decimal(parts[0].strip())
                max_amt = Decimal(parts[1].strip())
                return (min_amt, max_amt)
            except:
                pass
                
    elif amount_str.startswith('>'):
        # Greater than like ">1000"
        try:
            min_amt = Decimal(amount_str[1:].strip())
            return (min_amt, None)
        except:
            pass
            
    elif amount_str.startswith('<'):
        # Less than like "<500"
        try:
            max_amt = Decimal(amount_str[1:].strip())
            return (None, max_amt)
        except:
            pass
            
    else:
        # Single amount
        try:
            amt = Decimal(amount_str)
            return (amt, amt)
        except:
            pass
            
    return (None, None)


def calculate_date_range(period: str) -> tuple:
    """
    Calculate date range for common periods.
    
    Args:
        period: Period string ('last_week', 'last_month', 'last_year', etc.)
        
    Returns:
        Tuple of (start_date, end_date)
    """
    today = datetime.now().date()
    
    if period == 'today':
        return (today, today)
    elif period == 'yesterday':
        yesterday = today - timedelta(days=1)
        return (yesterday, yesterday)
    elif period == 'last_week':
        start = today - timedelta(days=7)
        return (start, today)
    elif period == 'last_month':
        start = today - timedelta(days=30)
        return (start, today)
    elif period == 'last_3_months':
        start = today - timedelta(days=90)
        return (start, today)
    elif period == 'last_6_months':
        start = today - timedelta(days=180)
        return (start, today)
    elif period == 'last_year':
        start = today - timedelta(days=365)
        return (start, today)
    elif period == 'this_month':
        start = today.replace(day=1)
        return (start, today)
    elif period == 'this_year':
        start = today.replace(month=1, day=1)
        return (start, today)
    else:
        # Default to last month
        start = today - timedelta(days=30)
        return (start, today)


def group_transactions_by_period(transactions: List[Dict], period: str = 'month') -> Dict[str, List[Dict]]:
    """
    Group transactions by time period.
    
    Args:
        transactions: List of transaction dictionaries
        period: Grouping period ('day', 'week', 'month', 'year')
        
    Returns:
        Dictionary with period keys and transaction lists
    """
    groups = {}
    
    for transaction in transactions:
        date = transaction.get('date')
        if not date:
            continue
            
        if isinstance(date, str):
            try:
                date = datetime.fromisoformat(date).date()
            except:
                continue
        elif isinstance(date, datetime):
            date = date.date()
            
        # Generate period key
        if period == 'day':
            key = date.strftime('%Y-%m-%d')
        elif period == 'week':
            # Get Monday of the week
            monday = date - timedelta(days=date.weekday())
            key = monday.strftime('%Y-W%U')
        elif period == 'month':
            key = date.strftime('%Y-%m')
        elif period == 'year':
            key = date.strftime('%Y')
        else:
            key = date.strftime('%Y-%m')
            
        if key not in groups:
            groups[key] = []
        groups[key].append(transaction)
        
    return groups


def calculate_category_totals(transactions: List[Dict]) -> Dict[str, Decimal]:
    """
    Calculate total amounts by category.
    
    Args:
        transactions: List of transaction dictionaries
        
    Returns:
        Dictionary mapping categories to total amounts
    """
    totals = {}
    
    for transaction in transactions:
        category = transaction.get('category', 'OTHER')
        amount = transaction.get('amount', 0)
        
        if isinstance(amount, (int, float)):
            amount = Decimal(str(amount))
        elif not isinstance(amount, Decimal):
            continue
            
        if category not in totals:
            totals[category] = Decimal('0')
        totals[category] += amount
        
    return totals


def detect_recurring_transactions(transactions: List[Dict], min_occurrences: int = 3) -> List[Dict]:
    """
    Detect recurring transactions based on amount and description patterns.
    
    Args:
        transactions: List of transaction dictionaries
        min_occurrences: Minimum occurrences to consider as recurring
        
    Returns:
        List of recurring transaction patterns
    """
    # Group by description and amount
    patterns = {}
    
    for transaction in transactions:
        description = clean_text(transaction.get('description', ''))
        amount = transaction.get('amount', 0)
        
        # Create a pattern key
        key = f"{description[:50]}_{amount}"
        
        if key not in patterns:
            patterns[key] = {
                'description': description,
                'amount': amount,
                'transactions': [],
                'dates': []
            }
            
        patterns[key]['transactions'].append(transaction)
        if transaction.get('date'):
            patterns[key]['dates'].append(transaction['date'])
            
    # Filter patterns with minimum occurrences
    recurring = []
    for pattern_data in patterns.values():
        if len(pattern_data['transactions']) >= min_occurrences:
            # Calculate frequency
            dates = sorted(pattern_data['dates'])
            if len(dates) > 1:
                total_days = (dates[-1] - dates[0]).days if isinstance(dates[0], datetime) else 0
                frequency = len(dates) / max(total_days / 30, 1)  # per month
                
                pattern_data['frequency_per_month'] = round(frequency, 2)
                pattern_data['first_occurrence'] = dates[0]
                pattern_data['last_occurrence'] = dates[-1]
                
                recurring.append(pattern_data)
                
    return recurring
