"""
Data encryption utilities for sensitive information.
"""
import base64
import hashlib
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from typing import Union, Optional

from config import settings


class DataEncryption:
    """Handle encryption/decryption of sensitive data."""
    
    def __init__(self, key: Optional[str] = None):
        """
        Initialize encryption with key.
        
        Args:
            key: Optional encryption key (uses settings.encryption_key if not provided)
        """
        self.key = key or settings.encryption_key
        self._fernet = None
        
    def _get_fernet(self) -> Fernet:
        """Get or create Fernet cipher instance."""
        if self._fernet is None:
            # Derive key from the provided key string
            key_bytes = self.key.encode()
            
            # Use PBKDF2 to derive a proper key
            kdf = PBKDF2HMAC(
                algorithm=hashes.SHA256(),
                length=32,
                salt=b'bank_analyzer_salt',  # Static salt for consistency
                iterations=100000,
            )
            derived_key = base64.urlsafe_b64encode(kdf.derive(key_bytes))
            self._fernet = Fernet(derived_key)
            
        return self._fernet
        
    def encrypt(self, data: str) -> str:
        """
        Encrypt string data.
        
        Args:
            data: String to encrypt
            
        Returns:
            Base64 encoded encrypted string
        """
        if not data:
            return ""
            
        fernet = self._get_fernet()
        encrypted_bytes = fernet.encrypt(data.encode())
        return base64.urlsafe_b64encode(encrypted_bytes).decode()
        
    def decrypt(self, encrypted_data: str) -> str:
        """
        Decrypt encrypted string data.
        
        Args:
            encrypted_data: Base64 encoded encrypted string
            
        Returns:
            Decrypted string
        """
        if not encrypted_data:
            return ""
            
        try:
            fernet = self._get_fernet()
            encrypted_bytes = base64.urlsafe_b64decode(encrypted_data.encode())
            decrypted_bytes = fernet.decrypt(encrypted_bytes)
            return decrypted_bytes.decode()
        except Exception:
            # Return empty string if decryption fails
            return ""
            
    def hash_data(self, data: str, salt: Optional[str] = None) -> str:
        """
        Create a hash of the data (one-way).
        
        Args:
            data: Data to hash
            salt: Optional salt (uses default if not provided)
            
        Returns:
            Hexadecimal hash string
        """
        if not data:
            return ""
            
        salt_bytes = (salt or "default_salt").encode()
        data_bytes = data.encode()
        
        # Create hash
        hash_obj = hashlib.pbkdf2_hmac('sha256', data_bytes, salt_bytes, 100000)
        return hash_obj.hex()


# Global encryption instance
_encryption = None


def get_encryption() -> DataEncryption:
    """Get global encryption instance."""
    global _encryption
    if _encryption is None:
        _encryption = DataEncryption()
    return _encryption


def encrypt_data(data: str) -> str:
    """Encrypt data using global encryption instance."""
    return get_encryption().encrypt(data)


def decrypt_data(encrypted_data: str) -> str:
    """Decrypt data using global encryption instance."""
    return get_encryption().decrypt(encrypted_data)


def hash_data(data: str, salt: Optional[str] = None) -> str:
    """Hash data using global encryption instance."""
    return get_encryption().hash_data(data, salt)
