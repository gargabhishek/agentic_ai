"""
Authentication utilities for the Bank Transaction Analyzer.
"""
import jwt
import bcrypt
from datetime import datetime, timedelta
from typing import Optional, Dict, Any

from config import settings


def hash_password(password: str) -> str:
    """
    Hash a password using bcrypt.
    
    Args:
        password: Plain text password
        
    Returns:
        Hashed password string
    """
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed.decode('utf-8')


def verify_password(password: str, hashed_password: str) -> bool:
    """
    Verify a password against its hash.
    
    Args:
        password: Plain text password
        hashed_password: Hashed password to verify against
        
    Returns:
        True if password matches
    """
    try:
        return bcrypt.checkpw(password.encode('utf-8'), hashed_password.encode('utf-8'))
    except Exception:
        return False


def create_access_token(data: Dict[str, Any], expires_delta: Optional[timedelta] = None) -> str:
    """
    Create a JWT access token.
    
    Args:
        data: Data to encode in the token
        expires_delta: Optional expiration time delta
        
    Returns:
        JWT token string
    """
    to_encode = data.copy()
    
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(hours=24)
        
    to_encode.update({"exp": expire})
    
    encoded_jwt = jwt.encode(to_encode, settings.secret_key, algorithm="HS256")
    return encoded_jwt


def verify_access_token(token: str) -> Optional[Dict[str, Any]]:
    """
    Verify and decode a JWT access token.
    
    Args:
        token: JWT token string
        
    Returns:
        Decoded token data if valid, None otherwise
    """
    try:
        payload = jwt.decode(token, settings.secret_key, algorithms=["HS256"])
        return payload
    except jwt.PyJWTError:
        return None


def authenticate_user(username: str, password: str) -> bool:
    """
    Authenticate a user (placeholder implementation).
    
    Args:
        username: Username
        password: Password
        
    Returns:
        True if authentication successful
    """
    # This is a placeholder implementation
    # In a real application, you would check against a user database
    
    # For demo purposes, accept admin/admin
    if username == "admin" and password == "admin":
        return True
        
    return False


def get_current_user(token: str) -> Optional[Dict[str, Any]]:
    """
    Get current user from JWT token.
    
    Args:
        token: JWT token
        
    Returns:
        User data if token is valid
    """
    payload = verify_access_token(token)
    if payload is None:
        return None
        
    username = payload.get("sub")
    if username is None:
        return None
        
    # Return user data (in real app, would fetch from database)
    return {
        "username": username,
        "is_admin": payload.get("is_admin", False)
    }
