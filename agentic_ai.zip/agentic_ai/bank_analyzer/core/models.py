"""
Core data models for the Bank Transaction Analyzer.
"""
from datetime import datetime
from decimal import Decimal
from enum import Enum
from typing import List, Optional, Dict, Any
from dataclasses import dataclass, field
from pydantic import BaseModel, validator


class TransactionType(str, Enum):
    """Transaction type enumeration."""
    DEBIT = "debit"
    CREDIT = "credit"


class ProcessingStatus(str, Enum):
    """Processing status enumeration."""
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class Transaction:
    """Core transaction data model."""
    id: Optional[str] = None
    date: Optional[datetime] = None
    description: str = ""
    amount: Decimal = Decimal("0.00")
    transaction_type: TransactionType = TransactionType.DEBIT
    category: Optional[str] = None
    subcategory: Optional[str] = None
    confidence_score: float = 0.0
    source_file: Optional[str] = None
    bank_name: Optional[str] = None
    account_number: Optional[str] = None
    balance: Optional[Decimal] = None
    reference_number: Optional[str] = None
    
    # Classification metadata
    classification_method: Optional[str] = None  # 'ai', 'rule_based', 'manual'
    keywords_found: List[str] = field(default_factory=list)
    raw_text: Optional[str] = None
    
    # Processing metadata
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    processed: bool = False
    
    def __post_init__(self):
        """Post-initialization processing."""
        if self.amount < 0:
            self.transaction_type = TransactionType.DEBIT
            self.amount = abs(self.amount)
        else:
            self.transaction_type = TransactionType.CREDIT
            
    def to_dict(self) -> Dict[str, Any]:
        """Convert transaction to dictionary."""
        return {
            'id': self.id,
            'date': self.date.isoformat() if self.date else None,
            'description': self.description,
            'amount': float(self.amount),
            'transaction_type': self.transaction_type.value,
            'category': self.category,
            'subcategory': self.subcategory,
            'confidence_score': self.confidence_score,
            'source_file': self.source_file,
            'bank_name': self.bank_name,
            'account_number': self.account_number,
            'balance': float(self.balance) if self.balance else None,
            'reference_number': self.reference_number,
            'classification_method': self.classification_method,
            'keywords_found': self.keywords_found,
            'raw_text': self.raw_text,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
            'processed': self.processed
        }


@dataclass
class TransactionBatch:
    """Batch of transactions for processing."""
    id: str
    transactions: List[Transaction] = field(default_factory=list)
    source_file: str = ""
    file_type: str = ""
    bank_name: Optional[str] = None
    processing_status: ProcessingStatus = ProcessingStatus.PENDING
    total_transactions: int = 0
    processed_transactions: int = 0
    failed_transactions: int = 0
    created_at: datetime = field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = None
    error_messages: List[str] = field(default_factory=list)
    
    def add_transaction(self, transaction: Transaction):
        """Add a transaction to the batch."""
        transaction.source_file = self.source_file
        self.transactions.append(transaction)
        self.total_transactions = len(self.transactions)
        
    def mark_processed(self, transaction_id: str, success: bool = True):
        """Mark a transaction as processed."""
        if success:
            self.processed_transactions += 1
        else:
            self.failed_transactions += 1
            
        # Update batch status
        if self.processed_transactions + self.failed_transactions == self.total_transactions:
            self.processing_status = ProcessingStatus.COMPLETED
            self.completed_at = datetime.utcnow()
            
    def get_progress(self) -> float:
        """Get processing progress as percentage."""
        if self.total_transactions == 0:
            return 0.0
        return (self.processed_transactions + self.failed_transactions) / self.total_transactions * 100
        
    def to_dict(self) -> Dict[str, Any]:
        """Convert batch to dictionary."""
        return {
            'id': self.id,
            'source_file': self.source_file,
            'file_type': self.file_type,
            'bank_name': self.bank_name,
            'processing_status': self.processing_status.value,
            'total_transactions': self.total_transactions,
            'processed_transactions': self.processed_transactions,
            'failed_transactions': self.failed_transactions,
            'progress': self.get_progress(),
            'created_at': self.created_at.isoformat(),
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
            'error_messages': self.error_messages
        }


class TransactionRequest(BaseModel):
    """Pydantic model for transaction API requests."""
    date: datetime
    description: str
    amount: float
    transaction_type: TransactionType
    bank_name: Optional[str] = None
    account_number: Optional[str] = None
    
    @validator('amount')
    def amount_must_be_positive(cls, v):
        if v <= 0:
            raise ValueError('Amount must be positive')
        return v
        
    @validator('description')
    def description_must_not_be_empty(cls, v):
        if not v.strip():
            raise ValueError('Description cannot be empty')
        return v.strip()


class ClassificationResult(BaseModel):
    """Result of transaction classification."""
    category: str
    subcategory: Optional[str] = None
    confidence_score: float
    method: str  # 'ai', 'rule_based', 'manual'
    keywords_found: List[str] = []
    reasoning: Optional[str] = None


class AnalyticsReport(BaseModel):
    """Analytics report structure."""
    period_start: datetime
    period_end: datetime
    total_transactions: int
    total_income: float
    total_expenses: float
    net_amount: float
    category_breakdown: Dict[str, float]
    monthly_trends: Dict[str, float]
    top_expenses: List[Dict[str, Any]]
    generated_at: datetime = field(default_factory=datetime.utcnow)
