"""
Core transaction processing engine that orchestrates the entire pipeline.
"""
import uuid
import logging
from pathlib import Path
from typing import List, Optional, Dict, Any, Union
from decimal import Decimal

from ..parsers import PDFParser, ExcelParser, BaseParser
from ..classifiers import AITransactionClassifier, RuleBasedClassifier
from ..storage import FileStorageManager
from ..utils import setup_logger, validate_file
from ..security import encrypt_data
from .models import Transaction, TransactionBatch, ProcessingStatus, ClassificationResult
from config import settings


class TransactionProcessor:
    """Main processor for handling bank transaction analysis pipeline."""
    
    def __init__(self, use_ai: bool = True, use_encryption: bool = True):
        """
        Initialize the transaction processor.
        
        Args:
            use_ai: Whether to use AI-powered classification
            use_encryption: Whether to encrypt sensitive data
        """
        self.logger = setup_logger(__name__)
        self.use_ai = use_ai and settings.enable_ai_classification
        self.use_encryption = use_encryption
        
        # Initialize parsers
        self.parsers: Dict[str, BaseParser] = {
            'pdf': PDFParser(),
            'xlsx': ExcelParser(),
            'xls': ExcelParser(),
        }
        
        # Initialize classifiers
        self.ai_classifier = AITransactionClassifier() if self.use_ai else None
        self.rule_classifier = RuleBasedClassifier()
        
        # Initialize file storage
        self.storage_manager = FileStorageManager()
        
        self.logger.info(f"TransactionProcessor initialized - AI: {self.use_ai}, Encryption: {self.use_encryption}")
        
    def process_file(self, file_path: Union[str, Path], bank_name: Optional[str] = None) -> TransactionBatch:
        """
        Process a single file containing bank transactions.
        
        Args:
            file_path: Path to the file to process
            bank_name: Name of the bank (for better parsing)
            
        Returns:
            TransactionBatch: Processed batch of transactions
        """
        file_path = Path(file_path)
        self.logger.info(f"Starting to process file: {file_path}")
        
        # Validate file
        if not validate_file(file_path):
            raise ValueError(f"Invalid file: {file_path}")
            
        # Create batch
        batch_id = str(uuid.uuid4())
        batch = TransactionBatch(
            id=batch_id,
            source_file=str(file_path),
            file_type=file_path.suffix[1:].lower(),
            bank_name=bank_name,
            processing_status=ProcessingStatus.PROCESSING
        )
        
        try:
            # Step 1: Parse file
            self.logger.info(f"Parsing file: {file_path}")
            raw_transactions = self._parse_file(file_path, bank_name)
            
            # Step 2: Create transaction objects
            for raw_txn in raw_transactions:
                transaction = self._create_transaction(raw_txn, str(file_path), bank_name)
                batch.add_transaction(transaction)
                
            self.logger.info(f"Extracted {batch.total_transactions} transactions from {file_path}")
            
            # Step 3: Classify transactions
            self._classify_batch(batch)
            
            # Step 4: Save to CSV files
            self._save_batch(batch)
            
            batch.processing_status = ProcessingStatus.COMPLETED
            self.logger.info(f"Successfully processed file: {file_path}")
            
        except Exception as e:
            self.logger.error(f"Error processing file {file_path}: {str(e)}")
            batch.processing_status = ProcessingStatus.FAILED
            batch.error_messages.append(str(e))
            raise
            
        return batch
        
    def process_multiple_files(self, file_paths: List[Union[str, Path]], 
                             bank_name: Optional[str] = None) -> List[TransactionBatch]:
        """
        Process multiple files.
        
        Args:
            file_paths: List of file paths to process
            bank_name: Name of the bank
            
        Returns:
            List[TransactionBatch]: List of processed batches
        """
        batches = []
        
        for file_path in file_paths:
            try:
                batch = self.process_file(file_path, bank_name)
                batches.append(batch)
            except Exception as e:
                self.logger.error(f"Failed to process {file_path}: {str(e)}")
                # Create failed batch
                failed_batch = TransactionBatch(
                    id=str(uuid.uuid4()),
                    source_file=str(file_path),
                    file_type=Path(file_path).suffix[1:].lower(),
                    bank_name=bank_name,
                    processing_status=ProcessingStatus.FAILED
                )
                failed_batch.error_messages.append(str(e))
                batches.append(failed_batch)
                
        return batches
        
    def classify_transaction(self, transaction: Transaction) -> ClassificationResult:
        """
        Classify a single transaction.
        
        Args:
            transaction: Transaction to classify
            
        Returns:
            ClassificationResult: Classification result
        """
        # Try AI classification first if enabled
        if self.use_ai and self.ai_classifier:
            try:
                result = self.ai_classifier.classify(transaction)
                if result.confidence_score >= settings.model_confidence_threshold:
                    return result
            except Exception as e:
                self.logger.warning(f"AI classification failed: {str(e)}, falling back to rule-based")
                
        # Fallback to rule-based classification
        if settings.fallback_to_rule_based:
            return self.rule_classifier.classify(transaction)
        else:
            # Return unknown classification
            return ClassificationResult(
                category="OTHER",
                confidence_score=0.0,
                method="none",
                reasoning="No classification method available"
            )
            
    def get_analytics(self, start_date: Optional[str] = None, 
                     end_date: Optional[str] = None) -> Dict[str, Any]:
        """
        Generate analytics report for transactions.
        
        Args:
            start_date: Start date for analysis (YYYY-MM-DD)
            end_date: End date for analysis (YYYY-MM-DD)
            
        Returns:
            Dict containing analytics data
        """
        # Generate analytics from stored CSV files
        period = "custom" if start_date or end_date else "all_time"
        analytics_file = self.storage_manager.generate_analytics_report(period)
        
        if analytics_file:
            self.logger.info(f"Generated analytics report: {analytics_file}")
            return {"analytics_file": analytics_file, "message": f"Analytics saved to {analytics_file}"}
        else:
            return {"error": "No transaction data found for analytics"}
        
    def _parse_file(self, file_path: Path, bank_name: Optional[str] = None) -> List[Dict[str, Any]]:
        """Parse file and extract raw transaction data."""
        file_extension = file_path.suffix[1:].lower()
        
        if file_extension not in self.parsers:
            raise ValueError(f"Unsupported file type: {file_extension}")
            
        parser = self.parsers[file_extension]
        return parser.parse(file_path, bank_name)
        
    def _create_transaction(self, raw_data: Dict[str, Any], source_file: str, 
                          bank_name: Optional[str] = None) -> Transaction:
        """Create Transaction object from raw data."""
        transaction = Transaction(
            id=str(uuid.uuid4()),
            date=raw_data.get('date'),
            description=raw_data.get('description', ''),
            amount=Decimal(str(raw_data.get('amount', 0))),
            source_file=source_file,
            bank_name=bank_name or raw_data.get('bank_name'),
            account_number=raw_data.get('account_number'),
            balance=Decimal(str(raw_data.get('balance', 0))) if raw_data.get('balance') else None,
            reference_number=raw_data.get('reference_number'),
            raw_text=raw_data.get('raw_text')
        )
        
        return transaction
        
    def _classify_batch(self, batch: TransactionBatch):
        """Classify all transactions in a batch."""
        for transaction in batch.transactions:
            try:
                result = self.classify_transaction(transaction)
                transaction.category = result.category
                transaction.subcategory = result.subcategory
                transaction.confidence_score = result.confidence_score
                transaction.classification_method = result.method
                transaction.keywords_found = result.keywords_found
                transaction.processed = True
                
                batch.mark_processed(transaction.id, success=True)
                
            except Exception as e:
                self.logger.error(f"Failed to classify transaction {transaction.id}: {str(e)}")
                transaction.category = "OTHER"
                transaction.confidence_score = 0.0
                transaction.classification_method = "failed"
                
                batch.mark_processed(transaction.id, success=False)
                
    def _save_batch(self, batch: TransactionBatch):
        """Save batch to CSV files."""
        try:
            # Encrypt sensitive data if enabled
            if self.use_encryption:
                for transaction in batch.transactions:
                    if transaction.account_number:
                        transaction.account_number = encrypt_data(transaction.account_number)
                        
            # Save to file storage
            file_info = self.storage_manager.save_transaction_batch(batch)
            
            self.logger.info(f"Saved batch {batch.id} with {len(batch.transactions)} transactions to {file_info['output_directory']}")
            self.logger.info(f"Files created: {file_info['transactions_csv']}")
            
        except Exception as e:
            self.logger.error(f"Failed to save batch {batch.id}: {str(e)}")
            raise
            
    def get_transaction_summary(self, batch_id: str) -> Dict[str, Any]:
        """Get summary for a specific batch."""
        # For file-based storage, we can list recent files
        processed_files = self.storage_manager.list_processed_files()
        
        # Find files that match the batch_id (if they contain it in filename)
        matching_files = [f for f in processed_files if batch_id in f['file_name']]
        
        if matching_files:
            return {
                "batch_id": batch_id,
                "files": matching_files,
                "message": f"Found {len(matching_files)} files for batch {batch_id}"
            }
        else:
            return {
                "batch_id": batch_id,
                "message": "Batch not found. Use list_processed_files() to see all files."
            }
        
    def search_transactions(self, query: str, category: Optional[str] = None, 
                          limit: int = 100) -> List[Dict[str, Any]]:
        """Search transactions by description or category in stored CSV files."""
        try:
            import pandas as pd
            
            # Find all transaction CSV files
            processed_files = self.storage_manager.list_processed_files()
            
            matching_transactions = []
            
            for file_info in processed_files:
                try:
                    # Read CSV file
                    df = pd.read_csv(file_info['file_path'])
                    
                    # Filter by query in description
                    if query:
                        mask = df['Description'].str.contains(query, case=False, na=False)
                        df = df[mask]
                    
                    # Filter by category if specified
                    if category:
                        df = df[df['Category'].str.upper() == category.upper()]
                    
                    # Convert to dict and add to results
                    for _, row in df.iterrows():
                        matching_transactions.append(row.to_dict())
                        
                        if len(matching_transactions) >= limit:
                            break
                            
                    if len(matching_transactions) >= limit:
                        break
                        
                except Exception as e:
                    self.logger.warning(f"Could not search in {file_info['file_path']}: {str(e)}")
                    continue
                    
            self.logger.info(f"Found {len(matching_transactions)} matching transactions")
            return matching_transactions[:limit]
            
        except Exception as e:
            self.logger.error(f"Error searching transactions: {str(e)}")
            return []
            
    def list_processed_files(self) -> List[Dict[str, Any]]:
        """List all processed files."""
        return self.storage_manager.list_processed_files()
        
    def get_storage_stats(self) -> Dict[str, Any]:
        """Get storage statistics."""
        return self.storage_manager.get_storage_stats()
