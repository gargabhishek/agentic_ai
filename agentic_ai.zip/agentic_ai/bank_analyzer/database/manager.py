"""
Database manager for the Bank Transaction Analyzer.
"""
import json
import logging
from datetime import datetime, timedelta
from decimal import Decimal
from typing import List, Dict, Any, Optional, Tuple
from sqlalchemy import create_engine, func, and_, or_, desc
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.exc import SQLAlchemyError

from .models import Base, TransactionDB, BatchDB, CategoryRuleDB, AnalyticsDB, AuditLogDB
from ..core.models import Transaction, TransactionBatch, ProcessingStatus
from ..utils.logger import get_logger
from config import settings


class DatabaseManager:
    """Manages all database operations for the Bank Transaction Analyzer."""
    
    def __init__(self, database_url: Optional[str] = None):
        """
        Initialize database manager.
        
        Args:
            database_url: Optional database URL override
        """
        self.logger = get_logger(__name__)
        self.database_url = database_url or settings.database_url
        
        # Create engine
        self.engine = create_engine(
            self.database_url,
            echo=settings.debug_mode,  # Log SQL queries in debug mode
            pool_pre_ping=True,  # Enable connection health checks
        )
        
        # Create session factory
        self.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=self.engine)
        
        # Create tables
        self._create_tables()
        
        self.logger.info(f"Database manager initialized with URL: {self.database_url}")
        
    def _create_tables(self):
        """Create database tables if they don't exist."""
        try:
            Base.metadata.create_all(bind=self.engine)
            self.logger.info("Database tables created/verified")
        except Exception as e:
            self.logger.error(f"Error creating database tables: {str(e)}")
            raise
            
    def get_session(self) -> Session:
        """Get a new database session."""
        return self.SessionLocal()
        
    def save_transaction(self, transaction: Transaction) -> bool:
        """
        Save a transaction to the database.
        
        Args:
            transaction: Transaction object to save
            
        Returns:
            True if saved successfully
        """
        session = self.get_session()
        try:
            # Convert Transaction to TransactionDB
            db_transaction = TransactionDB(
                id=transaction.id,
                date=transaction.date,
                description=transaction.description,
                amount=transaction.amount,
                transaction_type=transaction.transaction_type,
                category=transaction.category,
                subcategory=transaction.subcategory,
                confidence_score=transaction.confidence_score,
                source_file=transaction.source_file,
                bank_name=transaction.bank_name,
                account_number=transaction.account_number,
                balance=transaction.balance,
                reference_number=transaction.reference_number,
                classification_method=transaction.classification_method,
                keywords_found=json.dumps(transaction.keywords_found) if transaction.keywords_found else None,
                raw_text=transaction.raw_text,
                created_at=transaction.created_at,
                updated_at=transaction.updated_at,
                processed=transaction.processed
            )
            
            # Merge (insert or update)
            session.merge(db_transaction)
            session.commit()
            
            self.logger.debug(f"Saved transaction {transaction.id}")
            return True
            
        except SQLAlchemyError as e:
            session.rollback()
            self.logger.error(f"Error saving transaction {transaction.id}: {str(e)}")
            return False
        finally:
            session.close()
            
    def save_batch(self, batch: TransactionBatch) -> bool:
        """
        Save a transaction batch to the database.
        
        Args:
            batch: TransactionBatch object to save
            
        Returns:
            True if saved successfully
        """
        session = self.get_session()
        try:
            # Convert TransactionBatch to BatchDB
            db_batch = BatchDB(
                id=batch.id,
                source_file=batch.source_file,
                file_type=batch.file_type,
                bank_name=batch.bank_name,
                processing_status=batch.processing_status,
                total_transactions=batch.total_transactions,
                processed_transactions=batch.processed_transactions,
                failed_transactions=batch.failed_transactions,
                created_at=batch.created_at,
                completed_at=batch.completed_at,
                error_messages=json.dumps(batch.error_messages) if batch.error_messages else None
            )
            
            session.merge(db_batch)
            session.commit()
            
            self.logger.debug(f"Saved batch {batch.id}")
            return True
            
        except SQLAlchemyError as e:
            session.rollback()
            self.logger.error(f"Error saving batch {batch.id}: {str(e)}")
            return False
        finally:
            session.close()
            
    def get_transactions(self, filters: Optional[Dict[str, Any]] = None, 
                        limit: int = 1000, offset: int = 0) -> List[Dict[str, Any]]:
        """
        Retrieve transactions with optional filters.
        
        Args:
            filters: Optional filters (category, date_from, date_to, etc.)
            limit: Maximum number of transactions to return
            offset: Number of transactions to skip
            
        Returns:
            List of transaction dictionaries
        """
        session = self.get_session()
        try:
            query = session.query(TransactionDB)
            
            # Apply filters
            if filters:
                if 'category' in filters:
                    query = query.filter(TransactionDB.category == filters['category'])
                    
                if 'date_from' in filters:
                    query = query.filter(TransactionDB.date >= filters['date_from'])
                    
                if 'date_to' in filters:
                    query = query.filter(TransactionDB.date <= filters['date_to'])
                    
                if 'bank_name' in filters:
                    query = query.filter(TransactionDB.bank_name == filters['bank_name'])
                    
                if 'amount_min' in filters:
                    query = query.filter(TransactionDB.amount >= filters['amount_min'])
                    
                if 'amount_max' in filters:
                    query = query.filter(TransactionDB.amount <= filters['amount_max'])
                    
                if 'search' in filters:
                    search_term = f"%{filters['search']}%"
                    query = query.filter(TransactionDB.description.ilike(search_term))
                    
            # Order by date descending
            query = query.order_by(desc(TransactionDB.date))
            
            # Apply pagination
            transactions = query.offset(offset).limit(limit).all()
            
            # Convert to dictionaries
            result = []
            for txn in transactions:
                txn_dict = {
                    'id': txn.id,
                    'date': txn.date.isoformat() if txn.date else None,
                    'description': txn.description,
                    'amount': float(txn.amount) if txn.amount else 0.0,
                    'transaction_type': txn.transaction_type.value if txn.transaction_type else None,
                    'category': txn.category,
                    'subcategory': txn.subcategory,
                    'confidence_score': float(txn.confidence_score) if txn.confidence_score else 0.0,
                    'source_file': txn.source_file,
                    'bank_name': txn.bank_name,
                    'balance': float(txn.balance) if txn.balance else None,
                    'reference_number': txn.reference_number,
                    'classification_method': txn.classification_method,
                    'keywords_found': json.loads(txn.keywords_found) if txn.keywords_found else [],
                    'created_at': txn.created_at.isoformat() if txn.created_at else None,
                    'processed': txn.processed
                }
                result.append(txn_dict)
                
            return result
            
        except SQLAlchemyError as e:
            self.logger.error(f"Error retrieving transactions: {str(e)}")
            return []
        finally:
            session.close()
            
    def get_analytics(self, start_date: Optional[str] = None, 
                     end_date: Optional[str] = None) -> Dict[str, Any]:
        """
        Generate analytics for transactions.
        
        Args:
            start_date: Start date for analysis (YYYY-MM-DD)
            end_date: End date for analysis (YYYY-MM-DD)
            
        Returns:
            Dictionary containing analytics data
        """
        session = self.get_session()
        try:
            # Set default date range if not provided
            if not end_date:
                end_date = datetime.now().date()
            else:
                end_date = datetime.fromisoformat(end_date).date()
                
            if not start_date:
                start_date = end_date - timedelta(days=30)
            else:
                start_date = datetime.fromisoformat(start_date).date()
                
            # Base query for the date range
            base_query = session.query(TransactionDB).filter(
                and_(
                    TransactionDB.date >= start_date,
                    TransactionDB.date <= end_date
                )
            )
            
            # Total transactions
            total_transactions = base_query.count()
            
            # Income vs Expenses
            income_query = base_query.filter(TransactionDB.amount > 0)
            expense_query = base_query.filter(TransactionDB.amount < 0)
            
            total_income = session.query(func.sum(TransactionDB.amount)).filter(
                and_(
                    TransactionDB.date >= start_date,
                    TransactionDB.date <= end_date,
                    TransactionDB.amount > 0
                )
            ).scalar() or Decimal('0')
            
            total_expenses = abs(session.query(func.sum(TransactionDB.amount)).filter(
                and_(
                    TransactionDB.date >= start_date,
                    TransactionDB.date <= end_date,
                    TransactionDB.amount < 0
                )
            ).scalar() or Decimal('0'))
            
            net_amount = total_income - total_expenses
            
            # Category breakdown
            category_stats = session.query(
                TransactionDB.category,
                func.sum(TransactionDB.amount).label('total'),
                func.count().label('count')
            ).filter(
                and_(
                    TransactionDB.date >= start_date,
                    TransactionDB.date <= end_date
                )
            ).group_by(TransactionDB.category).all()
            
            category_breakdown = {}
            for category, total, count in category_stats:
                category_breakdown[category or 'OTHER'] = {
                    'total': float(total),
                    'count': count,
                    'average': float(total / count) if count > 0 else 0.0
                }
                
            # Monthly trends (if date range > 30 days)
            monthly_trends = {}
            if (end_date - start_date).days > 30:
                monthly_stats = session.query(
                    func.date_trunc('month', TransactionDB.date).label('month'),
                    func.sum(TransactionDB.amount).label('total')
                ).filter(
                    and_(
                        TransactionDB.date >= start_date,
                        TransactionDB.date <= end_date
                    )
                ).group_by(func.date_trunc('month', TransactionDB.date)).all()
                
                for month, total in monthly_stats:
                    monthly_trends[month.strftime('%Y-%m')] = float(total)
                    
            # Top expenses
            top_expenses = session.query(
                TransactionDB.description,
                TransactionDB.amount,
                TransactionDB.category,
                TransactionDB.date
            ).filter(
                and_(
                    TransactionDB.date >= start_date,
                    TransactionDB.date <= end_date,
                    TransactionDB.amount < 0
                )
            ).order_by(TransactionDB.amount).limit(10).all()
            
            top_expenses_list = [
                {
                    'description': exp.description,
                    'amount': float(abs(exp.amount)),
                    'category': exp.category,
                    'date': exp.date.isoformat()
                }
                for exp in top_expenses
            ]
            
            return {
                'period_start': start_date.isoformat(),
                'period_end': end_date.isoformat(),
                'total_transactions': total_transactions,
                'total_income': float(total_income),
                'total_expenses': float(total_expenses),
                'net_amount': float(net_amount),
                'category_breakdown': category_breakdown,
                'monthly_trends': monthly_trends,
                'top_expenses': top_expenses_list,
                'generated_at': datetime.utcnow().isoformat()
            }
            
        except SQLAlchemyError as e:
            self.logger.error(f"Error generating analytics: {str(e)}")
            return {}
        finally:
            session.close()
            
    def search_transactions(self, query: str, category: Optional[str] = None, 
                          limit: int = 100) -> List[Transaction]:
        """
        Search transactions by description or category.
        
        Args:
            query: Search query string
            category: Optional category filter
            limit: Maximum number of results
            
        Returns:
            List of matching transactions
        """
        session = self.get_session()
        try:
            db_query = session.query(TransactionDB)
            
            # Text search in description
            if query:
                search_term = f"%{query}%"
                db_query = db_query.filter(TransactionDB.description.ilike(search_term))
                
            # Category filter
            if category:
                db_query = db_query.filter(TransactionDB.category == category)
                
            # Order by relevance (could be improved with full-text search)
            db_query = db_query.order_by(desc(TransactionDB.date))
            
            results = db_query.limit(limit).all()
            
            # Convert to Transaction objects
            transactions = []
            for db_txn in results:
                transaction = Transaction(
                    id=db_txn.id,
                    date=db_txn.date,
                    description=db_txn.description,
                    amount=db_txn.amount,
                    transaction_type=db_txn.transaction_type,
                    category=db_txn.category,
                    subcategory=db_txn.subcategory,
                    confidence_score=float(db_txn.confidence_score) if db_txn.confidence_score else 0.0,
                    source_file=db_txn.source_file,
                    bank_name=db_txn.bank_name,
                    account_number=db_txn.account_number,
                    balance=db_txn.balance,
                    reference_number=db_txn.reference_number,
                    classification_method=db_txn.classification_method,
                    keywords_found=json.loads(db_txn.keywords_found) if db_txn.keywords_found else [],
                    raw_text=db_txn.raw_text,
                    created_at=db_txn.created_at,
                    updated_at=db_txn.updated_at,
                    processed=db_txn.processed
                )
                transactions.append(transaction)
                
            return transactions
            
        except SQLAlchemyError as e:
            self.logger.error(f"Error searching transactions: {str(e)}")
            return []
        finally:
            session.close()
            
    def get_batch_summary(self, batch_id: str) -> Dict[str, Any]:
        """
        Get summary for a specific batch.
        
        Args:
            batch_id: Batch ID to get summary for
            
        Returns:
            Dictionary containing batch summary
        """
        session = self.get_session()
        try:
            batch = session.query(BatchDB).filter(BatchDB.id == batch_id).first()
            
            if not batch:
                return {}
                
            # Get transaction statistics for this batch
            txn_stats = session.query(
                func.count().label('count'),
                func.sum(TransactionDB.amount).label('total_amount'),
                func.avg(TransactionDB.amount).label('avg_amount')
            ).filter(TransactionDB.source_file == batch.source_file).first()
            
            # Get category distribution
            category_dist = session.query(
                TransactionDB.category,
                func.count().label('count')
            ).filter(TransactionDB.source_file == batch.source_file)\
             .group_by(TransactionDB.category).all()
            
            return {
                'batch_id': batch.id,
                'source_file': batch.source_file,
                'file_type': batch.file_type,
                'bank_name': batch.bank_name,
                'processing_status': batch.processing_status.value,
                'total_transactions': batch.total_transactions,
                'processed_transactions': batch.processed_transactions,
                'failed_transactions': batch.failed_transactions,
                'created_at': batch.created_at.isoformat(),
                'completed_at': batch.completed_at.isoformat() if batch.completed_at else None,
                'statistics': {
                    'transaction_count': txn_stats.count if txn_stats else 0,
                    'total_amount': float(txn_stats.total_amount) if txn_stats and txn_stats.total_amount else 0.0,
                    'average_amount': float(txn_stats.avg_amount) if txn_stats and txn_stats.avg_amount else 0.0
                },
                'category_distribution': {
                    category or 'OTHER': count for category, count in category_dist
                }
            }
            
        except SQLAlchemyError as e:
            self.logger.error(f"Error getting batch summary: {str(e)}")
            return {}
        finally:
            session.close()
            
    def cleanup_old_data(self, days: int = 365) -> int:
        """
        Clean up old transaction data.
        
        Args:
            days: Number of days to keep (delete older data)
            
        Returns:
            Number of records deleted
        """
        session = self.get_session()
        try:
            cutoff_date = datetime.utcnow() - timedelta(days=days)
            
            # Delete old transactions
            deleted_count = session.query(TransactionDB)\
                .filter(TransactionDB.created_at < cutoff_date)\
                .delete()
                
            # Delete old batches
            deleted_batches = session.query(BatchDB)\
                .filter(BatchDB.created_at < cutoff_date)\
                .delete()
                
            session.commit()
            
            self.logger.info(f"Cleaned up {deleted_count} transactions and {deleted_batches} batches older than {days} days")
            return deleted_count + deleted_batches
            
        except SQLAlchemyError as e:
            session.rollback()
            self.logger.error(f"Error during cleanup: {str(e)}")
            return 0
        finally:
            session.close()
