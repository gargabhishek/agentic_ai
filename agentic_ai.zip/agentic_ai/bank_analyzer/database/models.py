"""
Database models for the Bank Transaction Analyzer.
"""
from datetime import datetime
from decimal import Decimal
from sqlalchemy import Column, Integer, String, DateTime, Numeric, Boolean, Text, Enum
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship

from ..core.models import TransactionType, ProcessingStatus

Base = declarative_base()


class TransactionDB(Base):
    """Database model for transactions."""
    __tablename__ = 'transactions'
    
    id = Column(String(50), primary_key=True)
    date = Column(DateTime, nullable=False, index=True)
    description = Column(Text, nullable=False)
    amount = Column(Numeric(15, 2), nullable=False)
    transaction_type = Column(Enum(TransactionType), nullable=False)
    category = Column(String(50), nullable=True, index=True)
    subcategory = Column(String(50), nullable=True)
    confidence_score = Column(Numeric(5, 3), default=0.0)
    
    # Source information
    source_file = Column(String(500), nullable=True)
    bank_name = Column(String(100), nullable=True, index=True)
    account_number = Column(String(100), nullable=True)  # Encrypted
    balance = Column(Numeric(15, 2), nullable=True)
    reference_number = Column(String(100), nullable=True)
    
    # Classification metadata
    classification_method = Column(String(20), nullable=True)
    keywords_found = Column(Text, nullable=True)  # JSON string
    raw_text = Column(Text, nullable=True)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    processed = Column(Boolean, default=False, nullable=False)
    
    def __repr__(self):
        return f"<Transaction(id='{self.id}', date='{self.date}', amount='{self.amount}', category='{self.category}')>"


class BatchDB(Base):
    """Database model for transaction batches."""
    __tablename__ = 'batches'
    
    id = Column(String(50), primary_key=True)
    source_file = Column(String(500), nullable=False)
    file_type = Column(String(10), nullable=False)
    bank_name = Column(String(100), nullable=True)
    processing_status = Column(Enum(ProcessingStatus), nullable=False)
    
    # Processing statistics
    total_transactions = Column(Integer, default=0)
    processed_transactions = Column(Integer, default=0)
    failed_transactions = Column(Integer, default=0)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    completed_at = Column(DateTime, nullable=True)
    
    # Error tracking
    error_messages = Column(Text, nullable=True)  # JSON string
    
    def __repr__(self):
        return f"<Batch(id='{self.id}', file='{self.source_file}', status='{self.processing_status}')>"


class CategoryRuleDB(Base):
    """Database model for custom category rules."""
    __tablename__ = 'category_rules'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    rule_name = Column(String(100), nullable=False)
    category = Column(String(50), nullable=False)
    subcategory = Column(String(50), nullable=True)
    
    # Rule conditions
    description_pattern = Column(Text, nullable=True)  # Regex pattern
    amount_min = Column(Numeric(15, 2), nullable=True)
    amount_max = Column(Numeric(15, 2), nullable=True)
    keywords = Column(Text, nullable=True)  # JSON string
    
    # Rule metadata
    priority = Column(Integer, default=50)  # Higher number = higher priority
    is_active = Column(Boolean, default=True)
    created_by = Column(String(100), nullable=True)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    
    def __repr__(self):
        return f"<CategoryRule(id='{self.id}', name='{self.rule_name}', category='{self.category}')>"


class UserDB(Base):
    """Database model for users (if authentication is needed)."""
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    username = Column(String(100), unique=True, nullable=False)
    email = Column(String(200), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    
    # User preferences
    default_bank = Column(String(100), nullable=True)
    preferred_categories = Column(Text, nullable=True)  # JSON string
    
    # Account status
    is_active = Column(Boolean, default=True)
    is_admin = Column(Boolean, default=False)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    last_login = Column(DateTime, nullable=True)
    
    def __repr__(self):
        return f"<User(id='{self.id}', username='{self.username}')>"


class AnalyticsDB(Base):
    """Database model for storing analytics snapshots."""
    __tablename__ = 'analytics'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    report_type = Column(String(50), nullable=False)  # 'monthly', 'category', 'trend'
    period_start = Column(DateTime, nullable=False)
    period_end = Column(DateTime, nullable=False)
    
    # Analytics data (JSON)
    data = Column(Text, nullable=False)  # JSON string with analytics results
    
    # Metadata
    generated_by = Column(String(100), nullable=True)
    generated_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    
    def __repr__(self):
        return f"<Analytics(id='{self.id}', type='{self.report_type}', period='{self.period_start} to {self.period_end}')>"


class AuditLogDB(Base):
    """Database model for audit logging."""
    __tablename__ = 'audit_logs'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    action = Column(String(100), nullable=False)  # 'create', 'update', 'delete', 'classify'
    entity_type = Column(String(50), nullable=False)  # 'transaction', 'batch', 'rule'
    entity_id = Column(String(100), nullable=False)
    
    # Change details
    old_values = Column(Text, nullable=True)  # JSON string
    new_values = Column(Text, nullable=True)  # JSON string
    
    # User and session info
    user_id = Column(String(100), nullable=True)
    session_id = Column(String(100), nullable=True)
    ip_address = Column(String(50), nullable=True)
    
    # Timestamp
    timestamp = Column(DateTime, default=datetime.utcnow, nullable=False)
    
    def __repr__(self):
        return f"<AuditLog(id='{self.id}', action='{self.action}', entity='{self.entity_type}:{self.entity_id}')>"
