"""
CSV export utilities for transaction data.
"""
import csv
import json
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional
import pandas as pd

from ..core.models import Transaction, TransactionBatch
from ..utils.logger import get_logger


class CSVExporter:
    """Handles CSV export operations for transaction data."""
    
    def __init__(self):
        self.logger = get_logger(__name__)
        
    def export_transactions_to_csv(self, transactions: List[Transaction], 
                                 output_file: Path, include_metadata: bool = True) -> bool:
        """
        Export transactions to CSV file.
        
        Args:
            transactions: List of Transaction objects
            output_file: Path to output CSV file
            include_metadata: Whether to include classification metadata
            
        Returns:
            True if export successful
        """
        
        if not transactions:
            self.logger.warning("No transactions to export")
            return False
            
        try:
            # Prepare CSV headers
            headers = self._get_csv_headers(include_metadata)
            
            # Prepare data rows
            rows = []
            for txn in transactions:
                row = self._transaction_to_csv_row(txn, include_metadata)
                rows.append(row)
                
            # Sort by date (newest first)
            rows.sort(key=lambda x: x['Date'], reverse=True)
            
            # Write to CSV
            output_file.parent.mkdir(parents=True, exist_ok=True)
            
            with open(output_file, 'w', newline='', encoding='utf-8') as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=headers)
                writer.writeheader()
                writer.writerows(rows)
                
            self.logger.info(f"Exported {len(transactions)} transactions to {output_file}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to export transactions to CSV: {str(e)}")
            return False
            
    def _get_csv_headers(self, include_metadata: bool = True) -> List[str]:
        """Get CSV header columns."""
        
        basic_headers = [
            'Date',
            'Description', 
            'Amount',
            'Transaction_Type',
            'Category',
            'Subcategory',
            'Bank_Name',
            'Balance',
            'Reference_Number'
        ]
        
        if include_metadata:
            metadata_headers = [
                'Confidence_Score',
                'Classification_Method',
                'Keywords_Found',
                'Source_File',
                'Transaction_ID',
                'Created_At'
            ]
            basic_headers.extend(metadata_headers)
            
        return basic_headers
        
    def _transaction_to_csv_row(self, txn: Transaction, include_metadata: bool = True) -> Dict[str, str]:
        """Convert Transaction object to CSV row."""
        
        row = {
            'Date': txn.date.strftime('%Y-%m-%d') if txn.date else '',
            'Description': txn.description or '',
            'Amount': f"{float(txn.amount):.2f}" if txn.amount else '0.00',
            'Transaction_Type': txn.transaction_type.value if txn.transaction_type else '',
            'Category': txn.category or '',
            'Subcategory': txn.subcategory or '',
            'Bank_Name': txn.bank_name or '',
            'Balance': f"{float(txn.balance):.2f}" if txn.balance else '',
            'Reference_Number': txn.reference_number or ''
        }
        
        if include_metadata:
            row.update({
                'Confidence_Score': f"{txn.confidence_score:.3f}",
                'Classification_Method': txn.classification_method or '',
                'Keywords_Found': ', '.join(txn.keywords_found) if txn.keywords_found else '',
                'Source_File': Path(txn.source_file).name if txn.source_file else '',
                'Transaction_ID': txn.id or '',
                'Created_At': txn.created_at.strftime('%Y-%m-%d %H:%M:%S') if txn.created_at else ''
            })
            
        return row
        
    def export_category_summary(self, transactions: List[Transaction], 
                              output_file: Path) -> bool:
        """
        Export category-wise summary to CSV.
        
        Args:
            transactions: List of Transaction objects
            output_file: Path to output CSV file
            
        Returns:
            True if export successful
        """
        
        try:
            # Calculate category statistics
            category_stats = {}
            
            for txn in transactions:
                category = txn.category or 'OTHER'
                amount = float(txn.amount) if txn.amount else 0.0
                
                if category not in category_stats:
                    category_stats[category] = {
                        'count': 0,
                        'total_amount': 0.0,
                        'income': 0.0,
                        'expenses': 0.0
                    }
                    
                category_stats[category]['count'] += 1
                category_stats[category]['total_amount'] += amount
                
                if amount > 0:
                    category_stats[category]['income'] += amount
                else:
                    category_stats[category]['expenses'] += abs(amount)
                    
            # Prepare CSV data
            csv_data = []
            for category, stats in category_stats.items():
                avg_amount = stats['total_amount'] / stats['count'] if stats['count'] > 0 else 0
                
                csv_data.append({
                    'Category': category,
                    'Transaction_Count': stats['count'],
                    'Total_Amount': f"{stats['total_amount']:.2f}",
                    'Total_Income': f"{stats['income']:.2f}",
                    'Total_Expenses': f"{stats['expenses']:.2f}",
                    'Average_Amount': f"{avg_amount:.2f}",
                    'Percentage_of_Total': ''  # Will calculate after sorting
                })
                
            # Sort by total amount (descending)
            csv_data.sort(key=lambda x: abs(float(x['Total_Amount'])), reverse=True)
            
            # Calculate percentages
            total_amount = sum(abs(float(row['Total_Amount'])) for row in csv_data)
            for row in csv_data:
                if total_amount > 0:
                    percentage = (abs(float(row['Total_Amount'])) / total_amount) * 100
                    row['Percentage_of_Total'] = f"{percentage:.1f}%"
                    
            # Write to CSV
            output_file.parent.mkdir(parents=True, exist_ok=True)
            
            headers = ['Category', 'Transaction_Count', 'Total_Amount', 'Total_Income', 
                      'Total_Expenses', 'Average_Amount', 'Percentage_of_Total']
                      
            with open(output_file, 'w', newline='', encoding='utf-8') as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=headers)
                writer.writeheader()
                writer.writerows(csv_data)
                
            self.logger.info(f"Exported category summary to {output_file}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to export category summary: {str(e)}")
            return False
            
    def export_monthly_summary(self, transactions: List[Transaction], 
                             output_file: Path) -> bool:
        """
        Export monthly summary to CSV.
        
        Args:
            transactions: List of Transaction objects
            output_file: Path to output CSV file
            
        Returns:
            True if export successful
        """
        
        try:
            # Group transactions by month
            monthly_data = {}
            
            for txn in transactions:
                if not txn.date:
                    continue
                    
                month_key = txn.date.strftime('%Y-%m')
                amount = float(txn.amount) if txn.amount else 0.0
                
                if month_key not in monthly_data:
                    monthly_data[month_key] = {
                        'income': 0.0,
                        'expenses': 0.0,
                        'transaction_count': 0
                    }
                    
                monthly_data[month_key]['transaction_count'] += 1
                
                if amount > 0:
                    monthly_data[month_key]['income'] += amount
                else:
                    monthly_data[month_key]['expenses'] += abs(amount)
                    
            # Prepare CSV data
            csv_data = []
            for month, stats in sorted(monthly_data.items()):
                net_amount = stats['income'] - stats['expenses']
                
                csv_data.append({
                    'Month': month,
                    'Transaction_Count': stats['transaction_count'],
                    'Total_Income': f"{stats['income']:.2f}",
                    'Total_Expenses': f"{stats['expenses']:.2f}",
                    'Net_Amount': f"{net_amount:.2f}",
                    'Savings_Rate': f"{(net_amount / stats['income'] * 100):.1f}%" if stats['income'] > 0 else '0.0%'
                })
                
            # Write to CSV
            output_file.parent.mkdir(parents=True, exist_ok=True)
            
            headers = ['Month', 'Transaction_Count', 'Total_Income', 'Total_Expenses', 
                      'Net_Amount', 'Savings_Rate']
                      
            with open(output_file, 'w', newline='', encoding='utf-8') as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=headers)
                writer.writeheader()
                writer.writerows(csv_data)
                
            self.logger.info(f"Exported monthly summary to {output_file}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to export monthly summary: {str(e)}")
            return False
            
    def create_excel_workbook(self, transactions: List[Transaction], 
                            output_file: Path) -> bool:
        """
        Create Excel workbook with multiple sheets.
        
        Args:
            transactions: List of Transaction objects
            output_file: Path to output Excel file
            
        Returns:
            True if export successful
        """
        
        try:
            # Convert transactions to DataFrame
            data = [self._transaction_to_csv_row(txn, include_metadata=True) 
                   for txn in transactions]
            df_transactions = pd.DataFrame(data)
            
            # Create category summary
            category_summary = self._create_category_dataframe(transactions)
            
            # Create monthly summary  
            monthly_summary = self._create_monthly_dataframe(transactions)
            
            # Write to Excel with multiple sheets
            output_file.parent.mkdir(parents=True, exist_ok=True)
            
            with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
                df_transactions.to_excel(writer, sheet_name='All Transactions', index=False)
                category_summary.to_excel(writer, sheet_name='Category Summary', index=False)
                monthly_summary.to_excel(writer, sheet_name='Monthly Summary', index=False)
                
            self.logger.info(f"Created Excel workbook: {output_file}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to create Excel workbook: {str(e)}")
            return False
            
    def _create_category_dataframe(self, transactions: List[Transaction]) -> pd.DataFrame:
        """Create category summary DataFrame."""
        
        category_stats = {}
        
        for txn in transactions:
            category = txn.category or 'OTHER'
            amount = float(txn.amount) if txn.amount else 0.0
            
            if category not in category_stats:
                category_stats[category] = {
                    'Transaction_Count': 0,
                    'Total_Amount': 0.0,
                    'Total_Income': 0.0,
                    'Total_Expenses': 0.0
                }
                
            category_stats[category]['Transaction_Count'] += 1
            category_stats[category]['Total_Amount'] += amount
            
            if amount > 0:
                category_stats[category]['Total_Income'] += amount
            else:
                category_stats[category]['Total_Expenses'] += abs(amount)
                
        # Convert to DataFrame
        df_data = []
        for category, stats in category_stats.items():
            avg_amount = stats['Total_Amount'] / stats['Transaction_Count'] if stats['Transaction_Count'] > 0 else 0
            
            df_data.append({
                'Category': category,
                'Transaction_Count': stats['Transaction_Count'],
                'Total_Amount': round(stats['Total_Amount'], 2),
                'Total_Income': round(stats['Total_Income'], 2),
                'Total_Expenses': round(stats['Total_Expenses'], 2),
                'Average_Amount': round(avg_amount, 2)
            })
            
        return pd.DataFrame(df_data).sort_values('Total_Amount', key=abs, ascending=False)
        
    def _create_monthly_dataframe(self, transactions: List[Transaction]) -> pd.DataFrame:
        """Create monthly summary DataFrame."""
        
        monthly_data = {}
        
        for txn in transactions:
            if not txn.date:
                continue
                
            month_key = txn.date.strftime('%Y-%m')
            amount = float(txn.amount) if txn.amount else 0.0
            
            if month_key not in monthly_data:
                monthly_data[month_key] = {
                    'Transaction_Count': 0,
                    'Total_Income': 0.0,
                    'Total_Expenses': 0.0
                }
                
            monthly_data[month_key]['Transaction_Count'] += 1
            
            if amount > 0:
                monthly_data[month_key]['Total_Income'] += amount
            else:
                monthly_data[month_key]['Total_Expenses'] += abs(amount)
                
        # Convert to DataFrame
        df_data = []
        for month, stats in sorted(monthly_data.items()):
            net_amount = stats['Total_Income'] - stats['Total_Expenses']
            savings_rate = (net_amount / stats['Total_Income'] * 100) if stats['Total_Income'] > 0 else 0
            
            df_data.append({
                'Month': month,
                'Transaction_Count': stats['Transaction_Count'],
                'Total_Income': round(stats['Total_Income'], 2),
                'Total_Expenses': round(stats['Total_Expenses'], 2),
                'Net_Amount': round(net_amount, 2),
                'Savings_Rate_%': round(savings_rate, 1)
            })
            
        return pd.DataFrame(df_data)
