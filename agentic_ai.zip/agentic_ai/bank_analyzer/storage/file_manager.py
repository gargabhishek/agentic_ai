"""
File-based storage manager for transaction data.
"""
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional
import pandas as pd

from ..core.models import Transaction, TransactionBatch
from ..utils.logger import get_logger


class FileStorageManager:
    """Manages file-based storage of transaction data."""
    
    def __init__(self, base_output_dir: Optional[str] = None):
        """
        Initialize file storage manager.
        
        Args:
            base_output_dir: Base directory for output (defaults to output/)
        """
        self.logger = get_logger(__name__)
        
        # Set up base directories
        if base_output_dir:
            self.base_dir = Path(base_output_dir)
        else:
            # Use output folder in project root
            project_root = Path(__file__).parent.parent.parent
            self.base_dir = project_root / "output"
            
        self.processed_dir = self.base_dir / "processed"
        self.reports_dir = self.base_dir / "reports"
        self.logs_dir = self.base_dir / "logs"
        
        # Create directories
        self._create_directories()
        
        self.logger.info(f"FileStorageManager initialized with base dir: {self.base_dir}")
        
    def _create_directories(self):
        """Create necessary directories."""
        for directory in [self.base_dir, self.processed_dir, self.reports_dir, self.logs_dir]:
            directory.mkdir(parents=True, exist_ok=True)
            
    def save_transaction_batch(self, batch: TransactionBatch) -> Dict[str, str]:
        """
        Save a transaction batch to CSV files.
        
        Args:
            batch: TransactionBatch to save
            
        Returns:
            Dictionary with file paths created
        """
        timestamp = datetime.now()
        
        # Create year/month directory structure
        year_month_dir = self._get_year_month_dir(timestamp)
        year_month_dir.mkdir(parents=True, exist_ok=True)
        
        # Generate file names
        file_info = self._generate_file_names(batch, timestamp)
        
        # Save main transactions CSV
        transactions_file = year_month_dir / file_info['transactions_csv']
        self._save_transactions_csv(batch.transactions, transactions_file)
        
        # Save batch summary JSON
        summary_file = year_month_dir / file_info['summary_json']
        self._save_batch_summary(batch, summary_file)
        
        # Save processing log
        log_file = self.logs_dir / file_info['log_file']
        self._save_processing_log(batch, log_file)
        
        result = {
            'transactions_csv': str(transactions_file),
            'summary_json': str(summary_file),
            'log_file': str(log_file),
            'output_directory': str(year_month_dir)
        }
        
        self.logger.info(f"Saved batch {batch.id} to {year_month_dir}")
        return result
        
    def _get_year_month_dir(self, timestamp: datetime) -> Path:
        """Get year/month directory path."""
        year = timestamp.strftime('%Y')
        month = timestamp.strftime('%m-%B')
        return self.processed_dir / year / month
        
    def _generate_file_names(self, batch: TransactionBatch, timestamp: datetime) -> Dict[str, str]:
        """Generate standardized file names."""
        
        # Clean bank name for file name
        bank_name = (batch.bank_name or 'UNKNOWN').upper().replace(' ', '_')
        
        # Format timestamp
        date_str = timestamp.strftime('%Y-%m-%d')
        time_str = timestamp.strftime('%H%M%S')
        
        # Determine file type description
        file_type_desc = 'statement' if batch.file_type == 'pdf' else 'transactions'
        
        return {
            'transactions_csv': f"{bank_name}_{file_type_desc}_{date_str}_{time_str}.csv",
            'summary_json': f"batch_summary_{date_str}_{time_str}.json",
            'log_file': f"processing_{date_str}_{time_str}.log"
        }
        
    def _save_transactions_csv(self, transactions: List[Transaction], file_path: Path):
        """Save transactions to CSV file."""
        
        if not transactions:
            self.logger.warning("No transactions to save")
            return
            
        # Convert transactions to list of dictionaries
        data = []
        for txn in transactions:
            row = {
                'Date': txn.date.strftime('%Y-%m-%d') if txn.date else '',
                'Description': txn.description,
                'Amount': float(txn.amount) if txn.amount else 0.0,
                'Transaction_Type': txn.transaction_type.value if txn.transaction_type else '',
                'Category': txn.category or '',
                'Subcategory': txn.subcategory or '',
                'Confidence_Score': f"{txn.confidence_score:.3f}",
                'Classification_Method': txn.classification_method or '',
                'Keywords_Found': ', '.join(txn.keywords_found) if txn.keywords_found else '',
                'Bank_Name': txn.bank_name or '',
                'Source_File': Path(txn.source_file).name if txn.source_file else '',
                'Reference_Number': txn.reference_number or '',
                'Balance': float(txn.balance) if txn.balance else '',
                'Created_At': txn.created_at.strftime('%Y-%m-%d %H:%M:%S') if txn.created_at else '',
                'Transaction_ID': txn.id or ''
            }
            data.append(row)
            
        # Create DataFrame and save to CSV
        df = pd.DataFrame(data)
        
        # Sort by date (newest first)
        df['Date'] = pd.to_datetime(df['Date'])
        df = df.sort_values('Date', ascending=False)
        df['Date'] = df['Date'].dt.strftime('%Y-%m-%d')
        
        # Save with proper formatting
        df.to_csv(file_path, index=False, encoding='utf-8')
        
        self.logger.info(f"Saved {len(transactions)} transactions to {file_path}")
        
    def _save_batch_summary(self, batch: TransactionBatch, file_path: Path):
        """Save batch summary to JSON file."""
        
        summary = {
            'batch_info': {
                'batch_id': batch.id,
                'source_file': batch.source_file,
                'file_type': batch.file_type,
                'bank_name': batch.bank_name,
                'processing_status': batch.processing_status.value,
                'created_at': batch.created_at.isoformat() if batch.created_at else None,
                'completed_at': batch.completed_at.isoformat() if batch.completed_at else None
            },
            'statistics': {
                'total_transactions': batch.total_transactions,
                'processed_transactions': batch.processed_transactions,
                'failed_transactions': batch.failed_transactions,
                'success_rate': f"{batch.get_progress():.1f}%"
            },
            'category_breakdown': self._calculate_category_breakdown(batch.transactions),
            'amount_summary': self._calculate_amount_summary(batch.transactions),
            'error_messages': batch.error_messages
        }
        
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(summary, f, indent=2, default=str)
            
        self.logger.info(f"Saved batch summary to {file_path}")
        
    def _calculate_category_breakdown(self, transactions: List[Transaction]) -> Dict[str, Dict[str, Any]]:
        """Calculate category-wise breakdown."""
        breakdown = {}
        
        for txn in transactions:
            category = txn.category or 'OTHER'
            
            if category not in breakdown:
                breakdown[category] = {
                    'count': 0,
                    'total_amount': 0.0,
                    'average_amount': 0.0
                }
                
            breakdown[category]['count'] += 1
            breakdown[category]['total_amount'] += float(txn.amount) if txn.amount else 0.0
            
        # Calculate averages
        for category, data in breakdown.items():
            if data['count'] > 0:
                data['average_amount'] = data['total_amount'] / data['count']
                
        return breakdown
        
    def _calculate_amount_summary(self, transactions: List[Transaction]) -> Dict[str, float]:
        """Calculate amount summary statistics."""
        amounts = [float(txn.amount) for txn in transactions if txn.amount]
        
        if not amounts:
            return {
                'total_amount': 0.0,
                'total_income': 0.0,
                'total_expenses': 0.0,
                'net_amount': 0.0,
                'average_transaction': 0.0
            }
            
        income = sum(amt for amt in amounts if amt > 0)
        expenses = sum(abs(amt) for amt in amounts if amt < 0)
        
        return {
            'total_amount': sum(amounts),
            'total_income': income,
            'total_expenses': expenses,
            'net_amount': income - expenses,
            'average_transaction': sum(amounts) / len(amounts)
        }
        
    def _save_processing_log(self, batch: TransactionBatch, file_path: Path):
        """Save processing log."""
        
        log_data = {
            'timestamp': datetime.now().isoformat(),
            'batch_id': batch.id,
            'source_file': batch.source_file,
            'processing_summary': {
                'total_transactions': batch.total_transactions,
                'processed_successfully': batch.processed_transactions,
                'failed': batch.failed_transactions,
                'processing_time': str(batch.completed_at - batch.created_at) if batch.completed_at else None
            },
            'errors': batch.error_messages
        }
        
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(log_data, f, indent=2, default=str)
            
    def generate_analytics_report(self, period: str = "all_time") -> str:
        """
        Generate analytics report from all stored CSV files.
        
        Args:
            period: Period for analysis ("last_month", "last_3_months", "all_time")
            
        Returns:
            Path to generated analytics report
        """
        
        # Find all transaction CSV files
        csv_files = list(self.processed_dir.rglob("*.csv"))
        csv_files = [f for f in csv_files if not f.name.startswith('batch_summary')]
        
        if not csv_files:
            self.logger.warning("No transaction CSV files found for analytics")
            return ""
            
        # Combine all CSV files
        all_transactions = []
        for csv_file in csv_files:
            try:
                df = pd.read_csv(csv_file)
                all_transactions.append(df)
            except Exception as e:
                self.logger.warning(f"Could not read {csv_file}: {str(e)}")
                
        if not all_transactions:
            return ""
            
        # Combine all data
        combined_df = pd.concat(all_transactions, ignore_index=True)
        
        # Filter by period if needed
        if period != "all_time":
            combined_df = self._filter_by_period(combined_df, period)
            
        # Generate analytics
        analytics = self._generate_analytics_from_df(combined_df, period)
        
        # Save analytics report
        timestamp = datetime.now().strftime('%Y-%m-%d_%H%M%S')
        report_file = self.reports_dir / f"analytics_{period}_{timestamp}.json"
        
        with open(report_file, 'w', encoding='utf-8') as f:
            json.dump(analytics, f, indent=2, default=str)
            
        self.logger.info(f"Generated analytics report: {report_file}")
        return str(report_file)
        
    def _filter_by_period(self, df: pd.DataFrame, period: str) -> pd.DataFrame:
        """Filter DataFrame by time period."""
        
        df['Date'] = pd.to_datetime(df['Date'])
        now = datetime.now()
        
        if period == "last_month":
            cutoff = now - pd.DateOffset(months=1)
        elif period == "last_3_months":
            cutoff = now - pd.DateOffset(months=3)
        elif period == "last_year":
            cutoff = now - pd.DateOffset(years=1)
        else:
            return df
            
        return df[df['Date'] >= cutoff]
        
    def _generate_analytics_from_df(self, df: pd.DataFrame, period: str) -> Dict[str, Any]:
        """Generate analytics from DataFrame."""
        
        total_transactions = len(df)
        total_amount = df['Amount'].sum()
        income = df[df['Amount'] > 0]['Amount'].sum()
        expenses = abs(df[df['Amount'] < 0]['Amount'].sum())
        
        # Category breakdown
        category_breakdown = df.groupby('Category').agg({
            'Amount': ['sum', 'count', 'mean']
        }).round(2).to_dict()
        
        # Monthly trends (if enough data)
        df['Month'] = pd.to_datetime(df['Date']).dt.to_period('M')
        monthly_trends = df.groupby('Month')['Amount'].sum().to_dict()
        
        # Top expenses
        top_expenses = df[df['Amount'] < 0].nlargest(10, 'Amount')[
            ['Date', 'Description', 'Amount', 'Category']
        ].to_dict('records')
        
        return {
            'period': period,
            'generated_at': datetime.now().isoformat(),
            'summary': {
                'total_transactions': total_transactions,
                'total_amount': total_amount,
                'total_income': income,
                'total_expenses': expenses,
                'net_amount': income - expenses
            },
            'category_breakdown': category_breakdown,
            'monthly_trends': {str(k): v for k, v in monthly_trends.items()},
            'top_expenses': top_expenses
        }
        
    def list_processed_files(self) -> List[Dict[str, Any]]:
        """List all processed files with metadata."""
        
        files_info = []
        
        # Find all CSV files
        csv_files = list(self.processed_dir.rglob("*.csv"))
        
        for csv_file in csv_files:
            if csv_file.name.startswith('batch_summary'):
                continue
                
            try:
                # Get basic file info
                stat = csv_file.stat()
                
                # Try to read some basic info
                df = pd.read_csv(csv_file, nrows=1)  # Just read first row to get structure
                
                file_info = {
                    'file_path': str(csv_file),
                    'file_name': csv_file.name,
                    'size_mb': round(stat.st_size / (1024 * 1024), 2),
                    'created_at': datetime.fromtimestamp(stat.st_ctime).isoformat(),
                    'modified_at': datetime.fromtimestamp(stat.st_mtime).isoformat(),
                    'bank_name': df['Bank_Name'].iloc[0] if 'Bank_Name' in df.columns else 'Unknown',
                    'relative_path': str(csv_file.relative_to(self.base_dir))
                }
                
                files_info.append(file_info)
                
            except Exception as e:
                self.logger.warning(f"Could not read info for {csv_file}: {str(e)}")
                
        return sorted(files_info, key=lambda x: x['modified_at'], reverse=True)
        
    def get_storage_stats(self) -> Dict[str, Any]:
        """Get storage statistics."""
        
        csv_files = list(self.processed_dir.rglob("*.csv"))
        json_files = list(self.processed_dir.rglob("*.json"))
        log_files = list(self.logs_dir.rglob("*.log"))
        
        total_size = sum(f.stat().st_size for f in csv_files + json_files + log_files)
        
        return {
            'total_csv_files': len(csv_files),
            'total_json_files': len(json_files),
            'total_log_files': len(log_files),
            'total_size_mb': round(total_size / (1024 * 1024), 2),
            'base_directory': str(self.base_dir),
            'directories': {
                'processed': str(self.processed_dir),
                'reports': str(self.reports_dir),
                'logs': str(self.logs_dir)
            }
        }
