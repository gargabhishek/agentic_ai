"""
Core configuration settings for the Bank Transaction Analyzer.
"""
import os
from pathlib import Path
from typing import List, Optional
try:
    from pydantic_settings import BaseSettings
except ImportError:
    from pydantic import BaseSettings


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""
    
    # OpenAI Configuration
    openai_api_key: str = ""
    
    # Database Configuration
    database_url: str = "sqlite:///data/transactions.db"
    
    # Security
    secret_key: str = "your-secret-key-change-in-production"
    encryption_key: str = "your-encryption-key-32-chars-long"
    
    # API Configuration
    api_host: str = "0.0.0.0"
    api_port: int = 8000
    debug_mode: bool = True
    
    # File Processing
    max_file_size_mb: int = 50
    allowed_extensions: List[str] = ["pdf", "xlsx", "xls", "csv"]
    
    # Classification
    model_confidence_threshold: float = 0.8
    enable_ai_classification: bool = True
    fallback_to_rule_based: bool = True
    
    # Logging
    log_level: str = "INFO"
    log_file: str = "logs/app.log"
    
    # Paths
    project_root: Path = Path(__file__).parent.parent
    data_dir: Path = project_root / "data"
    raw_data_dir: Path = data_dir / "raw"
    processed_data_dir: Path = data_dir / "processed"
    reports_dir: Path = data_dir / "reports"
    logs_dir: Path = project_root / "logs"
    
    class Config:
        env_file = ".env"
        env_prefix = ""
        case_sensitive = False
        
    def __post_init__(self):
        """Create necessary directories on initialization."""
        for directory in [
            self.data_dir,
            self.raw_data_dir,
            self.processed_data_dir,
            self.reports_dir,
            self.logs_dir,
        ]:
            directory.mkdir(parents=True, exist_ok=True)


# Global settings instance
settings = Settings()

# Transaction categories for classification
TRANSACTION_CATEGORIES = {
    "INCOME": ["salary", "freelance", "interest", "dividend", "refund", "deposit"],
    "FOOD": ["restaurant", "grocery", "food", "dining", "cafe", "delivery"],
    "TRANSPORTATION": ["fuel", "gas", "uber", "taxi", "public transport", "parking"],
    "UTILITIES": ["electricity", "water", "gas", "internet", "phone", "cable"],
    "HEALTHCARE": ["doctor", "hospital", "pharmacy", "medical", "health"],
    "ENTERTAINMENT": ["movie", "streaming", "game", "concert", "sport"],
    "SHOPPING": ["amazon", "flipkart", "mall", "store", "retail"],
    "EDUCATION": ["school", "college", "course", "book", "training"],
    "INVESTMENT": ["mutual fund", "stock", "bond", "sip", "investment"],
    "INSURANCE": ["life insurance", "health insurance", "car insurance"],
    "LOAN": ["emi", "loan payment", "mortgage", "credit card payment"],
    "RENT": ["rent", "housing", "apartment", "property"],
    "OTHER": ["miscellaneous", "unknown", "other"]
}

# Bank statement patterns (regex patterns for different banks)
BANK_PATTERNS = {
    "HDFC": {
        "date_pattern": r"\d{2}/\d{2}/\d{4}",
        "amount_pattern": r"[\d,]+\.\d{2}",
        "description_pattern": r"[A-Za-z0-9\s\-/]+"
    },
    "ICICI": {
        "date_pattern": r"\d{2}-\d{2}-\d{4}",
        "amount_pattern": r"[\d,]+\.\d{2}",
        "description_pattern": r"[A-Za-z0-9\s\-/]+"
    },
    "SBI": {
        "date_pattern": r"\d{2}/\d{2}/\d{4}",
        "amount_pattern": r"[\d,]+\.\d{2}",
        "description_pattern": r"[A-Za-z0-9\s\-/]+"
    }
}
