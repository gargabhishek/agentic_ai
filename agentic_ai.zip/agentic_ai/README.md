# 🏦 Bank Transaction Analyzer

An AI-powered bank transaction classification and analysis system that automatically categorizes your financial transactions, provides insights, and helps you understand your spending patterns.

## ✨ Features

- **🤖 AI-Powered Classification**: Uses OpenAI GPT models for intelligent transaction categorization
- **📄 Multiple File Formats**: Supports PDF bank statements, Excel files, and CSV files
- **🏦 Multi-Bank Support**: Works with statements from HDFC, ICICI, SBI, and other major banks
- **📊 Advanced Analytics**: Generate detailed spending reports and insights
- **🔒 Secure**: Encrypts sensitive data and follows security best practices
- **⚡ Fast Processing**: Efficiently processes large transaction datasets
- **🖥️ Multiple Interfaces**: Command-line interface and REST API
- **📁 File-Based Storage**: Organizes results in CSV files with proper folder structure
- **📈 Easy Export**: Results saved as CSV files - open in Excel or Google Sheets

## 🚀 Quick Start

### Option 1: Docker (Recommended) 🐳

**Why Docker?**
- ✅ No dependency issues - everything is containerized
- ✅ Consistent environment across different systems
- ✅ Easy to deploy and share
- ✅ No Python environment conflicts

**Prerequisites:**
- Docker and Docker Compose
- OpenAI API key (for AI classification)

**Installation:**
1. **Clone the repository:**
   ```bash
   git clone <repository-url>
   cd agentic_ai
   ```

2. **Build Docker image:**
   ```bash
   ./docker-build
   ```

3. **Set up environment:**
   ```bash
   cp docker/env.template .env
   # Edit .env file with your OpenAI API key
   ```

4. **Create data directories:**
   ```bash
   mkdir -p data/input output
   # Place your bank statements in data/input/
   ```

**Usage:**
```bash
# Process a bank statement
./docker-process data/input/statement.pdf --bank HDFC

# Generate analytics
./docker-analytics --period last_month

# Interactive mode
./docker-run

# Check status and files
./docker-analytics status
./docker-analytics files
```

### Option 2: Local Installation

**Prerequisites:**
- Python 3.9 or higher
- OpenAI API key (for AI classification)

**Installation:**
1. **Clone the repository:**
   ```bash
   git clone <repository-url>
   cd agentic_ai
   ```

2. **Install dependencies:**
   ```bash
   pip install -e .
   ```

3. **Set up environment:**
   ```bash
   cp env.template .env
   # Edit .env file with your OpenAI API key and other settings
   ```

### Quick Example

```bash
# Process a bank statement
bank-analyzer process /path/to/bank_statement.pdf --bank HDFC

# View transactions
bank-analyzer list --period last_month

# Generate analytics
bank-analyzer analytics --period last_3_months

# Search transactions
bank-analyzer search "grocery"
```

## 📖 Documentation

### Configuration

The system uses environment variables for configuration. Copy `env.template` to `.env` and customize:

```bash
# OpenAI Configuration
OPENAI_API_KEY=your_openai_api_key_here

# Database (SQLite by default, PostgreSQL supported)
DATABASE_URL=sqlite:///data/transactions.db

# Security
SECRET_KEY=your-secret-key-here
ENCRYPTION_KEY=your-encryption-key-32-chars-long

# Features
ENABLE_AI_CLASSIFICATION=true
MODEL_CONFIDENCE_THRESHOLD=0.8
```

## 📁 Output Structure

The system stores all results in organized CSV files instead of a database:

```
output/
├── processed/
│   ├── 2024/
│   │   ├── 01-January/
│   │   │   ├── HDFC_statement_2024-01-15_143022.csv
│   │   │   ├── ICICI_transactions_2024-01-15_143045.csv
│   │   │   └── batch_summary_2024-01-15_143022.json
│   │   └── 02-February/
│   └── 2025/
├── reports/
│   ├── analytics_all_time_2024-01-15.json
│   └── category_summary_2024.csv
└── logs/
    └── processing_2024-01-15.log
```

**Benefits of File-Based Storage:**
- ✅ **No Database Setup**: Works immediately without complex database configuration
- ✅ **Easy to Review**: Open CSV files directly in Excel, Google Sheets, or any spreadsheet app
- ✅ **Portable**: Copy files anywhere, share with others easily
- ✅ **Version Control**: Track changes to your financial data over time
- ✅ **Backup Friendly**: Simple file backup and restore

### Supported File Formats

| Format | Extensions | Description |
|--------|------------|-------------|
| PDF | `.pdf` | Bank statement PDFs |
| Excel | `.xlsx`, `.xls` | Excel spreadsheets |
| CSV | `.csv` | Comma-separated values |

### Transaction Categories

The system automatically categorizes transactions into:

- **INCOME**: Salary, freelance, interest, dividends
- **FOOD**: Restaurants, groceries, delivery services
- **TRANSPORTATION**: Fuel, public transport, taxi/ride-sharing
- **UTILITIES**: Electricity, water, internet, phone bills
- **HEALTHCARE**: Medical expenses, pharmacy, insurance
- **ENTERTAINMENT**: Movies, streaming, gaming, events
- **SHOPPING**: Online/retail purchases, electronics, clothing
- **EDUCATION**: School fees, courses, books, training
- **INVESTMENT**: Mutual funds, stocks, SIP
- **INSURANCE**: Life, health, car insurance premiums
- **LOAN**: EMI, credit card payments, mortgage
- **RENT**: Housing payments, property expenses
- **OTHER**: Miscellaneous transactions

## 🖥️ Command Line Interface

### Processing Files

**With Docker:**
```bash
# Process single file
./docker-process data/input/statement.pdf --bank HDFC --ai

# Process without AI (rule-based only)  
./docker-process data/input/statement.xlsx --bank ICICI --no-ai

# Interactive mode for multiple files
./docker-run
# Inside container: bank-analyzer process /app/data/input/statement.pdf --bank HDFC
```

**Local Installation:**
```bash
# Process single file
bank-analyzer process statement.pdf --bank HDFC --ai

# Process multiple files
bank-analyzer batch *.pdf --bank HDFC --output-dir results/

# Process without AI (rule-based only)
bank-analyzer process statement.xlsx --no-ai
```

### Viewing Data

```bash
# List recent transactions from CSV files
bank-analyzer list --period last_week --limit 20

# Filter by category
bank-analyzer list --category FOOD --period last_month

# Filter by bank
bank-analyzer list --bank HDFC --period last_year

# Show all processed files and their locations
bank-analyzer files

# Check storage statistics
bank-analyzer status
```

### Analytics

```bash
# Generate analytics report
bank-analyzer analytics --period last_3_months --output report.json

# View system status
bank-analyzer status
```

### Search

```bash
# Search by description
bank-analyzer search "amazon" --limit 10

# Search within category
bank-analyzer search "restaurant" --category FOOD
```

## 🌐 REST API

Start the API server:

```bash
uvicorn bank_analyzer.api.app:app --host 0.0.0.0 --port 8000
```

### Authentication

```bash
# Login to get access token
curl -X POST "http://localhost:8000/api/v1/auth/login" \
     -H "Content-Type: application/x-www-form-urlencoded" \
     -d "username=admin&password=admin"
```

### Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/v1/process/upload` | Upload and process bank statement |
| `GET` | `/api/v1/transactions` | Get transactions with filters |
| `POST` | `/api/v1/transactions/classify` | Classify a single transaction |
| `GET` | `/api/v1/analytics/summary` | Get analytics summary |
| `GET` | `/api/v1/system/status` | Get system status |

### Example API Usage

```python
import requests

# Login
response = requests.post('http://localhost:8000/api/v1/auth/login', 
                        data={'username': 'admin', 'password': 'admin'})
token = response.json()['access_token']

headers = {'Authorization': f'Bearer {token}'}

# Upload file
with open('statement.pdf', 'rb') as f:
    files = {'file': f}
    data = {'bank_name': 'HDFC', 'use_ai': True}
    response = requests.post('http://localhost:8000/api/v1/process/upload',
                           files=files, data=data, headers=headers)

# Get transactions
response = requests.get('http://localhost:8000/api/v1/transactions?limit=10',
                       headers=headers)
transactions = response.json()['transactions']
```

## 🏗️ Architecture

The system follows a modular architecture:

```
bank_analyzer/
├── core/           # Core business logic
│   ├── models.py   # Data models
│   └── processor.py # Main processing engine
├── parsers/        # File format parsers
│   ├── pdf_parser.py
│   └── excel_parser.py
├── classifiers/    # Transaction classification
│   ├── ai_classifier.py
│   └── rule_based_classifier.py
├── database/       # Data persistence
│   ├── models.py
│   └── manager.py
├── api/           # REST API
├── cli/           # Command line interface
├── utils/         # Utilities
└── security/      # Security functions
```

## 🔧 Advanced Configuration

### Custom Categories

You can define custom transaction categories by modifying `TRANSACTION_CATEGORIES` in `config/settings.py`:

```python
CUSTOM_CATEGORIES = {
    "CUSTOM_CATEGORY": ["keyword1", "keyword2", "keyword3"],
    # Add more custom categories
}
```

### Database Configuration

#### SQLite (Default)
```bash
DATABASE_URL=sqlite:///data/transactions.db
```

#### PostgreSQL
```bash
DATABASE_URL=postgresql://user:password@localhost:5432/bank_transactions
```

### AI Model Configuration

```bash
# Use different OpenAI model
OPENAI_MODEL=gpt-4  # Default: gpt-3.5-turbo

# Adjust confidence threshold
MODEL_CONFIDENCE_THRESHOLD=0.9  # Default: 0.8

# Disable AI fallback
FALLBACK_TO_RULE_BASED=false  # Default: true
```

## 🧪 Testing

Run the test suite:

```bash
# Install development dependencies
pip install -e ".[dev]"

# Run tests
pytest tests/ -v

# Run with coverage
pytest tests/ --cov=bank_analyzer --cov-report=html
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

- **Documentation**: Check this README and inline code documentation
- **Issues**: Report bugs and feature requests on GitHub Issues
- **Discussions**: Join discussions on GitHub Discussions

## 🏅 Acknowledgments

- OpenAI for providing excellent language models
- The Python community for amazing libraries
- Contributors and users of this project

---

**Built with ❤️ for better financial insights**


## 🐳 Docker Deployment

### Docker Architecture

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   Host System   │    │  Docker Container │    │  File Storage   │
│                 │    │                   │    │                 │
│  data/input/ ───┼────┼→ /app/data/      │    │  output/       │
│  output/    ────┼────┼→ /app/output/    ├────┼→ processed/    │
│  .env       ────┼────┼→ Environment     │    │  reports/      │
│                 │    │  Variables       │    │  logs/         │
└─────────────────┘    └──────────────────┘    └─────────────────┘
```

### Docker Commands Reference

**Build and Setup:**
```bash
# Build the image
./docker-build

# Create environment file
cp docker/env.template .env
```

**Processing:**
```bash
# Quick processing
./docker-process data/input/statement.pdf --bank HDFC

# Interactive shell
./docker-run

# Analytics and reports
./docker-analytics --period last_month
./docker-analytics status
```

### Common Docker Issues

**Permission Issues:**
```bash
# Fix file permissions
sudo chown -R $USER:$USER output/
chmod -R 755 output/
```


