"""
Test cases for the TransactionProcessor.
"""
import pytest
from datetime import datetime
from decimal import Decimal
from pathlib import Path
import tempfile

from bank_analyzer.core.processor import TransactionProcessor
from bank_analyzer.core.models import Transaction, TransactionType


class TestTransactionProcessor:
    """Test cases for TransactionProcessor class."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.processor = TransactionProcessor(use_ai=False)  # Use rule-based for testing
        
    def test_processor_initialization(self):
        """Test processor initialization."""
        assert self.processor is not None
        assert self.processor.use_ai is False
        assert self.processor.rule_classifier is not None
        
    def test_classify_transaction(self):
        """Test transaction classification."""
        # Test food transaction
        transaction = Transaction(
            description="ZOMATO FOOD DELIVERY",
            amount=Decimal("250.00"),
            transaction_type=TransactionType.DEBIT,
            date=datetime.now()
        )
        
        result = self.processor.classify_transaction(transaction)
        
        assert result is not None
        assert result.category == "FOOD"
        assert result.confidence_score > 0
        assert result.method == "rule_based"
        
    def test_classify_salary_transaction(self):
        """Test salary transaction classification."""
        transaction = Transaction(
            description="SALARY CREDIT FOR MONTH",
            amount=Decimal("50000.00"),
            transaction_type=TransactionType.CREDIT,
            date=datetime.now()
        )
        
        result = self.processor.classify_transaction(transaction)
        
        assert result.category == "INCOME"
        assert result.confidence_score > 0.5
        
    def test_classify_unknown_transaction(self):
        """Test unknown transaction classification."""
        transaction = Transaction(
            description="RANDOM UNKNOWN TRANSACTION XYZ123",
            amount=Decimal("100.00"),
            transaction_type=TransactionType.DEBIT,
            date=datetime.now()
        )
        
        result = self.processor.classify_transaction(transaction)
        
        assert result.category == "OTHER"
        
    def test_create_transaction(self):
        """Test transaction creation from raw data."""
        raw_data = {
            'date': datetime.now(),
            'description': 'Test transaction',
            'amount': 100.50,
            'bank_name': 'TEST_BANK',
            'account_number': '1234567890'
        }
        
        transaction = self.processor._create_transaction(
            raw_data, 'test_file.csv', 'TEST_BANK'
        )
        
        assert transaction.description == 'Test transaction'
        assert transaction.amount == Decimal('100.50')
        assert transaction.bank_name == 'TEST_BANK'
        assert transaction.source_file == 'test_file.csv'


class TestTransactionClassification:
    """Test transaction classification logic."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.processor = TransactionProcessor(use_ai=False)
        
    @pytest.mark.parametrize("description,expected_category", [
        ("AMAZON PURCHASE", "SHOPPING"),
        ("UBER RIDE", "TRANSPORTATION"),
        ("SALARY CREDIT", "INCOME"),
        ("ELECTRICITY BILL", "UTILITIES"),
        ("NETFLIX SUBSCRIPTION", "ENTERTAINMENT"),
        ("GROCERY STORE", "FOOD"),
        ("DOCTOR CONSULTATION", "HEALTHCARE"),
        ("HOUSE RENT", "RENT"),
        ("EMI PAYMENT", "LOAN"),
        ("MUTUAL FUND SIP", "INVESTMENT"),
    ])
    def test_category_classification(self, description, expected_category):
        """Test category classification for various transaction types."""
        transaction = Transaction(
            description=description,
            amount=Decimal("1000.00"),
            transaction_type=TransactionType.DEBIT,
            date=datetime.now()
        )
        
        result = self.processor.classify_transaction(transaction)
        assert result.category == expected_category


@pytest.fixture
def sample_csv_file():
    """Create a sample CSV file for testing."""
    csv_content = """Date,Description,Amount,Type
2024-01-01,SALARY CREDIT,50000.00,Credit
2024-01-02,GROCERY STORE,-2500.00,Debit
2024-01-03,UBER RIDE,-450.00,Debit
2024-01-04,NETFLIX SUBSCRIPTION,-799.00,Debit
"""
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
        f.write(csv_content)
        temp_path = Path(f.name)
        
    yield temp_path
    
    # Cleanup
    temp_path.unlink(missing_ok=True)


def test_file_processing_integration(sample_csv_file):
    """Integration test for file processing."""
    processor = TransactionProcessor(use_ai=False)
    
    # This would require implementing CSV parser
    # For now, just test that the processor can be initialized
    assert processor is not None
    
    # TODO: Implement full file processing test when CSV parser is ready


if __name__ == "__main__":
    pytest.main([__file__])
