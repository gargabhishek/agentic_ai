#!/usr/bin/env python3
"""
Demo script for Bank Transaction Analyzer.
"""
import sys
from pathlib import Path
from datetime import datetime
from decimal import Decimal

# Add the project root to Python path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from bank_analyzer.core.processor import TransactionProcessor
from bank_analyzer.core.models import Transaction, TransactionType
from bank_analyzer.database.manager import DatabaseManager
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

console = Console()


def create_sample_transactions():
    """Create sample transactions for demo."""
    transactions = [
        Transaction(
            description="SALARY CREDIT FROM COMPANY XYZ",
            amount=Decimal("75000.00"),
            transaction_type=TransactionType.CREDIT,
            date=datetime(2024, 1, 1),
            bank_name="HDFC"
        ),
        Transaction(
            description="ZOMATO FOOD DELIVERY CHARGES",
            amount=Decimal("-450.00"),
            transaction_type=TransactionType.DEBIT,
            date=datetime(2024, 1, 2),
            bank_name="HDFC"
        ),
        Transaction(
            description="AMAZON.IN ONLINE PURCHASE",
            amount=Decimal("-2599.00"),
            transaction_type=TransactionType.DEBIT,
            date=datetime(2024, 1, 3),
            bank_name="HDFC"
        ),
        Transaction(
            description="UBER INDIA RIDE CHARGES",
            amount=Decimal("-285.00"),
            transaction_type=TransactionType.DEBIT,
            date=datetime(2024, 1, 4),
            bank_name="HDFC"
        ),
        Transaction(
            description="ELECTRICITY BILL PAYMENT",
            amount=Decimal("-1250.00"),
            transaction_type=TransactionType.DEBIT,
            date=datetime(2024, 1, 5),
            bank_name="HDFC"
        ),
        Transaction(
            description="NETFLIX SUBSCRIPTION",
            amount=Decimal("-799.00"),
            transaction_type=TransactionType.DEBIT,
            date=datetime(2024, 1, 6),
            bank_name="HDFC"
        ),
        Transaction(
            description="MUTUAL FUND SIP INVESTMENT",
            amount=Decimal("-5000.00"),
            transaction_type=TransactionType.DEBIT,
            date=datetime(2024, 1, 7),
            bank_name="HDFC"
        ),
        Transaction(
            description="HOUSE RENT PAYMENT",
            amount=Decimal("-25000.00"),
            transaction_type=TransactionType.DEBIT,
            date=datetime(2024, 1, 8),
            bank_name="HDFC"
        ),
    ]
    
    return transactions


def demo_classification():
    """Demonstrate transaction classification."""
    console.print(Panel.fit("🤖 Bank Transaction Analyzer Demo", style="bold green"))
    
    # Initialize processor
    console.print("🔄 Initializing transaction processor...")
    processor = TransactionProcessor(use_ai=False)  # Use rule-based for demo
    
    # Create sample transactions
    transactions = create_sample_transactions()
    
    # Classify transactions
    console.print("📊 Classifying transactions...")
    
    classified_transactions = []
    for transaction in transactions:
        result = processor.classify_transaction(transaction)
        transaction.category = result.category
        transaction.subcategory = result.subcategory
        transaction.confidence_score = result.confidence_score
        transaction.classification_method = result.method
        classified_transactions.append(transaction)
    
    # Display results
    console.print("\n[bold]Classification Results:[/bold]")
    
    table = Table()
    table.add_column("Description", style="white", max_width=40)
    table.add_column("Amount", style="cyan", justify="right")
    table.add_column("Category", style="yellow")
    table.add_column("Confidence", style="green", justify="right")
    
    for txn in classified_transactions:
        amount_color = "red" if txn.amount < 0 else "green"
        amount_str = f"[{amount_color}]₹{abs(txn.amount):,.2f}[/{amount_color}]"
        
        table.add_row(
            txn.description[:40],
            amount_str,
            txn.category,
            f"{txn.confidence_score:.2%}"
        )
    
    console.print(table)
    
    # Calculate category totals
    category_totals = {}
    for txn in classified_transactions:
        category = txn.category
        if category not in category_totals:
            category_totals[category] = Decimal('0')
        category_totals[category] += txn.amount
    
    # Display category summary
    console.print("\n[bold]Category Summary:[/bold]")
    
    summary_table = Table()
    summary_table.add_column("Category", style="cyan")
    summary_table.add_column("Total Amount", style="white", justify="right")
    summary_table.add_column("Percentage", style="yellow", justify="right")
    
    total_expenses = sum(abs(amount) for amount in category_totals.values() if amount < 0)
    
    for category, amount in sorted(category_totals.items(), key=lambda x: abs(x[1]), reverse=True):
        if amount != 0:
            percentage = (abs(amount) / total_expenses * 100) if total_expenses > 0 and amount < 0 else 0
            amount_color = "red" if amount < 0 else "green"
            amount_str = f"[{amount_color}]₹{abs(amount):,.2f}[/{amount_color}]"
            
            summary_table.add_row(
                category,
                amount_str,
                f"{percentage:.1f}%" if amount < 0 else "N/A"
            )
    
    console.print(summary_table)
    
    # Save to database (optional)
    try:
        console.print("\n💾 Saving transactions to database...")
        db_manager = DatabaseManager()
        
        for txn in classified_transactions:
            db_manager.save_transaction(txn)
            
        console.print("[green]✅ Transactions saved successfully![/green]")
        
    except Exception as e:
        console.print(f"[red]❌ Error saving to database: {str(e)}[/red]")
    
    console.print(f"\n[bold green]🎉 Demo completed! Processed {len(classified_transactions)} transactions.[/bold green]")


def demo_analytics():
    """Demonstrate analytics generation."""
    console.print("\n📊 Generating Analytics...")
    
    try:
        db_manager = DatabaseManager()
        analytics = db_manager.get_analytics()
        
        if analytics and analytics.get('total_transactions', 0) > 0:
            console.print("\n[bold]Analytics Summary:[/bold]")
            
            analytics_table = Table(show_header=False, box=None)
            analytics_table.add_column("Metric", style="cyan")
            analytics_table.add_column("Value", style="white")
            
            analytics_table.add_row("Total Transactions", f"{analytics.get('total_transactions', 0):,}")
            analytics_table.add_row("Total Income", f"₹{analytics.get('total_income', 0):,.2f}")
            analytics_table.add_row("Total Expenses", f"₹{analytics.get('total_expenses', 0):,.2f}")
            analytics_table.add_row("Net Amount", f"₹{analytics.get('net_amount', 0):,.2f}")
            
            console.print(analytics_table)
        else:
            console.print("[yellow]No data available for analytics[/yellow]")
            
    except Exception as e:
        console.print(f"[red]Error generating analytics: {str(e)}[/red]")


def main():
    """Run the demo."""
    try:
        demo_classification()
        demo_analytics()
        
        console.print("\n[bold blue]💡 Tips:[/bold blue]")
        console.print("• Use 'bank-analyzer --help' to see all CLI commands")
        console.print("• Start the API with 'python scripts/start_api.py'")
        console.print("• Check the documentation in README.md")
        
    except KeyboardInterrupt:
        console.print("\n[yellow]Demo interrupted by user[/yellow]")
    except Exception as e:
        console.print(f"\n[red]Demo failed: {str(e)}[/red]")


if __name__ == "__main__":
    main()
