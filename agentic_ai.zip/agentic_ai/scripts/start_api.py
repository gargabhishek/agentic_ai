#!/usr/bin/env python3
"""
Script to start the Bank Transaction Analyzer API server.
"""
import uvicorn
import argparse
from pathlib import Path
import sys

# Add the project root to Python path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from config import settings


def main():
    """Start the API server."""
    parser = argparse.ArgumentParser(description="Start Bank Transaction Analyzer API")
    parser.add_argument("--host", default=settings.api_host, help="Host to bind to")
    parser.add_argument("--port", type=int, default=settings.api_port, help="Port to bind to")
    parser.add_argument("--reload", action="store_true", help="Enable auto-reload")
    parser.add_argument("--debug", action="store_true", help="Enable debug mode")
    
    args = parser.parse_args()
    
    print(f"🚀 Starting Bank Transaction Analyzer API")
    print(f"📍 Server: http://{args.host}:{args.port}")
    print(f"📚 API Docs: http://{args.host}:{args.port}/docs")
    print(f"🔧 Debug Mode: {args.debug or settings.debug_mode}")
    
    uvicorn.run(
        "bank_analyzer.api.app:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
        log_level="debug" if args.debug else "info"
    )


if __name__ == "__main__":
    main()
