# 🐳 Docker Setup

This directory contains all Docker-related files for the Bank Transaction Analyzer.

## 📁 Directory Structure

```
docker/
├── Dockerfile              # Container definition
├── docker-compose.yml      # Multi-service orchestration
├── env.template            # Environment variables template
├── scripts/                # Docker utility scripts
│   ├── build.sh            # Build the Docker image
│   ├── run.sh              # Run interactive container
│   ├── process.sh          # Process bank statements
│   └── analytics.sh        # Generate analytics
└── README.md               # This file
```

## 🚀 Quick Start

### Option 1: Use wrapper scripts (from project root)
```bash
./docker-build                                      # Build image
./docker-process data/input/statement.pdf --bank HDFC  # Process file
./docker-analytics --period last_month              # Generate analytics
./docker-run                                        # Interactive mode
```

### Option 2: Use scripts directly
```bash
# From project root
docker/scripts/build.sh
docker/scripts/process.sh data/input/statement.pdf --bank HDFC
docker/scripts/analytics.sh --period last_month
docker/scripts/run.sh
```

### Option 3: Use Docker Compose
```bash
# From docker/ directory
cd docker
docker-compose up -d
```

## 🔧 Configuration

1. **Copy environment template:**
   ```bash
   cp docker/env.template .env
   ```

2. **Edit `.env` file:**
   ```bash
   OPENAI_API_KEY=your-actual-api-key
   ENABLE_AI_CLASSIFICATION=true
   # ... other settings
   ```

## 📦 What Gets Built

The Docker image includes:
- ✅ Python 3.11 with all dependencies
- ✅ Bank Transaction Analyzer package
- ✅ Non-root user for security
- ✅ Volume mounts for data persistence
- ✅ Health checks
- ✅ Proper environment setup

## 🔍 Troubleshooting

**Build Issues:**
```bash
# Clean rebuild
docker system prune -f
docker/scripts/build.sh
```

**Permission Issues:**
```bash
# Fix output directory permissions
sudo chown -R $USER:$USER output/
chmod -R 755 output/
```

**Path Issues:**
```bash
# Ensure you're in project root when running scripts
pwd  # Should show: .../agentic_ai
```

## 🎯 Benefits of This Structure

- ✅ **Clean**: All Docker files organized in one place
- ✅ **Maintainable**: Easy to find and update Docker configurations  
- ✅ **Flexible**: Multiple ways to run (wrapper scripts, direct, compose)
- ✅ **Backward Compatible**: Wrapper scripts maintain old interface
- ✅ **Professional**: Follows Docker best practices
