#!/bin/bash

# Bank Transaction Analyzer - Docker Run Script
set -e

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${BLUE}🐳 Running Bank Transaction Analyzer in Docker...${NC}"
echo "=================================================="

# Navigate to project root and create directories if they don't exist
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
cd "$PROJECT_ROOT"

mkdir -p data/input
mkdir -p output
mkdir -p config

echo -e "${YELLOW}📁 Directory structure:${NC}"
echo "  • ./data/input  - Place your bank statements here"
echo "  • ./output      - Processed CSV files will appear here"
echo "  • ./config      - Configuration files"
echo ""

# Check if .env file exists
if [ ! -f .env ]; then
    echo -e "${YELLOW}⚠️  No .env file found. Creating template...${NC}"
    cp docker/env.template .env
    echo "  📝 Please edit .env file with your OpenAI API key"
    echo ""
fi

# Run the container interactively
echo -e "${GREEN}🚀 Starting interactive container...${NC}"
echo "   Type 'bank-analyzer --help' to see available commands"
echo "   Type 'exit' to stop the container"
echo ""

docker run --rm -it \
    --name bank-analyzer-interactive \
    -v "$(pwd)/data:/app/data" \
    -v "$(pwd)/output:/app/output" \
    -v "$(pwd)/config:/app/config" \
    --env-file .env \
    bank-transaction-analyzer:latest \
    /bin/bash

echo -e "${GREEN}✅ Container stopped.${NC}"
