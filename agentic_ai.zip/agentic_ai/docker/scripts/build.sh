#!/bin/bash

# Bank Transaction Analyzer - Docker Build Script
set -e

echo "🐳 Building Bank Transaction Analyzer Docker Image..."
echo "=================================================="

# Build the Docker image (from project root)
# Get the script directory and navigate to project root
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
cd "$PROJECT_ROOT"

docker build -f docker/Dockerfile -t bank-transaction-analyzer:latest .

echo ""
echo "✅ Docker image built successfully!"
echo ""
echo "📋 Available commands:"
echo "  • docker run --rm -it bank-transaction-analyzer --help"
echo "  • cd docker && docker-compose up -d"
echo "  • docker/scripts/run.sh"
echo ""
echo "🎉 Ready to analyze your bank transactions!"
