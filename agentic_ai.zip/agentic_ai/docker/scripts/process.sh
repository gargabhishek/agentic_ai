#!/bin/bash

# Bank Transaction Analyzer - Docker Process Script
# Quick script to process bank statements using Docker

set -e

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Help function
show_help() {
    echo -e "${BLUE}🐳 Bank Transaction Analyzer - Docker Process${NC}"
    echo "=============================================="
    echo ""
    echo "Usage: $0 <statement-file> [options]"
    echo ""
    echo "Examples:"
    echo "  $0 data/input/hdfc_statement.pdf --bank HDFC"
    echo "  $0 data/input/transactions.xlsx --bank ICICI --no-ai"
    echo ""
    echo "Options:"
    echo "  --bank BANK_NAME    Specify bank name (HDFC, ICICI, SBI, etc.)"
    echo "  --ai                Use AI classification (default)"
    echo "  --no-ai             Use only rule-based classification"
    echo "  --help              Show this help message"
    echo ""
    echo "Note: Place your bank statements in the 'data/input/' directory"
}

# Check if Docker is running
if ! docker info > /dev/null 2>&1; then
    echo -e "${RED}❌ Docker is not running. Please start Docker first.${NC}"
    exit 1
fi

# Check if help is requested
if [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
    show_help
    exit 0
fi

# Check if file is provided
if [ $# -eq 0 ]; then
    echo -e "${RED}❌ No file specified.${NC}"
    echo ""
    show_help
    exit 1
fi

FILE_PATH="$1"
shift # Remove file path from arguments

# Check if file exists
if [ ! -f "$FILE_PATH" ]; then
    echo -e "${RED}❌ File not found: $FILE_PATH${NC}"
    echo ""
    echo -e "${YELLOW}💡 Make sure to place your bank statements in 'data/input/' directory${NC}"
    exit 1
fi

# Navigate to project root
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
cd "$PROJECT_ROOT"

# Create directories if they don't exist
mkdir -p data/input
mkdir -p output
mkdir -p config

# Check if .env file exists
if [ ! -f .env ]; then
    echo -e "${YELLOW}⚠️  No .env file found. Creating template...${NC}"
    cp docker/env.template .env
    echo -e "${YELLOW}   📝 Please edit .env file with your OpenAI API key${NC}"
    echo ""
fi

# Prepare the command
DOCKER_FILE_PATH="/app/$FILE_PATH"
COMMAND="bank-analyzer process $DOCKER_FILE_PATH $@"

echo -e "${BLUE}🐳 Processing bank statement with Docker...${NC}"
echo "=============================================="
echo -e "${YELLOW}📄 File:${NC} $FILE_PATH"
echo -e "${YELLOW}🔧 Command:${NC} $COMMAND"
echo ""

# Run the container
docker run --rm \
    --name bank-analyzer-process \
    -v "$(pwd)/data:/app/data" \
    -v "$(pwd)/output:/app/output" \
    -v "$(pwd)/config:/app/config" \
    --env-file .env \
    bank-transaction-analyzer:latest \
    $COMMAND

echo ""
echo -e "${GREEN}✅ Processing complete!${NC}"
echo -e "${BLUE}📁 Check the 'output/' directory for your results${NC}"
echo ""
echo -e "${YELLOW}💡 Next steps:${NC}"
echo "  • Open CSV files in Excel or Google Sheets"
echo "  • Run 'docker/scripts/analytics.sh' for analytics reports"
echo "  • Use 'docker/scripts/run.sh' for interactive mode"
