#!/bin/bash

# Bank Transaction Analyzer - Docker Analytics Script
# Generate analytics reports using Docker

set -e

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Help function
show_help() {
    echo -e "${BLUE}🐳 Bank Transaction Analyzer - Docker Analytics${NC}"
    echo "==============================================="
    echo ""
    echo "Usage: $0 [options]"
    echo ""
    echo "Examples:"
    echo "  $0                           # All-time analytics"
    echo "  $0 --period last_month       # Last month analytics"
    echo "  $0 --period last_3_months    # Last 3 months analytics"
    echo ""
    echo "Options:"
    echo "  --period PERIOD    Time period (last_week, last_month, last_3_months, last_year)"
    echo "  --help             Show this help message"
    echo ""
    echo "Available commands:"
    echo "  analytics          Generate analytics report"
    echo "  status             Show system status"
    echo "  files              List processed files"
    echo "  search QUERY       Search transactions"
}

# Check if Docker is running
if ! docker info > /dev/null 2>&1; then
    echo -e "${RED}❌ Docker is not running. Please start Docker first.${NC}"
    exit 1
fi

# Check if help is requested
if [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
    show_help
    exit 0
fi

# Parse arguments
PERIOD="all_time"
COMMAND="analytics"

while [[ $# -gt 0 ]]; do
    case $1 in
        --period)
            PERIOD="$2"
            shift 2
            ;;
        status|files|search)
            COMMAND="$1"
            shift
            ;;
        *)
            if [ "$COMMAND" = "search" ]; then
                SEARCH_QUERY="$1"
            fi
            shift
            ;;
    esac
done

# Navigate to project root
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
cd "$PROJECT_ROOT"

# Create directories if they don't exist
mkdir -p data/input
mkdir -p output
mkdir -p config

# Check if .env file exists
if [ ! -f .env ]; then
    echo -e "${YELLOW}⚠️  No .env file found. Creating template...${NC}"
    cp docker/env.template .env
    echo -e "${YELLOW}   📝 Please edit .env file with your OpenAI API key${NC}"
    echo ""
fi

# Prepare the command based on action
case $COMMAND in
    analytics)
        DOCKER_COMMAND="bank-analyzer analytics --period $PERIOD"
        echo -e "${BLUE}📊 Generating analytics report...${NC}"
        ;;
    status)
        DOCKER_COMMAND="bank-analyzer status"
        echo -e "${BLUE}📋 Getting system status...${NC}"
        ;;
    files)
        DOCKER_COMMAND="bank-analyzer files"
        echo -e "${BLUE}📁 Listing processed files...${NC}"
        ;;
    search)
        if [ -z "$SEARCH_QUERY" ]; then
            echo -e "${RED}❌ Search query is required${NC}"
            echo "Usage: $0 search 'your search term'"
            exit 1
        fi
        DOCKER_COMMAND="bank-analyzer search '$SEARCH_QUERY'"
        echo -e "${BLUE}🔍 Searching transactions...${NC}"
        ;;
esac

echo "=============================================="
echo -e "${YELLOW}🔧 Command:${NC} $DOCKER_COMMAND"
echo ""

# Run the container
docker run --rm \
    --name bank-analyzer-analytics \
    -v "$(pwd)/data:/app/data" \
    -v "$(pwd)/output:/app/output" \
    -v "$(pwd)/config:/app/config" \
    --env-file .env \
    bank-transaction-analyzer:latest \
    bash -c "$DOCKER_COMMAND"

echo ""
echo -e "${GREEN}✅ Operation complete!${NC}"

if [ "$COMMAND" = "analytics" ]; then
    echo -e "${BLUE}📁 Check the 'output/reports/' directory for analytics files${NC}"
fi

echo ""
echo -e "${YELLOW}💡 Available commands:${NC}"
echo "  • docker/scripts/process.sh <file>     Process bank statements"
echo "  • docker/scripts/analytics.sh status  Show system status"
echo "  • docker/scripts/analytics.sh files   List processed files"
echo "  • docker/scripts/run.sh               Interactive mode"
